'use client';

import { useSearchParams, useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';

export default function SawrniAppLogin() {
  const search = useSearchParams();
  const router = useRouter();
  const role = useMemo(() => (search.get('role') === 'provider' ? 'provider' : 'customer'), [search]);
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  async function requestOtp() {
    setLoading(true);
    setMessage('');
    try {
      const res = await fetch('/api/app-auth/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, role }),
      });
      const data = await res.json();
      if (!res.ok || data.status !== 'ok') {
        setMessage(data.message_ar || data.message_en || 'حدث خطأ.');
        return;
      }
      localStorage.setItem('sawrni_app_phone', phone);
      localStorage.setItem('sawrni_app_role', role);
      if (data.otp_preview) localStorage.setItem('sawrni_app_otp_preview', data.otp_preview);
      router.push('/app/otp');
    } catch (e) {
      setMessage('تعذر الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ minHeight: '100vh', background: '#f5f7fb', direction: 'rtl', padding: 24, fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' }}>
      <section style={{ maxWidth: 560, margin: '40px auto', background: 'white', borderRadius: 32, padding: 30, boxShadow: '0 24px 80px rgba(15,23,42,.12)', border: '1px solid #e2e8f0' }}>
        <div style={{ color: '#5b2dac', fontWeight: 900 }}>Sawrni Phase 7.0</div>
        <h1 style={{ fontSize: 42, margin: '12px 0 8px', color: '#0f172a' }}>تسجيل الدخول</h1>
        <p style={{ color: '#64748b', fontSize: 17, lineHeight: 1.7 }}>الدور الحالي: <b>{role === 'provider' ? 'مزود خدمة' : 'عميل'}</b></p>

        <label style={{ display: 'block', color: '#334155', fontWeight: 800, marginBottom: 8 }}>رقم الهاتف</label>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="07xxxxxxxxx" inputMode="tel" style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #cbd5e1', borderRadius: 18, padding: '18px 16px', fontSize: 22, outline: 'none', marginBottom: 16 }} />

        {message && <div style={{ border: '1px solid #fecaca', background: '#fff1f2', color: '#991b1b', borderRadius: 18, padding: 14, marginBottom: 14, fontWeight: 800 }}>{message}</div>}

        <button onClick={requestOtp} disabled={loading || phone.length < 8} style={{ width: '100%', border: 0, borderRadius: 18, padding: '17px 20px', background: loading ? '#94a3b8' : '#5b2dac', color: 'white', fontWeight: 900, fontSize: 18 }}>
          {loading ? 'جاري الإرسال...' : 'إرسال رمز التحقق'}
        </button>

        <button onClick={() => router.push('/app')} style={{ width: '100%', border: '1px solid #e2e8f0', borderRadius: 18, padding: '15px 20px', background: 'white', color: '#0f172a', fontWeight: 900, fontSize: 16, marginTop: 12 }}>
          رجوع
        </button>
      </section>
    </main>
  );
}
