'use client';

import { useRouter } from 'next/navigation';

const s = {
  page: { minHeight: '100vh', background: '#f5f7fb', padding: 24, direction: 'rtl' as const, fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' },
  hero: { background: '#071226', color: 'white', borderRadius: 34, padding: '48px 32px', maxWidth: 980, margin: '0 auto 24px', boxShadow: '0 24px 80px rgba(7,18,38,.18)' },
  badge: { color: '#f5c75c', fontWeight: 800, letterSpacing: 1 },
  title: { fontSize: 56, lineHeight: 1.05, margin: '14px 0', fontWeight: 900 },
  subtitle: { color: '#cbd5e1', fontSize: 20, lineHeight: 1.8, maxWidth: 760 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: 18, maxWidth: 980, margin: '0 auto' },
  card: { background: 'white', border: '1px solid #e2e8f0', borderRadius: 28, padding: 26, boxShadow: '0 18px 55px rgba(15,23,42,.08)' },
  cardTitle: { fontSize: 30, fontWeight: 900, color: '#0f172a', margin: '0 0 10px' },
  text: { color: '#64748b', fontSize: 17, lineHeight: 1.7 },
  button: { border: 0, borderRadius: 18, padding: '16px 22px', background: '#5b2dac', color: 'white', fontWeight: 900, fontSize: 17, cursor: 'pointer', width: '100%', marginTop: 18 },
  outline: { border: '1px solid #d6b455', borderRadius: 18, padding: '16px 22px', background: '#fff9e8', color: '#7a5611', fontWeight: 900, fontSize: 17, cursor: 'pointer', width: '100%', marginTop: 18 },
};

export default function SawrniAppEntry() {
  const router = useRouter();

  return (
    <main style={s.page}>
      <section style={s.hero}>
        <div style={s.badge}>Sawrni Phase 7.0</div>
        <h1 style={s.title}>تطبيق صورني</h1>
        <p style={s.subtitle}>بداية بناء التطبيق الحقيقي للعملاء ومزودي الخدمة. هذه الواجهة منفصلة عن لوحة الإدارة وتستخدم تسجيل دخول برقم الهاتف.</p>
      </section>

      <section style={s.grid}>
        <article style={s.card}>
          <h2 style={s.cardTitle}>أنا عميل</h2>
          <p style={s.text}>تصفح خدمات التصوير والتعديل والمودلز، ثم احجز الخدمة وادفع العربون لاحقاً عند ربط الدفع الحقيقي.</p>
          <button style={s.button} onClick={() => router.push('/app/login?role=customer')}>الدخول كعميل</button>
        </article>

        <article style={s.card}>
          <h2 style={s.cardTitle}>أنا مزود خدمة</h2>
          <p style={s.text}>سجل كمصور أو محرر أو مودل. لن يظهر حسابك للعملاء إلا بعد موافقة الإدارة/COO من لوحة التحكم.</p>
          <button style={s.outline} onClick={() => router.push('/app/login?role=provider')}>الدخول كمزود خدمة</button>
        </article>
      </section>
    </main>
  );
}
