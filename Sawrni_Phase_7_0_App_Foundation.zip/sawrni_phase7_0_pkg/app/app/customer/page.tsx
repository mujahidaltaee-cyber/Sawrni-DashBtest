'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type HomeData = {
  user?: { name?: string; phone?: string };
  categories?: Array<{ key: string; title_ar: string; title_en: string }>;
  featured_providers?: Array<any>;
  booking_policy?: any;
};

export default function CustomerHome() {
  const router = useRouter();
  const [data, setData] = useState<HomeData>({});
  const [message, setMessage] = useState('');

  async function load() {
    const token = localStorage.getItem('sawrni_app_token');
    if (!token) return router.push('/app');
    const res = await fetch('/api/app-core/customer/home', { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
    const json = await res.json();
    if (!res.ok) {
      setMessage(json.message_ar || json.message_en || 'يرجى تسجيل الدخول.');
      return;
    }
    setData(json);
  }

  useEffect(() => { load(); }, []);

  function logout() {
    localStorage.removeItem('sawrni_app_token');
    localStorage.removeItem('sawrni_app_user');
    router.push('/app');
  }

  return (
    <main style={{ minHeight: '100vh', background: '#f5f7fb', direction: 'rtl', padding: 22, fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' }}>
      <section style={{ background: '#071226', color: 'white', borderRadius: 34, padding: 28, marginBottom: 18 }}>
        <div style={{ color: '#f5c75c', fontWeight: 900 }}>Sawrni Customer App</div>
        <h1 style={{ fontSize: 44, margin: '12px 0' }}>أهلاً {data.user?.name || 'بالعميل'}</h1>
        <p style={{ color: '#cbd5e1', fontSize: 18 }}>ابحث عن مصور أو محرر أو مودل واحجز الخدمة من داخل صورني.</p>
        <button onClick={logout} style={{ border: 0, borderRadius: 16, padding: '13px 18px', background: 'white', color: '#071226', fontWeight: 900 }}>تسجيل الخروج</button>
      </section>

      {message && <div style={{ background: '#fff1f2', color: '#991b1b', border: '1px solid #fecaca', borderRadius: 18, padding: 16, fontWeight: 900 }}>{message}</div>}

      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(210px,1fr))', gap: 14, marginBottom: 18 }}>
        {(data.categories || []).map((c) => (
          <article key={c.key} style={{ background: 'white', borderRadius: 24, padding: 22, border: '1px solid #e2e8f0', boxShadow: '0 16px 40px rgba(15,23,42,.06)' }}>
            <h2 style={{ margin: 0, fontSize: 24, color: '#0f172a' }}>{c.title_ar}</h2>
            <p style={{ color: '#64748b' }}>{c.title_en}</p>
            <button style={{ border: 0, borderRadius: 14, padding: '12px 16px', background: '#5b2dac', color: 'white', fontWeight: 900 }}>استعراض</button>
          </article>
        ))}
      </section>

      <section style={{ background: 'white', borderRadius: 28, padding: 24, border: '1px solid #e2e8f0' }}>
        <h2 style={{ fontSize: 34, margin: '0 0 16px', color: '#0f172a' }}>مزودون متاحون</h2>
        {(data.featured_providers || []).length === 0 ? (
          <p style={{ color: '#64748b', fontSize: 18 }}>لا يوجد مزودون ظاهرون حالياً. سيظهر فقط المزودون الموافق عليهم من الإدارة.</p>
        ) : (data.featured_providers || []).map((p) => (
          <div key={p.id} style={{ border: '1px solid #e2e8f0', borderRadius: 22, padding: 18, marginBottom: 12 }}>
            <b style={{ fontSize: 22 }}>{p.display_name}</b>
            <p style={{ color: '#64748b' }}>{p.city} · {p.category} · Rating {p.rating}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
