'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function SawrniOtpPage() {
  const router = useRouter();
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('customer');
  const [otp, setOtp] = useState('');
  const [preview, setPreview] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const p = localStorage.getItem('sawrni_app_phone') || '';
    const r = localStorage.getItem('sawrni_app_role') || 'customer';
    const pr = localStorage.getItem('sawrni_app_otp_preview') || '';
    setPhone(p);
    setRole(r);
    setPreview(pr);
    if (!p) router.push('/app');
  }, [router]);

  async function verify() {
    setLoading(true);
    setMessage('');
    try {
      const res = await fetch('/api/app-auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, role, otp }),
      });
      const data = await res.json();
      if (!res.ok || data.status !== 'ok') {
        setMessage(data.message_ar || data.message_en || 'رمز غير صحيح.');
        return;
      }
      localStorage.setItem('sawrni_app_token', data.token);
      localStorage.setItem('sawrni_app_user', JSON.stringify(data.user));
      router.push(data.redirect_to || (role === 'provider' ? '/app/provider' : '/app/customer'));
    } catch (e) {
      setMessage('تعذر الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ minHeight: '100vh', background: '#f5f7fb', direction: 'rtl', padding: 24, fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' }}>
      <section style={{ maxWidth: 560, margin: '40px auto', background: 'white', borderRadius: 32, padding: 30, boxShadow: '0 24px 80px rgba(15,23,42,.12)', border: '1px solid #e2e8f0' }}>
        <div style={{ color: '#5b2dac', fontWeight: 900 }}>Phone OTP</div>
        <h1 style={{ fontSize: 42, margin: '12px 0 8px', color: '#0f172a' }}>رمز التحقق</h1>
        <p style={{ color: '#64748b', fontSize: 17, lineHeight: 1.7 }}>تم إرسال الرمز إلى: <b>{phone}</b></p>
        {preview && <p style={{ color: '#7a5611', background: '#fff9e8', border: '1px solid #f5c75c', padding: 12, borderRadius: 16, fontWeight: 900 }}>رمز التطوير: {preview}</p>}

        <input value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="123456" inputMode="numeric" maxLength={6} style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #cbd5e1', borderRadius: 18, padding: '18px 16px', fontSize: 28, textAlign: 'center', letterSpacing: 8, outline: 'none', marginBottom: 16 }} />

        {message && <div style={{ border: '1px solid #fecaca', background: '#fff1f2', color: '#991b1b', borderRadius: 18, padding: 14, marginBottom: 14, fontWeight: 800 }}>{message}</div>}

        <button onClick={verify} disabled={loading || otp.length < 4} style={{ width: '100%', border: 0, borderRadius: 18, padding: '17px 20px', background: loading ? '#94a3b8' : '#5b2dac', color: 'white', fontWeight: 900, fontSize: 18 }}>
          {loading ? 'جاري التحقق...' : 'تأكيد الدخول'}
        </button>
      </section>
    </main>
  );
}
