'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type ProviderData = { user?: any; profile?: any; visibility?: any; next_steps?: Array<any>; business_rules?: any };

export default function ProviderHome() {
  const router = useRouter();
  const [data, setData] = useState<ProviderData>({});
  const [message, setMessage] = useState('');

  async function load() {
    const token = localStorage.getItem('sawrni_app_token');
    if (!token) return router.push('/app');
    const res = await fetch('/api/app-core/provider/home', { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
    const json = await res.json();
    if (!res.ok) {
      setMessage(json.message_ar || json.message_en || 'يرجى تسجيل الدخول كمزود خدمة.');
      return;
    }
    setData(json);
  }

  useEffect(() => { load(); }, []);

  function logout() {
    localStorage.removeItem('sawrni_app_token');
    localStorage.removeItem('sawrni_app_user');
    router.push('/app');
  }

  const profile = data.profile;

  return (
    <main style={{ minHeight: '100vh', background: '#f5f7fb', direction: 'rtl', padding: 22, fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif' }}>
      <section style={{ background: '#071226', color: 'white', borderRadius: 34, padding: 28, marginBottom: 18 }}>
        <div style={{ color: '#f5c75c', fontWeight: 900 }}>Sawrni Provider App</div>
        <h1 style={{ fontSize: 44, margin: '12px 0' }}>مركز مزود الخدمة</h1>
        <p style={{ color: '#cbd5e1', fontSize: 18 }}>حسابك لا يظهر للعملاء قبل موافقة الإدارة/COO.</p>
        <button onClick={logout} style={{ border: 0, borderRadius: 16, padding: '13px 18px', background: 'white', color: '#071226', fontWeight: 900 }}>تسجيل الخروج</button>
      </section>

      {message && <div style={{ background: '#fff1f2', color: '#991b1b', border: '1px solid #fecaca', borderRadius: 18, padding: 16, fontWeight: 900 }}>{message}</div>}

      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(230px,1fr))', gap: 14, marginBottom: 18 }}>
        <article style={{ background: 'white', borderRadius: 24, padding: 22, border: '1px solid #e2e8f0' }}>
          <h2 style={{ margin: 0, color: '#0f172a' }}>حالة الظهور</h2>
          <p style={{ fontSize: 28, fontWeight: 900, color: data.visibility?.is_public ? '#15803d' : '#b45309' }}>{data.visibility?.is_public ? 'ظاهر' : 'مخفي'}</p>
          <p style={{ color: '#64748b' }}>{data.visibility?.reason_ar}</p>
        </article>
        <article style={{ background: 'white', borderRadius: 24, padding: 22, border: '1px solid #e2e8f0' }}>
          <h2 style={{ margin: 0, color: '#0f172a' }}>الخطة</h2>
          <p style={{ fontSize: 28, fontWeight: 900 }}>{profile?.subscription_plan || 'basic'}</p>
          <p style={{ color: '#64748b' }}>حد الدين: {data.business_rules?.debt_threshold_iqd || 75000} IQD</p>
        </article>
        <article style={{ background: 'white', borderRadius: 24, padding: 22, border: '1px solid #e2e8f0' }}>
          <h2 style={{ margin: 0, color: '#0f172a' }}>العمولة</h2>
          <p style={{ fontSize: 28, fontWeight: 900 }}>15%</p>
          <p style={{ color: '#64748b' }}>تحتسب من كامل العملية.</p>
        </article>
      </section>

      <section style={{ background: 'white', borderRadius: 28, padding: 24, border: '1px solid #e2e8f0' }}>
        <h2 style={{ fontSize: 34, margin: '0 0 16px', color: '#0f172a' }}>خطوات إكمال الحساب</h2>
        {(data.next_steps || []).map((step) => (
          <div key={step.key} style={{ border: '1px solid #e2e8f0', borderRadius: 20, padding: 17, marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <b>{step.title_ar}</b>
            <span style={{ color: '#64748b' }}>{step.title_en}</span>
          </div>
        ))}
      </section>
    </main>
  );
}
