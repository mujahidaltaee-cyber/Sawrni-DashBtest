import { NextRequest, NextResponse } from 'next/server';

const API_BASE = process.env.NEXT_PUBLIC_SAWRNI_API_BASE || 'http://127.0.0.1:8010/api/v1';

async function proxy(req: NextRequest, context: { params: { path: string[] } | Promise<{ path: string[] }> }) {
  const params = await Promise.resolve(context.params as any);
  const path = (params?.path || []).join('/');
  const url = new URL(req.url);
  const target = `${API_BASE}/app-auth/${path}${url.search}`;

  const headers: Record<string, string> = { Accept: 'application/json' };
  const auth = req.headers.get('authorization');
  const contentType = req.headers.get('content-type');
  if (auth) headers.Authorization = auth;
  if (contentType) headers['Content-Type'] = contentType;

  const init: RequestInit = { method: req.method, headers, cache: 'no-store' };
  if (!['GET', 'HEAD'].includes(req.method)) init.body = await req.text();

  try {
    const res = await fetch(target, init);
    const body = await res.text();
    return new NextResponse(body, {
      status: res.status,
      headers: { 'Content-Type': res.headers.get('content-type') || 'application/json' },
    });
  } catch (error) {
    return NextResponse.json({ status: 'error', message_en: 'Laravel API unavailable', detail: String(error) }, { status: 502 });
  }
}

export async function GET(req: NextRequest, context: any) { return proxy(req, context); }
export async function POST(req: NextRequest, context: any) { return proxy(req, context); }
export async function PUT(req: NextRequest, context: any) { return proxy(req, context); }
export async function PATCH(req: NextRequest, context: any) { return proxy(req, context); }
export async function DELETE(req: NextRequest, context: any) { return proxy(req, context); }
