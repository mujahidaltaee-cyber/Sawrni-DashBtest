# Sawrni Phase 7.0 — App Foundation

This phase moves Sawrni from admin-only development into real app building.

## Adds

- Customer app entry
- Provider app entry
- Phone OTP login
- Role selection: customer/provider
- Customer home
- Provider home
- Provider hidden until admin/COO approval
- Laravel app auth endpoints
- Laravel app core endpoints
- App sessions, OTPs, audit logs, provider profile base tables
- Next.js proxies for Laravel API

## Apply

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase7_0
unzip -o Sawrni_Phase_7_0_App_Foundation.zip -d _phase7_0
bash _phase7_0/sawrni_phase7_0_pkg/scripts/apply_phase7_0_app_foundation.sh
```

## Run Laravel

```bash
cd /workspaces/Sawrni-DashBtest/_sawrni_phase6/backend-runtime-laravel
lsof -ti tcp:8010 | xargs -r kill -9
php artisan serve --host=0.0.0.0 --port=8010
```

## Run Next.js

```bash
cd /workspaces/Sawrni-DashBtest
lsof -ti tcp:3000 | xargs -r kill -9
npm run dev -- -H 0.0.0.0 -p 3000
```

## Open

- `/app`
- `/app/login?role=customer`
- `/app/login?role=provider`
- `/app/customer`
- `/app/provider`

Development OTP preview is returned only outside production.
