#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(pwd)"
PKG_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_ROOT="$PROJECT_ROOT/_sawrni_phase6/backend-runtime-laravel"

if [ ! -d "$BACKEND_ROOT" ]; then
  echo "ERROR: Laravel backend not found at $BACKEND_ROOT"
  echo "Run this from /workspaces/Sawrni-DashBtest after Phase 6 backend exists."
  exit 1
fi

if [ ! -f "$PROJECT_ROOT/package.json" ]; then
  echo "ERROR: Next.js package.json not found in $PROJECT_ROOT"
  echo "Run this from /workspaces/Sawrni-DashBtest."
  exit 1
fi

echo "Applying Sawrni Phase 7.0 App Foundation..."

mkdir -p "$BACKEND_ROOT/routes" "$BACKEND_ROOT/database/migrations"
cp "$PKG_ROOT/routes/sawrni_phase7_app_foundation.php" "$BACKEND_ROOT/routes/sawrni_phase7_app_foundation.php"
cp "$PKG_ROOT/database/migrations/2026_06_26_000070_create_sawrni_phase7_app_foundation_tables.php" "$BACKEND_ROOT/database/migrations/2026_06_26_000070_create_sawrni_phase7_app_foundation_tables.php"

python3 - <<'PY'
from pathlib import Path
api = Path('_sawrni_phase6/backend-runtime-laravel/routes/api.php')
text = api.read_text() if api.exists() else '<?php\n'
line = "require __DIR__ . '/sawrni_phase7_app_foundation.php';\n"
if line not in text:
    if not text.startswith('<?php'):
        text = '<?php\n' + text
    text = text.rstrip() + "\n\n" + line
api.write_text(text)
print('Phase 7.0 Laravel route registered in routes/api.php')
PY

mkdir -p "$PROJECT_ROOT/app/app" "$PROJECT_ROOT/app/api"
cp -R "$PKG_ROOT/app/app" "$PROJECT_ROOT/app/"
mkdir -p "$PROJECT_ROOT/app/api/app-auth" "$PROJECT_ROOT/app/api/app-core"
cp -R "$PKG_ROOT/app/api/app-auth" "$PROJECT_ROOT/app/api/"
cp -R "$PKG_ROOT/app/api/app-core" "$PROJECT_ROOT/app/api/"

if [ ! -f "$PROJECT_ROOT/.env.local" ]; then
  touch "$PROJECT_ROOT/.env.local"
fi
if ! grep -q '^NEXT_PUBLIC_SAWRNI_API_BASE=' "$PROJECT_ROOT/.env.local"; then
  echo 'NEXT_PUBLIC_SAWRNI_API_BASE=http://127.0.0.1:8010/api/v1' >> "$PROJECT_ROOT/.env.local"
fi

cd "$BACKEND_ROOT"
php artisan optimize:clear || true
php artisan route:clear || true
php artisan config:clear || true
php artisan migrate --force

echo "DONE: Sawrni Phase 7.0 App Foundation applied."
echo "Next pages added: /app, /app/login, /app/otp, /app/customer, /app/provider"
echo "Laravel endpoints added: /api/v1/app-auth/* and /api/v1/app-core/*"
