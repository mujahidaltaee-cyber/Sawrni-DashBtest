<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use Throwable;

function sawrni_70_now()
{
    return now();
}

function sawrni_70_phone($value): string
{
    $phone = preg_replace('/[^0-9+]/', '', (string) $value);
    return substr($phone, 0, 20);
}

function sawrni_70_role($value): string
{
    return in_array($value, ['customer', 'provider'], true) ? $value : 'customer';
}

function sawrni_70_audit(?object $user, string $eventType, array $metadata = [], ?Request $request = null): void
{
    try {
        DB::table('sawrni_app_audit_logs')->insert([
            'user_id' => $user->id ?? null,
            'phone' => $user->phone ?? null,
            'role' => $user->role ?? null,
            'event_type' => $eventType,
            'metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE),
            'ip_address' => $request?->ip(),
            'user_agent' => substr((string) $request?->userAgent(), 0, 255),
            'created_at' => sawrni_70_now(),
            'updated_at' => sawrni_70_now(),
        ]);
    } catch (Throwable $e) {
        // Audit logging must never break the app flow.
    }
}

function sawrni_70_auth(Request $request, ?string $requiredRole = null)
{
    $header = (string) $request->header('Authorization', '');

    if (!str_starts_with($header, 'Bearer ')) {
        return response()->json([
            'status' => 'error',
            'message_ar' => 'يرجى تسجيل الدخول.',
            'message_en' => 'Please login first.',
        ], 401);
    }

    $token = trim(substr($header, 7));

    if ($token === '') {
        return response()->json([
            'status' => 'error',
            'message_ar' => 'جلسة غير صالحة.',
            'message_en' => 'Invalid session.',
        ], 401);
    }

    $session = DB::table('sawrni_app_sessions')
        ->where('token_hash', hash('sha256', $token))
        ->whereNull('revoked_at')
        ->where(function ($q) {
            $q->whereNull('expires_at')->orWhere('expires_at', '>', sawrni_70_now());
        })
        ->first();

    if (!$session) {
        return response()->json([
            'status' => 'error',
            'message_ar' => 'انتهت الجلسة أو غير صالحة.',
            'message_en' => 'Session expired or invalid.',
        ], 401);
    }

    $user = DB::table('sawrni_app_users')->where('id', $session->user_id)->first();

    if (!$user) {
        return response()->json([
            'status' => 'error',
            'message_ar' => 'المستخدم غير موجود.',
            'message_en' => 'User not found.',
        ], 404);
    }

    if ($requiredRole && $user->role !== $requiredRole) {
        return response()->json([
            'status' => 'error',
            'message_ar' => 'لا تملك صلاحية لهذا القسم.',
            'message_en' => 'You do not have permission for this section.',
        ], 403);
    }

    DB::table('sawrni_app_sessions')->where('id', $session->id)->update([
        'last_used_at' => sawrni_70_now(),
        'updated_at' => sawrni_70_now(),
    ]);

    return [$user, $session];
}

Route::prefix('/v1/app-auth')->group(function () {
    Route::get('/config', function () {
        return response()->json([
            'status' => 'ok',
            'phase' => '7.0',
            'app' => 'Sawrni',
            'login' => [
                'method' => 'phone_otp',
                'email_optional' => true,
                'roles' => ['customer', 'provider'],
            ],
            'production_rules' => [
                'providers_hidden_until_approval' => true,
                'commission_rate' => 0.15,
                'debt_threshold_iqd' => 75000,
            ],
        ]);
    });

    Route::post('/request-otp', function (Request $request) {
        $phone = sawrni_70_phone($request->input('phone'));
        $role = sawrni_70_role($request->input('role', 'customer'));

        if (strlen($phone) < 8) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'رقم الهاتف غير صحيح.',
                'message_en' => 'Invalid phone number.',
            ], 422);
        }

        $recentCount = DB::table('sawrni_app_otps')
            ->where('phone', $phone)
            ->where('created_at', '>=', sawrni_70_now()->subMinutes(10))
            ->count();

        if ($recentCount >= 20) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'محاولات كثيرة. يرجى الانتظار قليلاً.',
                'message_en' => 'Too many attempts. Please wait briefly.',
            ], 429);
        }

        $otp = app()->environment('production') ? (string) random_int(100000, 999999) : '123456';

        DB::table('sawrni_app_otps')->where('phone', $phone)->where('role', $role)->where('status', 'pending')->update([
            'status' => 'replaced',
            'updated_at' => sawrni_70_now(),
        ]);

        DB::table('sawrni_app_otps')->insert([
            'phone' => $phone,
            'role' => $role,
            'purpose' => 'login',
            'otp_hash' => Hash::make($otp),
            'attempts' => 0,
            'status' => 'pending',
            'expires_at' => sawrni_70_now()->addMinutes(10),
            'consumed_at' => null,
            'created_at' => sawrni_70_now(),
            'updated_at' => sawrni_70_now(),
        ]);

        $payload = [
            'status' => 'ok',
            'message_ar' => 'تم إرسال رمز التحقق.',
            'message_en' => 'OTP has been sent.',
            'expires_in_seconds' => 600,
            'phase' => '7.0',
        ];

        if (!app()->environment('production')) {
            $payload['otp_preview'] = $otp;
        }

        return response()->json($payload);
    });

    Route::post('/verify-otp', function (Request $request) {
        $phone = sawrni_70_phone($request->input('phone'));
        $role = sawrni_70_role($request->input('role', 'customer'));
        $otp = (string) $request->input('otp', '');

        $otpRow = DB::table('sawrni_app_otps')
            ->where('phone', $phone)
            ->where('role', $role)
            ->where('status', 'pending')
            ->where('expires_at', '>', sawrni_70_now())
            ->latest('id')
            ->first();

        if (!$otpRow) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'رمز التحقق منتهي أو غير موجود.',
                'message_en' => 'OTP expired or not found.',
            ], 422);
        }

        if (!Hash::check($otp, $otpRow->otp_hash)) {
            DB::table('sawrni_app_otps')->where('id', $otpRow->id)->increment('attempts');
            return response()->json([
                'status' => 'error',
                'message_ar' => 'رمز التحقق غير صحيح.',
                'message_en' => 'Invalid OTP.',
            ], 422);
        }

        DB::table('sawrni_app_otps')->where('id', $otpRow->id)->update([
            'status' => 'consumed',
            'consumed_at' => sawrni_70_now(),
            'updated_at' => sawrni_70_now(),
        ]);

        $existing = DB::table('sawrni_app_users')->where('phone', $phone)->where('role', $role)->first();

        if ($existing) {
            $userId = $existing->id;
            DB::table('sawrni_app_users')->where('id', $userId)->update([
                'phone_verified_at' => $existing->phone_verified_at ?: sawrni_70_now(),
                'updated_at' => sawrni_70_now(),
            ]);
        } else {
            $userId = DB::table('sawrni_app_users')->insertGetId([
                'phone' => $phone,
                'display_name' => $role === 'provider' ? 'New Provider' : 'Customer',
                'email' => null,
                'role' => $role,
                'status' => 'active',
                'phone_verified_at' => sawrni_70_now(),
                'metadata' => json_encode(['phase' => '7.0'], JSON_UNESCAPED_UNICODE),
                'created_at' => sawrni_70_now(),
                'updated_at' => sawrni_70_now(),
            ]);
        }

        $user = DB::table('sawrni_app_users')->where('id', $userId)->first();

        if ($role === 'provider') {
            $hasProfile = DB::table('sawrni_app_provider_profiles')->where('user_id', $userId)->exists();
            if (!$hasProfile) {
                DB::table('sawrni_app_provider_profiles')->insert([
                    'user_id' => $userId,
                    'phone' => $phone,
                    'display_name' => 'New Provider',
                    'provider_type' => 'photographer',
                    'category' => 'photography',
                    'city' => 'Baghdad',
                    'subscription_plan' => 'basic',
                    'approval_status' => 'pending',
                    'debt_balance_iqd' => 0,
                    'is_suspended' => false,
                    'rating' => 0,
                    'bio' => null,
                    'metadata' => json_encode(['created_from' => 'app_otp_login', 'phase' => '7.0'], JSON_UNESCAPED_UNICODE),
                    'created_at' => sawrni_70_now(),
                    'updated_at' => sawrni_70_now(),
                ]);
            }
        }

        $token = 'sawrni-app-' . Str::random(80);

        DB::table('sawrni_app_sessions')->insert([
            'user_id' => $userId,
            'phone' => $phone,
            'role' => $role,
            'token_hash' => hash('sha256', $token),
            'device_name' => substr((string) $request->userAgent(), 0, 255),
            'last_used_at' => sawrni_70_now(),
            'expires_at' => sawrni_70_now()->addDays(30),
            'revoked_at' => null,
            'created_at' => sawrni_70_now(),
            'updated_at' => sawrni_70_now(),
        ]);

        sawrni_70_audit($user, 'app_login', ['role' => $role], $request);

        return response()->json([
            'status' => 'ok',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'phone' => $user->phone,
                'name' => $user->display_name,
                'role' => $user->role,
            ],
            'redirect_to' => $role === 'provider' ? '/app/provider' : '/app/customer',
            'phase' => '7.0',
        ]);
    });

    Route::get('/me', function (Request $request) {
        $auth = sawrni_70_auth($request);
        if ($auth instanceof \Illuminate\Http\JsonResponse) return $auth;
        [$user, $session] = $auth;

        return response()->json([
            'status' => 'ok',
            'user' => [
                'id' => $user->id,
                'phone' => $user->phone,
                'name' => $user->display_name,
                'role' => $user->role,
                'status' => $user->status,
            ],
            'session' => [
                'expires_at' => $session->expires_at,
            ],
        ]);
    });

    Route::post('/logout', function (Request $request) {
        $header = (string) $request->header('Authorization', '');
        if (str_starts_with($header, 'Bearer ')) {
            $token = trim(substr($header, 7));
            DB::table('sawrni_app_sessions')->where('token_hash', hash('sha256', $token))->update([
                'revoked_at' => sawrni_70_now(),
                'updated_at' => sawrni_70_now(),
            ]);
        }

        return response()->json(['status' => 'ok']);
    });
});

Route::prefix('/v1/app-core')->group(function () {
    Route::get('/customer/home', function (Request $request) {
        $auth = sawrni_70_auth($request, 'customer');
        if ($auth instanceof \Illuminate\Http\JsonResponse) return $auth;
        [$user] = $auth;

        $providers = DB::table('sawrni_app_provider_profiles')
            ->where('approval_status', 'approved')
            ->where('is_suspended', false)
            ->orderByDesc('rating')
            ->limit(10)
            ->get(['id', 'display_name', 'provider_type', 'category', 'city', 'subscription_plan', 'rating', 'bio']);

        return response()->json([
            'status' => 'ok',
            'phase' => '7.0',
            'user' => [
                'name' => $user->display_name,
                'phone' => $user->phone,
            ],
            'categories' => [
                ['key' => 'graduation', 'title_ar' => 'تصوير تخرج', 'title_en' => 'Graduation photography'],
                ['key' => 'wedding', 'title_ar' => 'تصوير أعراس', 'title_en' => 'Wedding photography'],
                ['key' => 'editing', 'title_ar' => 'تعديل صور', 'title_en' => 'Photo editing'],
                ['key' => 'models', 'title_ar' => 'مودلز', 'title_en' => 'Models'],
            ],
            'featured_providers' => $providers,
            'booking_policy' => [
                'platform_commission_rate' => 0.15,
                'customer_edit_window_hours_after_deposit' => 3,
                'customer_cancel_window_hours_after_deposit' => 1,
                'deposit_nonrefundable_after_cancel_window' => true,
            ],
        ]);
    });

    Route::get('/provider/home', function (Request $request) {
        $auth = sawrni_70_auth($request, 'provider');
        if ($auth instanceof \Illuminate\Http\JsonResponse) return $auth;
        [$user] = $auth;

        $profile = DB::table('sawrni_app_provider_profiles')->where('user_id', $user->id)->first();

        return response()->json([
            'status' => 'ok',
            'phase' => '7.0',
            'user' => [
                'name' => $user->display_name,
                'phone' => $user->phone,
            ],
            'profile' => $profile,
            'visibility' => [
                'is_public' => $profile && $profile->approval_status === 'approved' && !$profile->is_suspended,
                'reason_ar' => (!$profile || $profile->approval_status !== 'approved') ? 'لن يظهر حسابك للعملاء قبل موافقة الإدارة.' : 'حسابك ظاهر للعملاء.',
                'reason_en' => (!$profile || $profile->approval_status !== 'approved') ? 'Your account is hidden until admin approval.' : 'Your account is visible to customers.',
            ],
            'next_steps' => [
                ['key' => 'complete_profile', 'title_ar' => 'إكمال الملف الشخصي', 'title_en' => 'Complete profile'],
                ['key' => 'portfolio', 'title_ar' => 'إضافة أعمال سابقة', 'title_en' => 'Add portfolio'],
                ['key' => 'subscription', 'title_ar' => 'اختيار الاشتراك', 'title_en' => 'Select subscription'],
                ['key' => 'approval', 'title_ar' => 'انتظار موافقة الإدارة', 'title_en' => 'Wait for admin approval'],
            ],
            'business_rules' => [
                'commission_rate' => 0.15,
                'debt_threshold_iqd' => 75000,
                'provider_hidden_until_approval' => true,
            ],
        ]);
    });
});
