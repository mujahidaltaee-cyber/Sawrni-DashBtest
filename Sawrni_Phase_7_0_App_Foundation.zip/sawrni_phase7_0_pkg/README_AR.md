# صورني Phase 7.0 — أساس التطبيق الحقيقي

هذه المرحلة تنقل صورني من لوحة الإدارة فقط إلى بناء التطبيق الحقيقي.

## المضاف

- واجهة دخول العميل
- واجهة دخول مزود الخدمة
- تسجيل دخول برقم الهاتف ورمز OTP
- اختيار الدور: عميل / مزود خدمة
- صفحة العميل الرئيسية
- صفحة مزود الخدمة الرئيسية
- إخفاء مزود الخدمة حتى موافقة الإدارة/COO
- نقاط API حقيقية للتطبيق
- جلسات التطبيق، رموز OTP، سجلات تدقيق، وجداول مزودي الخدمة الأساسية
- ربط Next.js مع Laravel عبر proxy

## التطبيق

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase7_0
unzip -o Sawrni_Phase_7_0_App_Foundation.zip -d _phase7_0
bash _phase7_0/sawrni_phase7_0_pkg/scripts/apply_phase7_0_app_foundation.sh
```

## تشغيل Laravel

```bash
cd /workspaces/Sawrni-DashBtest/_sawrni_phase6/backend-runtime-laravel
lsof -ti tcp:8010 | xargs -r kill -9
php artisan serve --host=0.0.0.0 --port=8010
```

## تشغيل Next.js

```bash
cd /workspaces/Sawrni-DashBtest
lsof -ti tcp:3000 | xargs -r kill -9
npm run dev -- -H 0.0.0.0 -p 3000
```

## الصفحات

- `/app`
- `/app/login?role=customer`
- `/app/login?role=provider`
- `/app/customer`
- `/app/provider`

رمز OTP التجريبي يظهر فقط خارج بيئة الإنتاج.
