<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('sawrni_app_users')) {
            Schema::create('sawrni_app_users', function (Blueprint $table) {
                $table->id();
                $table->string('phone')->unique();
                $table->string('display_name')->nullable();
                $table->string('email')->nullable();
                $table->string('role')->default('customer')->index(); // customer | provider
                $table->string('status')->default('active')->index();
                $table->timestamp('phone_verified_at')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_app_otps')) {
            Schema::create('sawrni_app_otps', function (Blueprint $table) {
                $table->id();
                $table->string('phone')->index();
                $table->string('role')->default('customer')->index();
                $table->string('purpose')->default('login')->index();
                $table->string('otp_hash');
                $table->unsignedInteger('attempts')->default(0);
                $table->string('status')->default('pending')->index();
                $table->timestamp('expires_at')->nullable();
                $table->timestamp('consumed_at')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_app_sessions')) {
            Schema::create('sawrni_app_sessions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('phone')->nullable()->index();
                $table->string('role')->nullable()->index();
                $table->string('token_hash')->unique();
                $table->string('device_name')->nullable();
                $table->timestamp('last_used_at')->nullable();
                $table->timestamp('expires_at')->nullable();
                $table->timestamp('revoked_at')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_app_audit_logs')) {
            Schema::create('sawrni_app_audit_logs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('phone')->nullable()->index();
                $table->string('role')->nullable()->index();
                $table->string('event_type')->index();
                $table->json('metadata')->nullable();
                $table->string('ip_address')->nullable();
                $table->string('user_agent')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_app_provider_profiles')) {
            Schema::create('sawrni_app_provider_profiles', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('phone')->nullable()->index();
                $table->string('display_name');
                $table->string('provider_type')->default('photographer')->index();
                $table->string('category')->default('photography')->index();
                $table->string('city')->default('Baghdad')->index();
                $table->string('subscription_plan')->default('basic')->index();
                $table->string('approval_status')->default('pending')->index();
                $table->unsignedBigInteger('debt_balance_iqd')->default(0);
                $table->boolean('is_suspended')->default(false);
                $table->decimal('rating', 3, 2)->default(0);
                $table->text('bio')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('sawrni_app_provider_profiles');
        Schema::dropIfExists('sawrni_app_audit_logs');
        Schema::dropIfExists('sawrni_app_sessions');
        Schema::dropIfExists('sawrni_app_otps');
        Schema::dropIfExists('sawrni_app_users');
    }
};
