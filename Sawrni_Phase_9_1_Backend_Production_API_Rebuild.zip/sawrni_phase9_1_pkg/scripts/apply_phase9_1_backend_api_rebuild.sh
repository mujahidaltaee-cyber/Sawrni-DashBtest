#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend-laravel"
PHP_BIN="/usr/bin/php8.3"

if [ ! -x "$PHP_BIN" ]; then
  PHP_BIN="$(command -v php || true)"
fi

if [ -z "$PHP_BIN" ]; then
  echo "ERROR: PHP is not available. Install PHP 8.3 first."
  exit 1
fi

PHP_VERSION="$($PHP_BIN -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
echo "Using PHP: $PHP_BIN ($PHP_VERSION)"

COMPOSER_BIN="$(command -v composer || true)"
if [ -z "$COMPOSER_BIN" ]; then
  echo "ERROR: Composer not found."
  exit 1
fi

mkdir -p "$ROOT/_archive_old_phases"

if [ -d "$ROOT/backend" ] && [ ! -d "$ROOT/backend_partial_restore" ]; then
  mv "$ROOT/backend" "$ROOT/backend_partial_restore" || true
fi

if [ -d "$BACKEND" ] && [ ! -f "$BACKEND/artisan" ]; then
  mv "$BACKEND" "$ROOT/_archive_old_phases/backend-laravel-broken-$(date +%Y%m%d%H%M%S)"
fi

if [ ! -f "$BACKEND/artisan" ]; then
  echo "Creating clean Laravel backend at backend-laravel..."
  rm -rf "$BACKEND"
  "$PHP_BIN" "$COMPOSER_BIN" create-project laravel/laravel "$BACKEND" --no-interaction
else
  echo "Laravel backend already exists; applying Sawrni API files."
fi

cd "$BACKEND"

# Remove default user migration to avoid conflict with Sawrni unified users table.
find database/migrations -type f -name '*create_users_table.php' -delete || true

mkdir -p routes database/migrations database/seeders config
cp "$PKG_DIR/backend-files/routes/api.php" routes/api.php
cp "$PKG_DIR/backend-files/database/migrations/2026_06_27_090100_create_sawrni_core_tables.php" database/migrations/2026_06_27_090100_create_sawrni_core_tables.php
cp "$PKG_DIR/backend-files/database/seeders/SawrniProductionSeeder.php" database/seeders/SawrniProductionSeeder.php
cp "$PKG_DIR/backend-files/database/seeders/DatabaseSeeder.php" database/seeders/DatabaseSeeder.php
cp "$PKG_DIR/backend-files/config/cors.php" config/cors.php

# Enable routes/api.php for Laravel 11/12/13 style bootstrap.
if [ -f bootstrap/app.php ]; then
  "$PHP_BIN" -r '
  $p="bootstrap/app.php";
  $text=file_get_contents($p);
  if (strpos($text, "routes/api.php") === false) {
      $text=str_replace("web: __DIR__.'/../routes/web.php',", "web: __DIR__.'/../routes/web.php',\n        api: __DIR__.'/../routes/api.php',", $text);
  }
  file_put_contents($p,$text);
  echo "API route loading enabled.\n";
  '
fi

# Configure staging SQLite by default. Production should replace with PostgreSQL env.
if [ ! -f .env ]; then
  cp .env.example .env
fi
mkdir -p database
touch database/database.sqlite

"$PHP_BIN" -r '
$p=".env";
$text=file_get_contents($p);
$replacements = [
  "APP_NAME=Laravel" => "APP_NAME=Sawrni",
  "APP_ENV=local" => "APP_ENV=local",
  "APP_DEBUG=true" => "APP_DEBUG=true",
  "DB_CONNECTION=mysql" => "DB_CONNECTION=sqlite",
  "DB_HOST=127.0.0.1" => "# DB_HOST=127.0.0.1",
  "DB_PORT=3306" => "# DB_PORT=3306",
  "DB_DATABASE=laravel" => "# DB_DATABASE=laravel",
  "DB_USERNAME=root" => "# DB_USERNAME=root",
  "DB_PASSWORD=" => "# DB_PASSWORD=",
  "SESSION_DRIVER=database" => "SESSION_DRIVER=file",
  "CACHE_STORE=database" => "CACHE_STORE=file",
  "QUEUE_CONNECTION=database" => "QUEUE_CONNECTION=sync",
];
foreach ($replacements as $old=>$new) { $text=str_replace($old,$new,$text); }
file_put_contents($p,$text);
echo "Configured backend .env for staging SQLite.\n";
'

"$PHP_BIN" "$COMPOSER_BIN" install --no-interaction
"$PHP_BIN" artisan key:generate --force
"$PHP_BIN" artisan migrate:fresh --seed --force
"$PHP_BIN" artisan route:list | grep 'api/v1' | head -80 || true

mkdir -p "$ROOT/docs"
cp "$PKG_DIR/docs/PHASE_9_1_BACKEND_API_REBUILD.md" "$ROOT/docs/PHASE_9_1_BACKEND_API_REBUILD.md"

mkdir -p "$ROOT/tests/e2e"
cp "$PKG_DIR/tests/e2e/phase9_1_api_smoke.sh" "$ROOT/tests/e2e/phase9_1_api_smoke.sh"
chmod +x "$ROOT/tests/e2e/phase9_1_api_smoke.sh"

echo "PASS: Phase 9.1 backend production API rebuild applied."
echo "Next: cd backend-laravel && $PHP_BIN artisan serve --host=0.0.0.0 --port=8010"
