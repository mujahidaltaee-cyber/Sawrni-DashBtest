# Sawrni — Phase 9.1 Backend Production API Rebuild

This phase builds the real staging backend foundation according to the frozen SRS, UI/UX, and Database/API Blueprint.

## Apply

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase9_1
unzip -o Sawrni_Phase_9_1_Backend_Production_API_Rebuild.zip -d _phase9_1
bash _phase9_1/sawrni_phase9_1_pkg/scripts/apply_phase9_1_backend_api_rebuild.sh
```

Then start the backend:

```bash
cd /workspaces/Sawrni-DashBtest/backend-laravel
/usr/bin/php8.3 artisan serve --host=0.0.0.0 --port=8010
```

## Test users

- Super Admin: `07000000000` / `password`
- COO/Admin: `07000000010` / `password`
- Customer: `07000000001` / `password`
- Approved Provider: `07000000002` / `password`
- Pending Provider: `07000000003` / `password`

Staging OTP: `123456`.
