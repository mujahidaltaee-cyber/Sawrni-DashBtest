# صورني — Phase 9.1 Backend Production API Rebuild

هذه المرحلة تبني أساس الباك إند الحقيقي للـ staging حسب وثائق SRS و UI/UX و Database/API Blueprint.

## التشغيل

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase9_1
unzip -o Sawrni_Phase_9_1_Backend_Production_API_Rebuild.zip -d _phase9_1
bash _phase9_1/sawrni_phase9_1_pkg/scripts/apply_phase9_1_backend_api_rebuild.sh
```

بعدها شغل الباك إند:

```bash
cd /workspaces/Sawrni-DashBtest/backend-laravel
/usr/bin/php8.3 artisan serve --host=0.0.0.0 --port=8010
```

## حسابات التجربة

- Super Admin: `07000000000` / `password`
- COO/Admin: `07000000010` / `password`
- Customer: `07000000001` / `password`
- Provider approved: `07000000002` / `password`
- Provider pending: `07000000003` / `password`

OTP للتجربة: `123456`.
