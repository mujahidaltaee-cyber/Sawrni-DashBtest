# Sawrni Phase 9.1 v4 — Backend Production API Rebuild

This is a corrected full package, not a fragment fix.

v4 fixes the v3 failure where Laravel attempted to run `php artisan key:generate` before `vendor/autoload.php` existed.

Core corrections:
- Force PHP 8.3 directly.
- Use local Composer PHAR.
- Create Laravel with `--no-install --no-scripts`.
- Install dependencies with `--prefer-source --no-scripts`.
- Run artisan only after dependencies exist.

Use v4 only. Ignore previous Phase 9.1 packages.
