# صورني Phase 9.1 v4 — إعادة بناء الباك إند الإنتاجي

هذه نسخة كاملة مصححة وليست إصلاحًا جزئيًا.

تعالج المشكلة التي ظهرت في v3 عندما حاول Laravel تشغيل `php artisan key:generate` قبل تثبيت `vendor/autoload.php`.

التصحيح الأساسي في v4:
- استخدام PHP 8.3 مباشرة.
- استخدام Composer PHAR محلي.
- إنشاء Laravel بـ `--no-install --no-scripts`.
- تثبيت الاعتماديات بـ `--prefer-source --no-scripts`.
- بعدها فقط يتم تشغيل artisan وتطبيق مخطط صورني.

استخدم v4 فقط وتجاهل نسخ Phase 9.1 القديمة.
