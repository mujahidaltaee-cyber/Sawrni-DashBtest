#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend-laravel"
TOOLS="$ROOT/.sawrni-tools"
PHP_BIN="/usr/bin/php8.3"
COMPOSER_PHAR="$TOOLS/composer.phar"

mkdir -p "$TOOLS"

echo "=== Sawrni Phase 9.1 v4: production backend rebuild ==="
echo "Root: $ROOT"

# 1) Ensure PHP 8.3+ is actually used, not Codespaces old /home/codespace/.php/current/bin/php.
if [ ! -x "$PHP_BIN" ]; then
  echo "PHP 8.3 not found at /usr/bin/php8.3. Installing PHP 8.3 runtime packages..."
  sudo apt-get update
  sudo apt-get install -y software-properties-common ca-certificates lsb-release apt-transport-https curl git unzip zip
  sudo add-apt-repository ppa:ondrej/php -y || true
  sudo apt-get update
  sudo apt-get install -y php8.3 php8.3-cli php8.3-common php8.3-mbstring php8.3-xml php8.3-curl php8.3-sqlite3 php8.3-zip php8.3-bcmath php8.3-tokenizer php8.3-dom php8.3-fileinfo
fi

if [ ! -x "$PHP_BIN" ]; then
  echo "ERROR: /usr/bin/php8.3 is still not available. Stop here; backend cannot be built correctly."
  exit 1
fi

PHP_VERSION="$($PHP_BIN -r 'echo PHP_VERSION;')"
PHP_MAJOR_MINOR="$($PHP_BIN -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
echo "Using PHP binary: $PHP_BIN"
echo "Using PHP version: $PHP_VERSION"

$PHP_BIN -r 'exit((PHP_MAJOR_VERSION > 8 || (PHP_MAJOR_VERSION == 8 && PHP_MINOR_VERSION >= 3)) ? 0 : 1);' || {
  echo "ERROR: PHP 8.3+ is required. Current: $PHP_VERSION"
  exit 1
}

# 2) Use a local Composer PHAR executed by PHP 8.3 directly. Do not trust the global composer shebang.
if [ ! -f "$COMPOSER_PHAR" ]; then
  echo "Downloading local Composer PHAR..."
  curl -L --retry 5 --retry-delay 3 -o "$COMPOSER_PHAR" https://getcomposer.org/download/latest-stable/composer.phar
fi

$PHP_BIN "$COMPOSER_PHAR" --version

# 3) Harden Composer/Git for GitHub Codespaces network instability.
#    The previous failures came from old PHP paths, GitHub codeload instability, and Laravel post-create-project scripts running before dependencies. v4 disables create/install scripts until vendor is installed.
git config --global http.version HTTP/1.1 || true
git config --global core.compression 0 || true
export COMPOSER_HOME="$TOOLS/composer-home"
export COMPOSER_CACHE_DIR="$TOOLS/composer-cache"
export COMPOSER_PROCESS_TIMEOUT=2000
export GIT_TERMINAL_PROMPT=0
mkdir -p "$COMPOSER_HOME" "$COMPOSER_CACHE_DIR"

$PHP_BIN "$COMPOSER_PHAR" config --global preferred-install source || true
$PHP_BIN "$COMPOSER_PHAR" config --global github-protocols https || true
$PHP_BIN "$COMPOSER_PHAR" config --global audit.block-insecure false || true
$PHP_BIN "$COMPOSER_PHAR" clear-cache || true

mkdir -p "$ROOT/_archive_old_phases"

# Archive old backend fragments; production path uses backend-laravel only.
if [ -d "$ROOT/backend" ]; then
  ts="$(date +%Y%m%d%H%M%S)"
  mv "$ROOT/backend" "$ROOT/_archive_old_phases/backend-old-$ts" || true
fi
if [ -d "$BACKEND" ]; then
  ts="$(date +%Y%m%d%H%M%S)"
  mv "$BACKEND" "$ROOT/_archive_old_phases/backend-laravel-old-$ts" || true
fi

# 4) Create Laravel skeleton without installing dependencies first.
#    Then install dependencies with --prefer-source and retries.
echo "Creating clean Laravel skeleton at backend-laravel without dependency install and without scripts..."
rm -rf "$BACKEND"
# IMPORTANT: --no-scripts prevents Laravel's post-create-project command from running `php artisan key:generate`
# before vendor/autoload.php exists. This is the exact failure fixed in v4.
$PHP_BIN "$COMPOSER_PHAR" create-project laravel/laravel "$BACKEND" --no-install --no-scripts --no-interaction --no-audit

cd "$BACKEND"

install_ok=0
for attempt in 1 2 3; do
  echo "Composer install attempt $attempt/3 using PHP 8.3, no scripts, and source-preferred packages..."
  if $PHP_BIN "$COMPOSER_PHAR" install --no-interaction --no-progress --no-audit --prefer-source --no-scripts; then
    install_ok=1
    break
  fi
  echo "Composer install attempt $attempt failed. Clearing cache and retrying..."
  $PHP_BIN "$COMPOSER_PHAR" clear-cache || true
  rm -rf vendor composer.lock
  sleep 5
  git config --global http.version HTTP/1.1 || true
done

if [ "$install_ok" != "1" ]; then
  echo "ERROR: Composer dependency installation failed after 3 attempts."
  echo "This is a network/dependency download problem, not a Sawrni code fragment issue."
  echo "No partial backend will be accepted. Re-run this v4 installer after network stabilizes."
  exit 1
fi

# 5) Apply Sawrni production-staging backend files from the frozen Phase 3 blueprint.
find database/migrations -type f -name '*create_users_table.php' -delete || true

mkdir -p routes database/migrations database/seeders config
cp "$PKG_DIR/backend-files/routes/api.php" routes/api.php
cp "$PKG_DIR/backend-files/database/migrations/2026_06_27_090100_create_sawrni_core_tables.php" database/migrations/2026_06_27_090100_create_sawrni_core_tables.php
cp "$PKG_DIR/backend-files/database/seeders/SawrniProductionSeeder.php" database/seeders/SawrniProductionSeeder.php
cp "$PKG_DIR/backend-files/database/seeders/DatabaseSeeder.php" database/seeders/DatabaseSeeder.php
cp "$PKG_DIR/backend-files/config/cors.php" config/cors.php

# Enable routes/api.php for Laravel 11/12/13 style bootstrap.
if [ -f bootstrap/app.php ]; then
  $PHP_BIN -r '
  $p="bootstrap/app.php";
  $text=file_get_contents($p);
  if (strpos($text, "routes/api.php") === false) {
      $text=str_replace("web: __DIR__.\'/../routes/web.php\',", "web: __DIR__.\'/../routes/web.php\',\n        api: __DIR__.\'/../routes/api.php\',", $text);
  }
  file_put_contents($p,$text);
  echo "API route loading enabled.\n";
  '
fi

# Configure staging SQLite by default. Production must replace with PostgreSQL env.
if [ ! -f .env ]; then
  cp .env.example .env
fi
mkdir -p database
touch database/database.sqlite

$PHP_BIN -r '
$p=".env";
$text=file_get_contents($p);
$replacements = [
  "APP_NAME=Laravel" => "APP_NAME=Sawrni",
  "APP_ENV=local" => "APP_ENV=local",
  "APP_DEBUG=true" => "APP_DEBUG=true",
  "DB_CONNECTION=mysql" => "DB_CONNECTION=sqlite",
  "DB_HOST=127.0.0.1" => "# DB_HOST=127.0.0.1",
  "DB_PORT=3306" => "# DB_PORT=3306",
  "DB_DATABASE=laravel" => "# DB_DATABASE=laravel",
  "DB_USERNAME=root" => "# DB_USERNAME=root",
  "DB_PASSWORD=" => "# DB_PASSWORD=",
  "SESSION_DRIVER=database" => "SESSION_DRIVER=file",
  "CACHE_STORE=database" => "CACHE_STORE=file",
  "QUEUE_CONNECTION=database" => "QUEUE_CONNECTION=sync",
];
foreach ($replacements as $old=>$new) { $text=str_replace($old,$new,$text); }
file_put_contents($p,$text);
echo "Configured backend .env for staging SQLite.\n";
'

$PHP_BIN artisan key:generate --force
$PHP_BIN artisan migrate:fresh --seed --force
$PHP_BIN artisan route:list | grep 'api/v1' | head -80 || true

mkdir -p "$ROOT/docs"
cp "$PKG_DIR/docs/PHASE_9_1_BACKEND_API_REBUILD.md" "$ROOT/docs/PHASE_9_1_BACKEND_API_REBUILD.md"

mkdir -p "$ROOT/tests/e2e"
cp "$PKG_DIR/tests/e2e/phase9_1_api_smoke.sh" "$ROOT/tests/e2e/phase9_1_api_smoke.sh"
chmod +x "$ROOT/tests/e2e/phase9_1_api_smoke.sh"

cat > "$ROOT/docs/PHASE_9_1_V4_INSTALLER_NOTES.md" <<'EOF'
# Sawrni Phase 9.1 v4 Installer Notes

This installer is the production-staging backend path. It avoids the old beta fragments and forces a clean Laravel backend using PHP 8.3.

Key corrections from v3:
- Uses `/usr/bin/php8.3` directly.
- Uses a local Composer PHAR executed by PHP 8.3.
- Creates Laravel with `--no-install --no-scripts`, then installs dependencies with `--prefer-source --no-scripts`.
- Retries Composer install and clears cache after network failures.
- Archives old `backend` and `backend-laravel` folders before creating a clean backend.
- Applies Sawrni Phase 3 database/API blueprint files after Laravel is successfully installed.

If this installer fails during Composer dependency download, re-run the same v4 script. Do not apply old Phase 7/8 backend fragments.
EOF

echo "PASS: Phase 9.1 v4 backend production API rebuild applied."
echo "Next: cd backend-laravel && /usr/bin/php8.3 artisan serve --host=0.0.0.0 --port=8010"
