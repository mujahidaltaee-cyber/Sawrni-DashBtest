#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspaces/Sawrni-DashBtest"
BACKEND="$ROOT/_sawrni_phase6/backend-runtime-laravel"

if [ ! -d "$BACKEND" ]; then
  echo "ERROR: Laravel backend not found at $BACKEND"
  exit 1
fi

cd "$BACKEND"

mkdir -p database/migrations routes storage/app/private/deliveries/booking-1 storage/app/private/deliveries/booking-2

cat > database/migrations/2026_06_26_000011_create_sawrni_phase611_signed_delivery_access.php <<'PHP'
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('sawrni_delivery_files')) {
            Schema::table('sawrni_delivery_files', function (Blueprint $table) {
                if (!Schema::hasColumn('sawrni_delivery_files', 'approved_at')) {
                    $table->timestamp('approved_at')->nullable();
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'rejected_at')) {
                    $table->timestamp('rejected_at')->nullable();
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'download_count')) {
                    $table->unsignedInteger('download_count')->default(0);
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'last_downloaded_at')) {
                    $table->timestamp('last_downloaded_at')->nullable();
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'checksum_sha256')) {
                    $table->string('checksum_sha256', 128)->nullable();
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'mime_type')) {
                    $table->string('mime_type', 120)->nullable();
                }
                if (!Schema::hasColumn('sawrni_delivery_files', 'original_filename')) {
                    $table->string('original_filename')->nullable();
                }
            });
        }

        if (!Schema::hasTable('sawrni_delivery_access_tokens')) {
            Schema::create('sawrni_delivery_access_tokens', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('delivery_file_id')->index();
                $table->string('token_hash', 128)->unique();
                $table->string('token_preview', 24)->nullable()->index();
                $table->string('actor_type', 40)->default('customer')->index();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('purpose', 40)->default('download')->index();
                $table->timestamp('expires_at')->index();
                $table->unsignedInteger('used_count')->default(0);
                $table->unsignedInteger('max_uses')->default(5);
                $table->timestamp('revoked_at')->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_delivery_access_logs')) {
            Schema::create('sawrni_delivery_access_logs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('delivery_file_id')->nullable()->index();
                $table->unsignedBigInteger('access_token_id')->nullable()->index();
                $table->string('actor_type', 40)->nullable()->index();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('action', 60)->index();
                $table->boolean('allowed')->default(false)->index();
                $table->string('reason')->nullable();
                $table->string('ip_address', 80)->nullable();
                $table->text('user_agent')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('sawrni_delivery_access_logs');
        Schema::dropIfExists('sawrni_delivery_access_tokens');
    }
};
PHP

cat > routes/sawrni_phase6_11_signed_delivery.php <<'PHP'
<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Schema\Blueprint;

if (!function_exists('sawrni_phase611_admin')) {
    function sawrni_phase611_admin(Request $request) {
        if (function_exists('sawrni_security_admin')) {
            return sawrni_security_admin($request);
        }

        $token = $request->bearerToken();
        if (!$token || !Schema::hasTable('admin_auth_sessions')) {
            return null;
        }

        return DB::table('admin_auth_sessions')
            ->where(function ($q) use ($token) {
                $q->where('token', $token)->orWhere('token_hash', hash('sha256', $token));
            })
            ->whereNull('revoked_at')
            ->first();
    }
}

if (!function_exists('sawrni_phase611_ensure_storage')) {
    function sawrni_phase611_ensure_storage(): void {
        if (!Schema::hasTable('sawrni_delivery_files')) {
            Schema::create('sawrni_delivery_files', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('booking_id')->nullable()->index();
                $table->string('provider_name')->nullable();
                $table->string('customer_name')->nullable();
                $table->string('title_ar')->nullable();
                $table->string('title_en')->nullable();
                $table->string('storage_disk')->default('private');
                $table->string('private_path')->nullable();
                $table->unsignedInteger('file_count')->default(1);
                $table->string('status')->default('pending_admin_review')->index();
                $table->boolean('customer_access_enabled')->default(false);
                $table->unsignedBigInteger('reviewed_by')->nullable();
                $table->timestamp('reviewed_at')->nullable();
                $table->timestamp('approved_at')->nullable();
                $table->timestamp('rejected_at')->nullable();
                $table->text('reject_reason')->nullable();
                $table->text('notes')->nullable();
                $table->unsignedInteger('download_count')->default(0);
                $table->timestamp('last_downloaded_at')->nullable();
                $table->string('checksum_sha256', 128)->nullable();
                $table->string('mime_type', 120)->nullable();
                $table->string('original_filename')->nullable();
                $table->timestamps();
            });
        }

        $columns = [
            'storage_disk' => fn(Blueprint $t) => $t->string('storage_disk')->default('private'),
            'private_path' => fn(Blueprint $t) => $t->string('private_path')->nullable(),
            'customer_access_enabled' => fn(Blueprint $t) => $t->boolean('customer_access_enabled')->default(false),
            'approved_at' => fn(Blueprint $t) => $t->timestamp('approved_at')->nullable(),
            'rejected_at' => fn(Blueprint $t) => $t->timestamp('rejected_at')->nullable(),
            'download_count' => fn(Blueprint $t) => $t->unsignedInteger('download_count')->default(0),
            'last_downloaded_at' => fn(Blueprint $t) => $t->timestamp('last_downloaded_at')->nullable(),
            'checksum_sha256' => fn(Blueprint $t) => $t->string('checksum_sha256', 128)->nullable(),
            'mime_type' => fn(Blueprint $t) => $t->string('mime_type', 120)->nullable(),
            'original_filename' => fn(Blueprint $t) => $t->string('original_filename')->nullable(),
        ];

        foreach ($columns as $column => $callback) {
            if (!Schema::hasColumn('sawrni_delivery_files', $column)) {
                Schema::table('sawrni_delivery_files', $callback);
            }
        }

        if (!Schema::hasTable('sawrni_delivery_access_tokens')) {
            Schema::create('sawrni_delivery_access_tokens', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('delivery_file_id')->index();
                $table->string('token_hash', 128)->unique();
                $table->string('token_preview', 24)->nullable()->index();
                $table->string('actor_type', 40)->default('customer')->index();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('purpose', 40)->default('download')->index();
                $table->timestamp('expires_at')->index();
                $table->unsignedInteger('used_count')->default(0);
                $table->unsignedInteger('max_uses')->default(5);
                $table->timestamp('revoked_at')->nullable()->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_delivery_access_logs')) {
            Schema::create('sawrni_delivery_access_logs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('delivery_file_id')->nullable()->index();
                $table->unsignedBigInteger('access_token_id')->nullable()->index();
                $table->string('actor_type', 40)->nullable()->index();
                $table->unsignedBigInteger('actor_id')->nullable()->index();
                $table->string('action', 60)->index();
                $table->boolean('allowed')->default(false)->index();
                $table->string('reason')->nullable();
                $table->string('ip_address', 80)->nullable();
                $table->text('user_agent')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        Storage::disk('local')->makeDirectory('private/deliveries/booking-1');
        Storage::disk('local')->makeDirectory('private/deliveries/booking-2');

        if (!Storage::disk('local')->exists('private/deliveries/booking-1/final-files.txt')) {
            Storage::disk('local')->put('private/deliveries/booking-1/final-files.txt', "Sawrni private delivery file for booking 1. This file must never be public.\n");
        }

        if (!Storage::disk('local')->exists('private/deliveries/booking-2/edited-files.txt')) {
            Storage::disk('local')->put('private/deliveries/booking-2/edited-files.txt', "Sawrni private delivery file for booking 2. This file must never be public.\n");
        }

        if (DB::table('sawrni_delivery_files')->count() === 0) {
            DB::table('sawrni_delivery_files')->insert([
                [
                    'booking_id' => 1,
                    'provider_name' => 'Hussein Photo',
                    'customer_name' => 'Ali Kareem',
                    'title_ar' => 'ملفات جلسة تخرج',
                    'title_en' => 'Graduation session files',
                    'storage_disk' => 'local',
                    'private_path' => 'private/deliveries/booking-1/final-files.txt',
                    'file_count' => 1,
                    'status' => 'approved',
                    'customer_access_enabled' => true,
                    'approved_at' => now(),
                    'notes' => 'Private storage demo file for signed access.',
                    'mime_type' => 'text/plain',
                    'original_filename' => 'final-files.txt',
                    'checksum_sha256' => hash('sha256', Storage::disk('local')->get('private/deliveries/booking-1/final-files.txt')),
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'booking_id' => 2,
                    'provider_name' => 'Edit Studio',
                    'customer_name' => 'Sara Ahmed',
                    'title_ar' => 'ملفات تعديل صور',
                    'title_en' => 'Edited photo files',
                    'storage_disk' => 'local',
                    'private_path' => 'private/deliveries/booking-2/edited-files.txt',
                    'file_count' => 1,
                    'status' => 'pending_admin_review',
                    'customer_access_enabled' => false,
                    'notes' => 'Private storage demo file pending admin approval.',
                    'mime_type' => 'text/plain',
                    'original_filename' => 'edited-files.txt',
                    'checksum_sha256' => hash('sha256', Storage::disk('local')->get('private/deliveries/booking-2/edited-files.txt')),
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }

        DB::table('sawrni_delivery_files')->where('id', 1)->update([
            'storage_disk' => 'local',
            'private_path' => 'private/deliveries/booking-1/final-files.txt',
            'status' => 'approved',
            'customer_access_enabled' => true,
            'approved_at' => now(),
            'mime_type' => 'text/plain',
            'original_filename' => 'final-files.txt',
            'checksum_sha256' => hash('sha256', Storage::disk('local')->get('private/deliveries/booking-1/final-files.txt')),
            'updated_at' => now(),
        ]);
    }
}

if (!function_exists('sawrni_phase611_log_access')) {
    function sawrni_phase611_log_access(Request $request, ?int $deliveryId, ?int $tokenId, string $action, bool $allowed, string $reason, array $metadata = []): void {
        if (!Schema::hasTable('sawrni_delivery_access_logs')) {
            return;
        }

        DB::table('sawrni_delivery_access_logs')->insert([
            'delivery_file_id' => $deliveryId,
            'access_token_id' => $tokenId,
            'actor_type' => $metadata['actor_type'] ?? null,
            'actor_id' => $metadata['actor_id'] ?? null,
            'action' => $action,
            'allowed' => $allowed,
            'reason' => $reason,
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 1200),
            'metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

if (!function_exists('sawrni_phase611_validate_access_token')) {
    function sawrni_phase611_validate_access_token(Request $request, string $token, string $action): array {
        sawrni_phase611_ensure_storage();

        $hash = hash('sha256', $token);

        $access = DB::table('sawrni_delivery_access_tokens')
            ->where('token_hash', $hash)
            ->first();

        if (!$access) {
            sawrni_phase611_log_access($request, null, null, $action, false, 'token_not_found');
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Invalid signed access token.', 'phase' => '6.11'], 404)];
        }

        if ($access->revoked_at !== null) {
            sawrni_phase611_log_access($request, (int) $access->delivery_file_id, (int) $access->id, $action, false, 'token_revoked', (array) $access);
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Signed access token has been revoked.', 'phase' => '6.11'], 403)];
        }

        if (now()->greaterThan($access->expires_at)) {
            sawrni_phase611_log_access($request, (int) $access->delivery_file_id, (int) $access->id, $action, false, 'token_expired', (array) $access);
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Signed access token has expired.', 'phase' => '6.11'], 403)];
        }

        if ((int) $access->used_count >= (int) $access->max_uses) {
            sawrni_phase611_log_access($request, (int) $access->delivery_file_id, (int) $access->id, $action, false, 'max_uses_reached', (array) $access);
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Signed access token usage limit reached.', 'phase' => '6.11'], 403)];
        }

        $delivery = DB::table('sawrni_delivery_files')->where('id', $access->delivery_file_id)->first();

        if (!$delivery) {
            sawrni_phase611_log_access($request, (int) $access->delivery_file_id, (int) $access->id, $action, false, 'delivery_not_found', (array) $access);
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Delivery file not found.', 'phase' => '6.11'], 404)];
        }

        if ($delivery->status !== 'approved' || !(bool) $delivery->customer_access_enabled) {
            sawrni_phase611_log_access($request, (int) $delivery->id, (int) $access->id, $action, false, 'delivery_not_approved', (array) $access);
            return [null, null, response()->json(['status' => 'error', 'message_en' => 'Delivery file is not approved for customer access.', 'phase' => '6.11'], 403)];
        }

        return [$access, $delivery, null];
    }
}

Route::prefix('/v1/admin-v10')->group(function () {
    Route::post('/delivery/{id}/signed-access', function (Request $request, int $id) {
        sawrni_phase611_ensure_storage();

        $admin = sawrni_phase611_admin($request);
        if (!$admin) {
            return sawrni_security_unauthorized();
        }

        $delivery = DB::table('sawrni_delivery_files')->where('id', $id)->first();
        if (!$delivery) {
            return response()->json(['status' => 'error', 'message_en' => 'Delivery file not found.', 'phase' => '6.11'], 404);
        }

        if ($delivery->status !== 'approved' || !(bool) $delivery->customer_access_enabled) {
            sawrni_phase611_log_access($request, $id, null, 'signed_access_create', false, 'delivery_not_approved');
            return response()->json([
                'status' => 'error',
                'message_ar' => 'لا يمكن إنشاء رابط تحميل قبل موافقة الإدارة على ملفات التسليم.',
                'message_en' => 'Cannot create signed access before admin approval.',
                'phase' => '6.11',
            ], 422);
        }

        $raw = 'sawrni-dlv-' . bin2hex(random_bytes(32));
        $hash = hash('sha256', $raw);
        $expiresAt = now()->addMinutes((int) $request->input('minutes', 30));
        $maxUses = max(1, min(20, (int) $request->input('max_uses', 5)));

        $tokenId = DB::table('sawrni_delivery_access_tokens')->insertGetId([
            'delivery_file_id' => $id,
            'token_hash' => $hash,
            'token_preview' => substr($raw, 0, 18),
            'actor_type' => 'customer',
            'actor_id' => null,
            'purpose' => 'download',
            'expires_at' => $expiresAt,
            'used_count' => 0,
            'max_uses' => $maxUses,
            'revoked_at' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        sawrni_phase611_log_access($request, $id, $tokenId, 'signed_access_create', true, 'created_by_admin', ['admin_id' => $admin->id ?? null]);

        return response()->json([
            'status' => 'ok',
            'phase' => '6.11',
            'message_ar' => 'تم إنشاء رابط وصول مؤقت وآمن.',
            'message_en' => 'Temporary signed access created.',
            'access_token' => $raw,
            'expires_at' => $expiresAt->toISOString(),
            'max_uses' => $maxUses,
            'links' => [
                'meta' => "/api/v1/delivery-access/{$raw}/meta",
                'download' => "/api/v1/delivery-access/{$raw}/download",
            ],
        ]);
    });

    Route::get('/delivery-access-logs', function (Request $request) {
        sawrni_phase611_ensure_storage();

        $admin = sawrni_phase611_admin($request);
        if (!$admin) {
            return sawrni_security_unauthorized();
        }

        $rows = DB::table('sawrni_delivery_access_logs')->orderByDesc('id')->limit(50)->get();

        return response()->json([
            'status' => 'ok',
            'phase' => '6.11',
            'module' => 'delivery_access_logs',
            'source' => 'sawrni_delivery_access_logs_secure',
            'rows' => $rows,
        ]);
    });
});

Route::get('/v1/delivery-access/{token}/meta', function (Request $request, string $token) {
    [$access, $delivery, $error] = sawrni_phase611_validate_access_token($request, $token, 'signed_meta_view');
    if ($error) {
        return $error;
    }

    DB::table('sawrni_delivery_access_tokens')->where('id', $access->id)->increment('used_count');
    sawrni_phase611_log_access($request, (int) $delivery->id, (int) $access->id, 'signed_meta_view', true, 'allowed', (array) $access);

    return response()->json([
        'status' => 'ok',
        'phase' => '6.11',
        'delivery' => [
            'id' => $delivery->id,
            'title_ar' => $delivery->title_ar,
            'title_en' => $delivery->title_en,
            'provider_name' => $delivery->provider_name,
            'customer_name' => $delivery->customer_name,
            'file_count' => $delivery->file_count,
            'original_filename' => $delivery->original_filename,
            'mime_type' => $delivery->mime_type,
            'checksum_sha256' => $delivery->checksum_sha256,
            'storage' => 'private_signed_only',
        ],
    ]);
});

Route::get('/v1/delivery-access/{token}/download', function (Request $request, string $token) {
    [$access, $delivery, $error] = sawrni_phase611_validate_access_token($request, $token, 'signed_download');
    if ($error) {
        return $error;
    }

    $disk = $delivery->storage_disk ?: 'local';
    $path = $delivery->private_path;

    if (!$path || !Storage::disk($disk)->exists($path)) {
        sawrni_phase611_log_access($request, (int) $delivery->id, (int) $access->id, 'signed_download', false, 'file_missing', (array) $access);
        return response()->json(['status' => 'error', 'message_en' => 'Private file missing.', 'phase' => '6.11'], 404);
    }

    DB::table('sawrni_delivery_access_tokens')->where('id', $access->id)->increment('used_count');
    DB::table('sawrni_delivery_files')->where('id', $delivery->id)->update([
        'download_count' => DB::raw('download_count + 1'),
        'last_downloaded_at' => now(),
        'updated_at' => now(),
    ]);

    sawrni_phase611_log_access($request, (int) $delivery->id, (int) $access->id, 'signed_download', true, 'allowed', (array) $access);

    $filename = $delivery->original_filename ?: basename($path);

    return response(Storage::disk($disk)->get($path), 200, [
        'Content-Type' => $delivery->mime_type ?: 'application/octet-stream',
        'Content-Disposition' => 'attachment; filename="' . addslashes($filename) . '"',
        'X-Sawrni-Private-Delivery' => 'signed-access-only',
    ]);
});
PHP

# Add route file to wrapper if not present.
python3 - <<'PY'
from pathlib import Path
p = Path('routes/sawrni_phase6_api.php')
text = p.read_text() if p.exists() else "<?php\n"
line = "require __DIR__ . '/sawrni_phase6_11_signed_delivery.php';"
if line not in text:
    # Load after security, before broad/generic routes if possible.
    security_line = "require __DIR__ . '/sawrni_phase6_security.php';"
    if security_line in text:
        text = text.replace(security_line, security_line + "\n" + line, 1)
    else:
        text += "\n" + line + "\n"
p.write_text(text)
print('Registered Phase 6.11 signed delivery routes.')
PY

# Ensure Laravel bootstrap points to Phase 6 API wrapper.
python3 - <<'PY'
from pathlib import Path
p = Path('bootstrap/app.php')
text = p.read_text()
text = text.replace("api: __DIR__.'/../routes/api.php',", "api: __DIR__.'/../routes/sawrni_phase6_api.php',")
text = text.replace("api: __DIR__.'/../routes/sawrni_phase6_health.php',", "api: __DIR__.'/../routes/sawrni_phase6_api.php',")
p.write_text(text)
print('bootstrap/app.php points to sawrni_phase6_api.php')
PY

php artisan migrate --force
php artisan optimize:clear
php artisan route:clear
php artisan config:clear

# Create smoke test in verified builds.
mkdir -p "$ROOT/_verified_builds"
cat > "$ROOT/_verified_builds/smoke_test_phase6_11_signed_delivery_access.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspaces/Sawrni-DashBtest"
BACKEND="$ROOT/_sawrni_phase6/backend-runtime-laravel"
API="http://127.0.0.1:8010/api/v1"

cd "$BACKEND"
php artisan tinker --execute='
if (Schema::hasTable("sawrni_security_rate_limits")) { DB::table("sawrni_security_rate_limits")->delete(); }
foreach (collect(DB::select("select name from sqlite_master where type=\"table\""))->pluck("name") as $t) { if (str_contains($t,"rate") || str_contains($t,"attempt")) { try { DB::table($t)->delete(); } catch (Throwable $e) {} } }
' >/dev/null 2>&1 || true

cd "$ROOT"

echo "Testing health..."
curl -fsS "$API/health" >/dev/null

echo "Testing secure auth..."
TOKEN=$(curl -fsS -X POST "$API/admin-auth/v10/beta-login" \
  -H "Content-Type: application/json" \
  -d '{"phone":"07000000000","password":"password"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

echo "Testing delivery approve reset..."
curl -fsS -X POST "$API/admin-v10/delivery/1/approve" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{}' | grep -q '"phase":"6.10"'

echo "Testing signed access creation..."
SIGNED=$(curl -fsS -X POST "$API/admin-v10/delivery/1/signed-access" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"minutes":30,"max_uses":10}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

echo "Testing signed metadata access..."
curl -fsS "$API/delivery-access/$SIGNED/meta" | grep -q '"phase":"6.11"'

echo "Testing signed private download..."
curl -fsS "$API/delivery-access/$SIGNED/download" | grep -q 'Sawrni private delivery file'

echo "Testing access logs..."
curl -fsS "$API/admin-v10/delivery-access-logs" \
  -H "Authorization: Bearer $TOKEN" | grep -q 'sawrni_delivery_access_logs_secure'

echo "PASS: Phase 6.11 real storage + signed delivery access verified."
SH
chmod +x "$ROOT/_verified_builds/smoke_test_phase6_11_signed_delivery_access.sh"

echo "Phase 6.11 applied successfully."
