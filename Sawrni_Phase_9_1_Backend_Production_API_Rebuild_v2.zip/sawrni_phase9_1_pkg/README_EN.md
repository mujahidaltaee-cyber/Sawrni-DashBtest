# Sawrni Phase 9.1 — Backend Production API Rebuild v2

This package rebuilds `backend-laravel` cleanly from the frozen Phase 3 Database/API Blueprint.

Important fix in v2:
- It does not trust Codespaces' old `/home/codespace/.php/current` PHP 8.0 path.
- It resolves or installs PHP 8.3+.
- It downloads a local Composer PHAR and runs Composer through PHP 8.3+ directly.
- It archives old backend fragments and creates a clean Laravel backend.

Run from repo root:

```bash
rm -rf _phase9_1
unzip -o Sawrni_Phase_9_1_Backend_Production_API_Rebuild_v2.zip -d _phase9_1
bash _phase9_1/sawrni_phase9_1_pkg/scripts/apply_phase9_1_backend_api_rebuild.sh
```
