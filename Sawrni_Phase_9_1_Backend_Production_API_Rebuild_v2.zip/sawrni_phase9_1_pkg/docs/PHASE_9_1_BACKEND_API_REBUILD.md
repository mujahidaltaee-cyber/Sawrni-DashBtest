# Sawrni Phase 9.1 — Backend Production API Rebuild

This phase creates the real staging backend foundation for Sawrni based on the frozen SRS v1.0 and Phase 3 Database/API Blueprint.

## Scope

- Laravel REST API under `/api/v1`
- Unified users table for customers, providers, admins, and super admins
- Provider approval workflow
- Customer booking lifecycle
- Deposit confirmation and contact/chat unlock
- 15% platform commission logic
- Provider wallet, debt, and 75,000 IQD suspension threshold
- Delivery upload and admin approval
- Review moderation before public rating
- In-app notifications table
- Audit logs for sensitive admin actions
- Staging seed users and test data

## Staging credentials

| Role | Phone | Password |
|---|---:|---|
| Super Admin | 07000000000 | password |
| COO/Admin | 07000000010 | password |
| Customer | 07000000001 | password |
| Approved Photographer | 07000000002 | password |
| Pending Provider | 07000000003 | password |
| Approved Editor | 07000000004 | password |
| Approved Model | 07000000005 | password |

OTP in staging: `123456`.

## Local API

After applying and starting the backend:

```bash
cd backend-laravel
/usr/bin/php8.3 artisan serve --host=0.0.0.0 --port=8010
```

Health endpoint:

```bash
curl http://127.0.0.1:8010/api/v1/health
```

Admin login:

```bash
curl -X POST http://127.0.0.1:8010/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{"phone":"07000000000","password":"password"}'
```

## Important production note

This phase is a staging rebuild. It is suitable for end-to-end product testing. Before real public launch, the backend should be deployed on a stable server with PostgreSQL, proper object storage, payment gateway credentials, Firebase credentials, and production secrets.
