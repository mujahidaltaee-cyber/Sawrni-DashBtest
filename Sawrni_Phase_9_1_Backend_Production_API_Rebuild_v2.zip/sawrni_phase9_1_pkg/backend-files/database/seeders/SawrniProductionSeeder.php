<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class SawrniProductionSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        DB::table('system_settings')->insertOrIgnore([
            ['key' => 'platform_commission_percent', 'value' => '15', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'provider_debt_suspend_threshold_iqd', 'value' => '75000', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'booking_edit_window_hours', 'value' => '3', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'booking_refund_cancel_window_hours', 'value' => '1', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'launch_city', 'value' => 'Baghdad', 'created_at' => $now, 'updated_at' => $now],
        ]);

        $baghdadId = DB::table('cities')->insertGetId([
            'name_ar' => 'بغداد',
            'name_en' => 'Baghdad',
            'status' => 'active',
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        foreach ([['الكرادة','Karrada'], ['المنصور','Mansour'], ['الجادرية','Jadriya'], ['زيونة','Zayouna']] as $area) {
            DB::table('areas')->insert(['city_id' => $baghdadId, 'name_ar' => $area[0], 'name_en' => $area[1], 'created_at' => $now, 'updated_at' => $now]);
        }

        foreach (['super_admin', 'admin', 'customer', 'provider'] as $role) {
            DB::table('roles')->insertOrIgnore(['name' => $role, 'label' => $role, 'created_at' => $now, 'updated_at' => $now]);
        }

        $permissions = [
            'dashboard.view', 'users.view', 'users.manage', 'providers.approve', 'bookings.view', 'bookings.manage',
            'payments.view', 'wallets.view', 'wallets.manage', 'deliveries.approve', 'reviews.approve', 'settings.manage', 'audit.view'
        ];
        foreach ($permissions as $permission) {
            DB::table('permissions')->insertOrIgnore(['name' => $permission, 'label' => $permission, 'created_at' => $now, 'updated_at' => $now]);
        }

        $password = Hash::make('password');
        $users = [
            ['phone' => '07000000000', 'full_name' => 'Mujahid Jabbar — Super Admin', 'role_type' => 'super_admin', 'email' => 'owner@sawrni.local'],
            ['phone' => '07000000010', 'full_name' => 'COO Test Admin', 'role_type' => 'admin', 'email' => 'coo@sawrni.local'],
            ['phone' => '07000000001', 'full_name' => 'Customer Test', 'role_type' => 'customer', 'email' => 'customer@sawrni.local'],
            ['phone' => '07000000002', 'full_name' => 'Photographer Approved', 'role_type' => 'provider', 'email' => 'photographer@sawrni.local'],
            ['phone' => '07000000003', 'full_name' => 'Photographer Pending', 'role_type' => 'provider', 'email' => 'pending@sawrni.local'],
            ['phone' => '07000000004', 'full_name' => 'Editor Approved', 'role_type' => 'provider', 'email' => 'editor@sawrni.local'],
            ['phone' => '07000000005', 'full_name' => 'Model Approved', 'role_type' => 'provider', 'email' => 'model@sawrni.local'],
        ];

        $userIds = [];
        foreach ($users as $user) {
            $id = DB::table('users')->insertGetId(array_merge($user, [
                'password' => $password,
                'status' => 'active',
                'locale' => 'ar',
                'phone_verified_at' => $now,
                'created_at' => $now,
                'updated_at' => $now,
            ]));
            $userIds[$user['phone']] = $id;
        }

        $plans = [
            ['name' => 'Basic', 'price_iqd' => 15000],
            ['name' => 'Standard', 'price_iqd' => 35000],
            ['name' => 'Premium', 'price_iqd' => 50000],
        ];
        foreach ($plans as $plan) {
            DB::table('subscription_plans')->insert([
                'name' => $plan['name'],
                'price_iqd' => $plan['price_iqd'],
                'features_json' => json_encode(['visibility' => $plan['name'], 'sawrni' => true], JSON_UNESCAPED_UNICODE),
                'limits_json' => json_encode(['v1' => true], JSON_UNESCAPED_UNICODE),
                'status' => 'active',
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        $providerRows = [
            ['phone' => '07000000002', 'type' => 'photographer', 'approval' => 'approved', 'bio' => 'مصور تخرج وبورتريه داخل بغداد.'],
            ['phone' => '07000000003', 'type' => 'photographer', 'approval' => 'pending', 'bio' => 'مزود خدمة بانتظار موافقة COO.'],
            ['phone' => '07000000004', 'type' => 'editor', 'approval' => 'approved', 'bio' => 'أدتر صور وفيديو.'],
            ['phone' => '07000000005', 'type' => 'model', 'approval' => 'approved', 'bio' => 'مودل متاح لجلسات تصوير تجارية.'],
        ];

        $providerIds = [];
        foreach ($providerRows as $provider) {
            $approved = $provider['approval'] === 'approved';
            $providerId = DB::table('provider_profiles')->insertGetId([
                'user_id' => $userIds[$provider['phone']],
                'provider_type' => $provider['type'],
                'approval_status' => $provider['approval'],
                'approved_by' => $approved ? $userIds['07000000000'] : null,
                'approved_at' => $approved ? $now : null,
                'bio' => $provider['bio'],
                'rating_avg' => $approved ? 4.8 : 0,
                'rating_count' => $approved ? 12 : 0,
                'subscription_status' => $approved ? 'Premium' : 'none',
                'service_area_text' => 'Baghdad',
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            $providerIds[$provider['phone']] = $providerId;
            DB::table('provider_wallets')->insert([
                'provider_id' => $providerId,
                'total_earned' => 0,
                'total_commission_due' => 0,
                'debt_balance' => 0,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('provider_portfolios')->insert([
                'provider_id' => $providerId,
                'title' => 'Sawrni sample portfolio',
                'media_url' => '/brand/logo_square.png',
                'media_type' => 'image',
                'sort_order' => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        $categories = [
            ['name_ar' => 'تصوير تخرج', 'name_en' => 'Graduation Photography', 'icon' => 'graduation'],
            ['name_ar' => 'تصوير شخصي', 'name_en' => 'Personal Photography', 'icon' => 'portrait'],
            ['name_ar' => 'تصوير منتجات', 'name_en' => 'Product Photography', 'icon' => 'product'],
            ['name_ar' => 'تصوير مطاعم وكافيهات', 'name_en' => 'Restaurants & Cafes', 'icon' => 'restaurant'],
            ['name_ar' => 'Video Edit', 'name_en' => 'Video Edit', 'icon' => 'edit'],
            ['name_ar' => 'Model Choosing', 'name_en' => 'Model Choosing', 'icon' => 'model'],
        ];

        $categoryIds = [];
        foreach ($categories as $i => $cat) {
            $categoryIds[$cat['icon']] = DB::table('service_categories')->insertGetId(array_merge($cat, [
                'status' => 'active',
                'sort_order' => $i + 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]));
        }

        $serviceId = DB::table('provider_services')->insertGetId([
            'provider_id' => $providerIds['07000000002'],
            'category_id' => $categoryIds['graduation'],
            'title' => 'جلسة تصوير تخرج Premium',
            'description' => 'جلسة تخرج داخل بغداد مع معالجة صور مختارة.',
            'base_price' => 100000,
            'status' => 'active',
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('provider_service_packages')->insert([
            'service_id' => $serviceId,
            'title' => 'باقة تخرج قياسية',
            'price_total' => 100000,
            'deposit_amount' => 25000,
            'duration_minutes' => 90,
            'deliverables' => json_encode(['20 edited photos', 'online delivery'], JSON_UNESCAPED_UNICODE),
            'status' => 'active',
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }
}
