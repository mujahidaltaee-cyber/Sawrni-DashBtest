<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;

if (! function_exists('sawrni_response')) {
    function sawrni_response(bool $success, string $message = '', mixed $data = null, array $errors = [], array $meta = [], int $status = 200)
    {
        return response()->json([
            'success' => $success,
            'message' => $message,
            'data' => $data,
            'errors' => (object) $errors,
            'meta' => (object) $meta,
            'request_id' => (string) Str::uuid(),
        ], $status);
    }
}

if (! function_exists('sawrni_token_for')) {
    function sawrni_token_for(object $user, string $name = 'api'): string
    {
        $plain = Str::random(64);
        DB::table('api_tokens')->insert([
            'user_id' => $user->id,
            'token_hash' => hash('sha256', $plain),
            'name' => $name,
            'abilities' => json_encode(['*']),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $plain;
    }
}

if (! function_exists('sawrni_user')) {
    function sawrni_user(Request $request): ?object
    {
        $header = $request->header('Authorization', '');
        if (! str_starts_with($header, 'Bearer ')) {
            return null;
        }
        $plain = trim(substr($header, 7));
        if ($plain === '') {
            return null;
        }
        $row = DB::table('api_tokens')->where('token_hash', hash('sha256', $plain))->first();
        if (! $row) {
            return null;
        }
        DB::table('api_tokens')->where('id', $row->id)->update(['last_used_at' => now(), 'updated_at' => now()]);
        return DB::table('users')->where('id', $row->user_id)->where('status', 'active')->first();
    }
}

if (! function_exists('sawrni_require_user')) {
    function sawrni_require_user(Request $request): object|\Illuminate\Http\JsonResponse
    {
        $user = sawrni_user($request);
        if (! $user) {
            return sawrni_response(false, 'Unauthenticated / غير مسجل الدخول', null, ['auth' => ['Bearer token is required']], [], 401);
        }
        return $user;
    }
}

if (! function_exists('sawrni_require_roles')) {
    function sawrni_require_roles(Request $request, array $roles): object|\Illuminate\Http\JsonResponse
    {
        $user = sawrni_require_user($request);
        if ($user instanceof \Illuminate\Http\JsonResponse) {
            return $user;
        }
        if (! in_array($user->role_type, $roles, true)) {
            return sawrni_response(false, 'Forbidden / لا توجد صلاحية', null, ['role' => ['Required role: '.implode(',', $roles)]], [], 403);
        }
        return $user;
    }
}

if (! function_exists('sawrni_provider_profile')) {
    function sawrni_provider_profile(int $userId): ?object
    {
        return DB::table('provider_profiles')->where('user_id', $userId)->first();
    }
}

if (! function_exists('sawrni_setting')) {
    function sawrni_setting(string $key, mixed $default = null): mixed
    {
        $row = DB::table('system_settings')->where('key', $key)->first();
        return $row ? $row->value : $default;
    }
}

if (! function_exists('sawrni_audit')) {
    function sawrni_audit(?int $actorId, string $action, string $targetType = null, int $targetId = null, array $before = null, array $after = null): void
    {
        DB::table('audit_logs')->insert([
            'actor_id' => $actorId,
            'action' => $action,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'before_json' => $before ? json_encode($before, JSON_UNESCAPED_UNICODE) : null,
            'after_json' => $after ? json_encode($after, JSON_UNESCAPED_UNICODE) : null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

if (! function_exists('sawrni_notify')) {
    function sawrni_notify(?int $userId, string $type, string $titleAr, string $bodyAr = null, array $data = []): void
    {
        DB::table('notifications')->insert([
            'user_id' => $userId,
            'type' => $type,
            'title_ar' => $titleAr,
            'title_en' => null,
            'body_ar' => $bodyAr,
            'body_en' => null,
            'data_json' => json_encode($data, JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('notification_events')->insert([
            'event_type' => $type,
            'payload_json' => json_encode(['user_id' => $userId, 'data' => $data], JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

if (! function_exists('sawrni_change_booking_status')) {
    function sawrni_change_booking_status(int $bookingId, string $toStatus, ?int $actorId = null, ?string $reason = null): void
    {
        $booking = DB::table('bookings')->where('id', $bookingId)->first();
        DB::table('bookings')->where('id', $bookingId)->update(['status' => $toStatus, 'updated_at' => now()]);
        DB::table('booking_status_history')->insert([
            'booking_id' => $bookingId,
            'from_status' => $booking?->status,
            'to_status' => $toStatus,
            'changed_by' => $actorId,
            'reason' => $reason,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

Route::prefix('v1')->group(function () {
    Route::get('/health', fn () => sawrni_response(true, 'Sawrni API is healthy', [
        'app' => 'Sawrni',
        'version' => 'Phase 9.1 Production API Rebuild',
        'time' => now()->toISOString(),
    ]));

    Route::post('/auth/send-otp', function (Request $request) {
        $request->validate(['phone' => ['required', 'string']]);
        return sawrni_response(true, 'OTP sent for staging', ['phone' => $request->phone, 'otp_preview' => '123456']);
    });

    Route::post('/auth/request-otp', function (Request $request) {
        $request->validate(['phone' => ['required', 'string']]);
        return sawrni_response(true, 'OTP sent for staging', ['phone' => $request->phone, 'otp_preview' => '123456']);
    });

    Route::post('/auth/verify-otp', function (Request $request) {
        $data = $request->validate(['phone' => ['required', 'string'], 'otp' => ['required', 'string']]);
        if ($data['otp'] !== '123456') {
            return sawrni_response(false, 'Invalid OTP', null, ['otp' => ['Use 123456 in staging']], [], 422);
        }
        $user = DB::table('users')->where('phone', $data['phone'])->first();
        if (! $user) {
            $id = DB::table('users')->insertGetId([
                'phone' => $data['phone'],
                'full_name' => 'Sawrni Customer',
                'password' => Hash::make('password'),
                'role_type' => 'customer',
                'status' => 'active',
                'locale' => 'ar',
                'phone_verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $user = DB::table('users')->where('id', $id)->first();
        }
        $token = sawrni_token_for($user, 'otp-login');
        return sawrni_response(true, 'Logged in', ['user' => $user, 'token' => $token, 'access_token' => $token]);
    });

    Route::post('/auth/login', function (Request $request) {
        $data = $request->validate(['phone' => ['required', 'string'], 'password' => ['required', 'string']]);
        $user = DB::table('users')->where('phone', $data['phone'])->first();
        if (! $user || ! $user->password || ! Hash::check($data['password'], $user->password)) {
            return sawrni_response(false, 'Invalid login credentials', null, ['phone' => ['Invalid phone or password']], [], 422);
        }
        if ($user->status !== 'active') {
            return sawrni_response(false, 'Account is not active', null, ['status' => [$user->status]], [], 403);
        }
        $token = sawrni_token_for($user, 'password-login');
        return sawrni_response(true, 'Logged in', ['user' => $user, 'token' => $token, 'access_token' => $token]);
    });

    Route::post('/auth/logout', function (Request $request) {
        $header = $request->header('Authorization', '');
        if (str_starts_with($header, 'Bearer ')) {
            DB::table('api_tokens')->where('token_hash', hash('sha256', trim(substr($header, 7))))->delete();
        }
        return sawrni_response(true, 'Logged out');
    });

    Route::get('/categories', function () {
        $rows = DB::table('service_categories')->where('status', 'active')->orderBy('sort_order')->get();
        return sawrni_response(true, 'Categories loaded', $rows);
    });

    Route::get('/providers', function (Request $request) {
        $q = DB::table('provider_profiles')
            ->join('users', 'users.id', '=', 'provider_profiles.user_id')
            ->where('provider_profiles.approval_status', 'approved')
            ->whereNull('provider_profiles.suspended_at')
            ->select('provider_profiles.*', 'users.full_name', 'users.phone');
        if ($request->filled('type')) {
            $q->where('provider_type', $request->query('type'));
        }
        $rows = $q->orderByDesc('rating_avg')->paginate(20);
        return sawrni_response(true, 'Approved providers loaded', $rows->items(), [], ['pagination' => ['total' => $rows->total(), 'page' => $rows->currentPage()]]);
    });

    Route::get('/models', function () {
        $rows = DB::table('provider_profiles')
            ->join('users', 'users.id', '=', 'provider_profiles.user_id')
            ->where('provider_profiles.provider_type', 'model')
            ->where('provider_profiles.approval_status', 'approved')
            ->select('provider_profiles.id', 'users.full_name', 'provider_profiles.rating_avg', 'provider_profiles.bio')
            ->get();
        return sawrni_response(true, 'Tiny-square models loaded', $rows);
    });

    Route::get('/providers/{id}', function (int $id) {
        $provider = DB::table('provider_profiles')
            ->join('users', 'users.id', '=', 'provider_profiles.user_id')
            ->where('provider_profiles.id', $id)
            ->where('provider_profiles.approval_status', 'approved')
            ->select('provider_profiles.*', 'users.full_name')
            ->first();
        if (! $provider) {
            return sawrni_response(false, 'Provider not found or not approved', null, [], [], 404);
        }
        $services = DB::table('provider_services')->where('provider_id', $id)->get();
        $packages = DB::table('provider_service_packages')
            ->join('provider_services', 'provider_services.id', '=', 'provider_service_packages.service_id')
            ->where('provider_services.provider_id', $id)
            ->select('provider_service_packages.*')
            ->get();
        $portfolio = DB::table('provider_portfolios')->where('provider_id', $id)->orderBy('sort_order')->get();
        return sawrni_response(true, 'Provider profile loaded', compact('provider', 'services', 'packages', 'portfolio'));
    });

    Route::get('/notifications', function (Request $request) {
        $user = sawrni_require_user($request);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $rows = DB::table('notifications')->where('user_id', $user->id)->orderByDesc('id')->limit(50)->get();
        return sawrni_response(true, 'Notifications loaded', $rows);
    });

    Route::get('/bookings', function (Request $request) {
        $user = sawrni_require_user($request);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $rows = DB::table('bookings')->where('customer_id', $user->id)->orderByDesc('id')->get();
        return sawrni_response(true, 'Customer bookings loaded', $rows);
    });

    Route::post('/bookings', function (Request $request) {
        $user = sawrni_require_roles($request, ['customer']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $data = $request->validate([
            'package_id' => ['required', 'integer'],
            'scheduled_start' => ['nullable', 'date'],
            'location_text' => ['nullable', 'string'],
            'lat' => ['nullable', 'numeric'],
            'lng' => ['nullable', 'numeric'],
            'customer_notes' => ['nullable', 'string'],
        ]);
        $package = DB::table('provider_service_packages')->where('id', $data['package_id'])->first();
        if (! $package) return sawrni_response(false, 'Package not found', null, [], [], 404);
        $service = DB::table('provider_services')->where('id', $package->service_id)->first();
        $provider = DB::table('provider_profiles')->where('id', $service->provider_id)->where('approval_status', 'approved')->first();
        if (! $provider) return sawrni_response(false, 'Provider is not approved', null, [], [], 422);
        $id = DB::table('bookings')->insertGetId([
            'customer_id' => $user->id,
            'provider_id' => $provider->id,
            'package_id' => $package->id,
            'scheduled_start' => $data['scheduled_start'] ?? now()->addDay(),
            'city' => 'Baghdad',
            'location_text' => $data['location_text'] ?? null,
            'lat' => $data['lat'] ?? null,
            'lng' => $data['lng'] ?? null,
            'total_price' => $package->price_total,
            'deposit_amount' => $package->deposit_amount,
            'status' => 'deposit_pending',
            'customer_notes' => $data['customer_notes'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        sawrni_change_booking_status($id, 'deposit_pending', $user->id, 'Booking created, waiting for deposit');
        sawrni_notify($user->id, 'booking_created', 'تم إنشاء الحجز', 'ادفع العربون لتأكيد الحجز.', ['booking_id' => $id]);
        return sawrni_response(true, 'Booking created. Deposit is required.', DB::table('bookings')->where('id', $id)->first(), [], [], 201);
    });

    Route::get('/bookings/{id}', function (Request $request, int $id) {
        $user = sawrni_require_user($request);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        $provider = DB::table('provider_profiles')->where('id', $booking->provider_id)->first();
        $isProvider = $user->role_type === 'provider' && $provider && $provider->user_id === $user->id;
        $isAdmin = in_array($user->role_type, ['admin', 'super_admin'], true);
        if ($booking->customer_id !== $user->id && ! $isProvider && ! $isAdmin) {
            return sawrni_response(false, 'Forbidden', null, [], [], 403);
        }
        $customer = DB::table('users')->where('id', $booking->customer_id)->first();
        $providerUser = DB::table('users')->where('id', $provider->user_id)->first();
        $contactUnlocked = $booking->deposit_paid_at !== null;
        if (! $contactUnlocked && ! $isAdmin) {
            $customer->phone = 'hidden_until_deposit';
            $providerUser->phone = 'hidden_until_deposit';
        }
        return sawrni_response(true, 'Booking loaded', compact('booking', 'customer', 'provider', 'providerUser', 'contactUnlocked'));
    });

    Route::post('/bookings/{id}/pay-deposit', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['customer']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $id)->where('customer_id', $user->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        if ($booking->deposit_paid_at) return sawrni_response(false, 'Deposit already paid', $booking, [], [], 422);
        $method = $request->input('method', 'cash');
        $paymentId = DB::table('payments')->insertGetId([
            'payer_id' => $user->id,
            'booking_id' => $booking->id,
            'amount' => $booking->deposit_amount,
            'type' => 'deposit',
            'method' => $method,
            'status' => 'confirmed',
            'gateway_reference' => 'STAGING-'.Str::upper(Str::random(8)),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('electronic_receipts')->insert([
            'payment_id' => $paymentId,
            'receipt_no' => 'RCPT-'.now()->format('Ymd').'-'.$paymentId,
            'receipt_url' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('bookings')->where('id', $id)->update(['deposit_paid_at' => now(), 'status' => 'confirmed', 'updated_at' => now()]);
        sawrni_change_booking_status($id, 'confirmed', $user->id, 'Deposit confirmed');
        DB::table('chat_threads')->insertOrIgnore([
            'booking_id' => $booking->id,
            'customer_id' => $booking->customer_id,
            'provider_id' => $booking->provider_id,
            'status' => 'open',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $wallet = DB::table('provider_wallets')->where('provider_id', $booking->provider_id)->first();
        $commission = (int) round($booking->total_price * 0.15);
        $providerNet = (int) $booking->total_price - $commission;
        $debtAfter = $wallet->debt_balance;
        if ($method === 'cash') {
            $debtAfter += $commission;
            DB::table('provider_wallets')->where('id', $wallet->id)->update([
                'total_earned' => DB::raw('total_earned + '.$providerNet),
                'total_commission_due' => DB::raw('total_commission_due + '.$commission),
                'debt_balance' => $debtAfter,
                'suspended_at' => $debtAfter >= 75000 ? now() : null,
                'updated_at' => now(),
            ]);
            DB::table('wallet_ledger_entries')->insert([
                'wallet_id' => $wallet->id,
                'booking_id' => $booking->id,
                'type' => 'platform_commission_debt',
                'amount' => $commission,
                'direction' => 'debit',
                'balance_after' => $debtAfter,
                'meta_json' => json_encode(['total_price' => $booking->total_price, 'commission_percent' => 15], JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        sawrni_notify($user->id, 'deposit_paid', 'تم دفع العربون', 'تم فتح معلومات التواصل والشات.', ['booking_id' => $id]);
        $provider = DB::table('provider_profiles')->where('id', $booking->provider_id)->first();
        sawrni_notify($provider->user_id, 'new_confirmed_booking', 'حجز جديد مؤكد', 'لديك حجز جديد بانتظار القبول.', ['booking_id' => $id]);
        return sawrni_response(true, 'Deposit confirmed. Contact and chat are now unlocked.', DB::table('bookings')->where('id', $id)->first());
    });

    Route::patch('/bookings/{id}', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['customer']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $id)->where('customer_id', $user->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        if ($booking->deposit_paid_at && Carbon::parse($booking->deposit_paid_at)->addHours(3)->isPast()) {
            return sawrni_response(false, 'Booking edit window expired', null, ['booking' => ['3-hour edit window ended']], [], 422);
        }
        $before = (array) $booking;
        $changes = $request->only(['scheduled_start', 'location_text', 'lat', 'lng', 'customer_notes']);
        $changes['updated_at'] = now();
        DB::table('bookings')->where('id', $id)->update($changes);
        DB::table('booking_modifications')->insert([
            'booking_id' => $id,
            'changed_by' => $user->id,
            'before_json' => json_encode($before, JSON_UNESCAPED_UNICODE),
            'after_json' => json_encode($changes, JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return sawrni_response(true, 'Booking updated', DB::table('bookings')->where('id', $id)->first());
    });

    Route::post('/bookings/{id}/cancel', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['customer']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $id)->where('customer_id', $user->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        $refundable = $booking->deposit_paid_at ? ! Carbon::parse($booking->deposit_paid_at)->addHour()->isPast() : true;
        DB::table('booking_cancellations')->insert([
            'booking_id' => $id,
            'cancelled_by' => $user->id,
            'reason' => $request->input('reason'),
            'deposit_refundable' => $refundable,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        sawrni_change_booking_status($id, 'customer_cancelled', $user->id, $refundable ? 'Refundable cancellation' : 'Deposit non-refundable');
        return sawrni_response(true, $refundable ? 'Booking cancelled. Deposit is refundable.' : 'Booking cancelled. Deposit is non-refundable.', ['deposit_refundable' => $refundable]);
    });

    Route::get('/bookings/{id}/delivery', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['customer', 'admin', 'super_admin']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        if ($user->role_type === 'customer' && $booking->customer_id !== $user->id) return sawrni_response(false, 'Forbidden', null, [], [], 403);
        $batches = DB::table('delivery_batches')->where('booking_id', $id)->where('status', 'approved')->get();
        $files = DB::table('delivery_files')->whereIn('delivery_batch_id', $batches->pluck('id'))->get();
        return sawrni_response(true, 'Approved delivery files loaded', compact('batches', 'files'));
    });

    Route::post('/bookings/{id}/reviews', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['customer']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $data = $request->validate(['rating' => ['required', 'integer', 'min:1', 'max:5'], 'comment' => ['nullable', 'string']]);
        $booking = DB::table('bookings')->where('id', $id)->where('customer_id', $user->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        $reviewId = DB::table('reviews')->insertGetId([
            'booking_id' => $id,
            'customer_id' => $user->id,
            'provider_id' => $booking->provider_id,
            'rating' => $data['rating'],
            'comment' => $data['comment'] ?? null,
            'moderation_status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        sawrni_notify(null, 'review_pending_admin', 'تقييم جديد بانتظار الموافقة', 'يوجد تقييم جديد يحتاج مراجعة الإدارة.', ['review_id' => $reviewId]);
        return sawrni_response(true, 'Review submitted and waiting for management approval', DB::table('reviews')->where('id', $reviewId)->first(), [], [], 201);
    });

    Route::get('/chats/{booking_id}', function (Request $request, int $bookingId) {
        $user = sawrni_require_user($request);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $booking = DB::table('bookings')->where('id', $bookingId)->first();
        if (! $booking || ! $booking->deposit_paid_at) return sawrni_response(false, 'Chat opens only after deposit payment', null, [], [], 403);
        $provider = DB::table('provider_profiles')->where('id', $booking->provider_id)->first();
        if ($booking->customer_id !== $user->id && $provider->user_id !== $user->id) return sawrni_response(false, 'Forbidden', null, [], [], 403);
        $thread = DB::table('chat_threads')->where('booking_id', $bookingId)->first();
        $messages = $thread ? DB::table('chat_messages')->where('thread_id', $thread->id)->orderBy('id')->get() : [];
        return sawrni_response(true, 'Chat loaded', compact('thread', 'messages'));
    });

    Route::post('/provider/register', function (Request $request) {
        $data = $request->validate([
            'phone' => ['required', 'string'],
            'password' => ['nullable', 'string'],
            'full_name' => ['required', 'string'],
            'provider_type' => ['required', 'in:photographer,editor,model'],
            'bio' => ['nullable', 'string'],
        ]);
        if (DB::table('users')->where('phone', $data['phone'])->exists()) {
            return sawrni_response(false, 'Phone already exists', null, ['phone' => ['already exists']], [], 422);
        }
        $userId = DB::table('users')->insertGetId([
            'phone' => $data['phone'],
            'full_name' => $data['full_name'],
            'password' => Hash::make($data['password'] ?? 'password'),
            'role_type' => 'provider',
            'status' => 'active',
            'locale' => 'ar',
            'phone_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $providerId = DB::table('provider_profiles')->insertGetId([
            'user_id' => $userId,
            'provider_type' => $data['provider_type'],
            'approval_status' => 'pending',
            'bio' => $data['bio'] ?? null,
            'subscription_status' => 'none',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('provider_wallets')->insert(['provider_id' => $providerId, 'created_at' => now(), 'updated_at' => now()]);
        sawrni_notify(null, 'provider_pending', 'مزود خدمة جديد بانتظار الموافقة', $data['full_name'], ['provider_id' => $providerId]);
        return sawrni_response(true, 'Provider registered and waiting for approval', ['provider_id' => $providerId], [], [], 201);
    });

    Route::get('/provider/me', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        return sawrni_response(true, 'Provider profile loaded', compact('user', 'profile'));
    });

    Route::patch('/provider/profile', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $changes = $request->only(['bio', 'service_radius_km', 'service_area_text']);
        $changes['updated_at'] = now();
        DB::table('provider_profiles')->where('id', $profile->id)->update($changes);
        return sawrni_response(true, 'Provider profile updated', DB::table('provider_profiles')->where('id', $profile->id)->first());
    });

    Route::post('/provider/portfolio', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $id = DB::table('provider_portfolios')->insertGetId([
            'provider_id' => $profile->id,
            'title' => $request->input('title', 'Portfolio item'),
            'media_url' => $request->input('media_url', '/brand/logo_square.png'),
            'media_type' => $request->input('media_type', 'image'),
            'sort_order' => (int) $request->input('sort_order', 0),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return sawrni_response(true, 'Portfolio item created', DB::table('provider_portfolios')->where('id', $id)->first(), [], [], 201);
    });

    Route::post('/provider/services', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        if ($profile->approval_status !== 'approved') return sawrni_response(false, 'Provider must be approved first', null, [], [], 403);
        $data = $request->validate(['category_id' => ['required', 'integer'], 'title' => ['required', 'string'], 'base_price' => ['required', 'integer'], 'description' => ['nullable', 'string']]);
        $id = DB::table('provider_services')->insertGetId(array_merge($data, ['provider_id' => $profile->id, 'status' => 'active', 'created_at' => now(), 'updated_at' => now()]));
        return sawrni_response(true, 'Service created', DB::table('provider_services')->where('id', $id)->first(), [], [], 201);
    });

    Route::post('/provider/services/{id}/packages', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $service = DB::table('provider_services')->where('id', $id)->where('provider_id', $profile->id)->first();
        if (! $service) return sawrni_response(false, 'Service not found', null, [], [], 404);
        $data = $request->validate(['title' => ['required', 'string'], 'price_total' => ['required', 'integer'], 'deposit_amount' => ['required', 'integer'], 'duration_minutes' => ['nullable', 'integer']]);
        $packageId = DB::table('provider_service_packages')->insertGetId(array_merge($data, ['service_id' => $id, 'status' => 'active', 'created_at' => now(), 'updated_at' => now()]));
        return sawrni_response(true, 'Package created', DB::table('provider_service_packages')->where('id', $packageId)->first(), [], [], 201);
    });

    Route::get('/provider/bookings', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $rows = DB::table('bookings')->where('provider_id', $profile->id)->orderByDesc('id')->get();
        return sawrni_response(true, 'Provider bookings loaded', $rows);
    });

    Route::post('/provider/bookings/{id}/accept', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $booking = DB::table('bookings')->where('id', $id)->where('provider_id', $profile->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        sawrni_change_booking_status($id, 'provider_accepted', $user->id, 'Provider accepted booking');
        sawrni_notify($booking->customer_id, 'booking_accepted', 'تم قبول الحجز', 'مزود الخدمة قبل الحجز.', ['booking_id' => $id]);
        return sawrni_response(true, 'Booking accepted', DB::table('bookings')->where('id', $id)->first());
    });

    Route::post('/provider/bookings/{id}/reject', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $booking = DB::table('bookings')->where('id', $id)->where('provider_id', $profile->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        sawrni_change_booking_status($id, 'provider_rejected', $user->id, $request->input('reason', 'Rejected'));
        sawrni_notify($booking->customer_id, 'booking_rejected', 'تم رفض الحجز', 'مزود الخدمة رفض الحجز.', ['booking_id' => $id]);
        return sawrni_response(true, 'Booking rejected', DB::table('bookings')->where('id', $id)->first());
    });

    Route::patch('/provider/bookings/{id}/status', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $data = $request->validate(['status' => ['required', 'string']]);
        $profile = sawrni_provider_profile($user->id);
        $booking = DB::table('bookings')->where('id', $id)->where('provider_id', $profile->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        sawrni_change_booking_status($id, $data['status'], $user->id, 'Provider status update');
        return sawrni_response(true, 'Booking status updated', DB::table('bookings')->where('id', $id)->first());
    });

    Route::post('/provider/bookings/{id}/delivery', function (Request $request, int $id) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $booking = DB::table('bookings')->where('id', $id)->where('provider_id', $profile->id)->first();
        if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
        $batchId = DB::table('delivery_batches')->insertGetId([
            'booking_id' => $id,
            'provider_id' => $profile->id,
            'status' => 'pending',
            'submitted_at' => now(),
            'notes' => $request->input('notes'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        foreach ($request->input('files', [['file_name' => 'staging-delivery.zip', 'file_url' => '/staging/delivery.zip']]) as $file) {
            DB::table('delivery_files')->insert([
                'delivery_batch_id' => $batchId,
                'file_name' => $file['file_name'] ?? 'delivery-file',
                'file_url' => $file['file_url'] ?? null,
                'storage_disk' => 'staging',
                'size_bytes' => $file['size_bytes'] ?? 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        sawrni_change_booking_status($id, 'delivery_pending', $user->id, 'Provider uploaded delivery files');
        sawrni_notify(null, 'delivery_pending_admin', 'تسليم جديد بانتظار الموافقة', 'مزود الخدمة رفع ملفات تسليم.', ['delivery_batch_id' => $batchId]);
        return sawrni_response(true, 'Delivery uploaded and waiting for admin approval', DB::table('delivery_batches')->where('id', $batchId)->first(), [], [], 201);
    });

    Route::get('/provider/wallet', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $wallet = DB::table('provider_wallets')->where('provider_id', $profile->id)->first();
        $ledger = DB::table('wallet_ledger_entries')->where('wallet_id', $wallet->id)->orderByDesc('id')->limit(20)->get();
        return sawrni_response(true, 'Wallet loaded', compact('wallet', 'ledger'));
    });

    Route::get('/provider/subscription', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $current = DB::table('provider_subscriptions')->where('provider_id', $profile->id)->orderByDesc('id')->first();
        $plans = DB::table('subscription_plans')->where('status', 'active')->get();
        return sawrni_response(true, 'Subscription loaded', compact('current', 'plans'));
    });

    Route::post('/provider/subscription/pay', function (Request $request) {
        $user = sawrni_require_roles($request, ['provider']);
        if ($user instanceof \Illuminate\Http\JsonResponse) return $user;
        $profile = sawrni_provider_profile($user->id);
        $planId = (int) $request->input('plan_id');
        $plan = DB::table('subscription_plans')->where('id', $planId)->first();
        if (! $plan) return sawrni_response(false, 'Plan not found', null, [], [], 404);
        DB::table('provider_subscriptions')->insert([
            'provider_id' => $profile->id,
            'plan_id' => $plan->id,
            'status' => 'active',
            'starts_at' => now(),
            'ends_at' => now()->addMonth(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('provider_profiles')->where('id', $profile->id)->update(['subscription_status' => $plan->name, 'updated_at' => now()]);
        return sawrni_response(true, 'Subscription activated', ['plan' => $plan]);
    });

    Route::prefix('admin')->group(function () {
        Route::get('/dashboard', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $data = [
                'users' => DB::table('users')->count(),
                'customers' => DB::table('users')->where('role_type', 'customer')->count(),
                'providers_pending' => DB::table('provider_profiles')->where('approval_status', 'pending')->count(),
                'providers_approved' => DB::table('provider_profiles')->where('approval_status', 'approved')->count(),
                'bookings' => DB::table('bookings')->count(),
                'payments_confirmed_iqd' => DB::table('payments')->where('status', 'confirmed')->sum('amount'),
                'delivery_pending' => DB::table('delivery_batches')->where('status', 'pending')->count(),
                'reviews_pending' => DB::table('reviews')->where('moderation_status', 'pending')->count(),
                'debt_warnings' => DB::table('provider_wallets')->where('debt_balance', '>=', 75000)->count(),
            ];
            return sawrni_response(true, 'Admin dashboard loaded', $data);
        });

        Route::get('/users', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Users loaded', DB::table('users')->orderByDesc('id')->limit(100)->get());
        });

        Route::patch('/users/{id}/status', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $status = $request->input('status', 'active');
            DB::table('users')->where('id', $id)->update(['status' => $status, 'updated_at' => now()]);
            sawrni_audit($admin->id, 'users.status.update', 'users', $id, null, ['status' => $status]);
            return sawrni_response(true, 'User status updated', DB::table('users')->where('id', $id)->first());
        });

        Route::get('/providers/pending', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $rows = DB::table('provider_profiles')->join('users', 'users.id', '=', 'provider_profiles.user_id')
                ->where('approval_status', 'pending')
                ->select('provider_profiles.*', 'users.full_name', 'users.phone', 'users.email')
                ->get();
            return sawrni_response(true, 'Pending providers loaded', $rows);
        });

        Route::get('/providers', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $rows = DB::table('provider_profiles')->join('users', 'users.id', '=', 'provider_profiles.user_id')
                ->select('provider_profiles.*', 'users.full_name', 'users.phone', 'users.email')
                ->orderByDesc('provider_profiles.id')->get();
            return sawrni_response(true, 'Providers loaded', $rows);
        });

        Route::post('/providers/{id}/approve', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('provider_profiles')->where('id', $id)->update([
                'approval_status' => 'approved', 'approved_by' => $admin->id, 'approved_at' => now(), 'updated_at' => now(),
            ]);
            sawrni_audit($admin->id, 'providers.approve', 'provider_profiles', $id);
            $provider = DB::table('provider_profiles')->where('id', $id)->first();
            sawrni_notify($provider->user_id, 'provider_approved', 'تمت الموافقة على حسابك', 'أصبح حسابك ظاهرًا داخل تطبيق صورني.', ['provider_id' => $id]);
            return sawrni_response(true, 'Provider approved', $provider);
        });

        Route::post('/providers/{id}/reject', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('provider_profiles')->where('id', $id)->update(['approval_status' => 'rejected', 'updated_at' => now()]);
            sawrni_audit($admin->id, 'providers.reject', 'provider_profiles', $id, null, ['reason' => $request->input('reason')]);
            return sawrni_response(true, 'Provider rejected', DB::table('provider_profiles')->where('id', $id)->first());
        });

        Route::post('/providers/{id}/reactivate', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('provider_profiles')->where('id', $id)->update(['suspended_at' => null, 'updated_at' => now()]);
            DB::table('provider_wallets')->where('provider_id', $id)->update(['suspended_at' => null, 'updated_at' => now()]);
            sawrni_audit($admin->id, 'providers.reactivate', 'provider_profiles', $id);
            return sawrni_response(true, 'Provider reactivated', DB::table('provider_profiles')->where('id', $id)->first());
        });

        Route::post('/providers/{id}/suspend', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('provider_profiles')->where('id', $id)->update(['suspended_at' => now(), 'updated_at' => now()]);
            sawrni_audit($admin->id, 'providers.suspend', 'provider_profiles', $id, null, ['reason' => $request->input('reason')]);
            return sawrni_response(true, 'Provider suspended', DB::table('provider_profiles')->where('id', $id)->first());
        });

        Route::get('/customers', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Customers loaded', DB::table('users')->where('role_type', 'customer')->orderByDesc('id')->get());
        });

        Route::get('/bookings', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Bookings loaded', DB::table('bookings')->orderByDesc('id')->limit(100)->get());
        });

        Route::post('/bookings/{id}/reassign-provider', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $newProviderId = (int) $request->input('new_provider_id');
            $booking = DB::table('bookings')->where('id', $id)->first();
            if (! $booking) return sawrni_response(false, 'Booking not found', null, [], [], 404);
            DB::table('provider_reassignment_requests')->insert([
                'booking_id' => $id,
                'old_provider_id' => $booking->provider_id,
                'new_provider_id' => $newProviderId,
                'status' => 'pending_customer_approval',
                'reason' => $request->input('reason'),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            sawrni_audit($admin->id, 'bookings.reassign_provider', 'bookings', $id, ['old_provider_id' => $booking->provider_id], ['new_provider_id' => $newProviderId]);
            return sawrni_response(true, 'Provider reassignment request created');
        });

        Route::get('/payments', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Payments loaded', DB::table('payments')->orderByDesc('id')->get());
        });

        Route::get('/wallets', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Wallets loaded', DB::table('provider_wallets')->orderByDesc('debt_balance')->get());
        });

        Route::post('/wallets/{id}/settlements', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $amount = (int) $request->input('amount', 0);
            $wallet = DB::table('provider_wallets')->where('id', $id)->first();
            if (! $wallet) return sawrni_response(false, 'Wallet not found', null, [], [], 404);
            $newDebt = max(0, $wallet->debt_balance - $amount);
            DB::table('provider_wallets')->where('id', $id)->update(['debt_balance' => $newDebt, 'suspended_at' => $newDebt >= 75000 ? now() : null, 'updated_at' => now()]);
            DB::table('provider_settlements')->insert(['wallet_id' => $id, 'amount' => $amount, 'method' => $request->input('method', 'cash'), 'recorded_by' => $admin->id, 'notes' => $request->input('notes'), 'created_at' => now(), 'updated_at' => now()]);
            sawrni_audit($admin->id, 'wallets.settlement', 'provider_wallets', $id, ['debt_balance' => $wallet->debt_balance], ['debt_balance' => $newDebt]);
            return sawrni_response(true, 'Settlement recorded', DB::table('provider_wallets')->where('id', $id)->first());
        });

        Route::get('/deliveries/pending', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Pending deliveries loaded', DB::table('delivery_batches')->where('status', 'pending')->orderByDesc('id')->get());
        });

        Route::post('/deliveries/{id}/approve', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $batch = DB::table('delivery_batches')->where('id', $id)->first();
            if (! $batch) return sawrni_response(false, 'Delivery batch not found', null, [], [], 404);
            DB::table('delivery_batches')->where('id', $id)->update(['status' => 'approved', 'approved_by' => $admin->id, 'approved_at' => now(), 'updated_at' => now()]);
            DB::table('delivery_approvals')->insert(['delivery_batch_id' => $id, 'admin_id' => $admin->id, 'action' => 'approved', 'created_at' => now(), 'updated_at' => now()]);
            sawrni_change_booking_status($batch->booking_id, 'delivery_approved', $admin->id, 'Admin approved delivery');
            $booking = DB::table('bookings')->where('id', $batch->booking_id)->first();
            sawrni_notify($booking->customer_id, 'delivery_approved', 'تمت الموافقة على ملفات التسليم', 'يمكنك الآن تحميل ملفاتك.', ['booking_id' => $booking->id]);
            sawrni_audit($admin->id, 'deliveries.approve', 'delivery_batches', $id);
            return sawrni_response(true, 'Delivery approved', DB::table('delivery_batches')->where('id', $id)->first());
        });

        Route::post('/deliveries/{id}/reject', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('delivery_batches')->where('id', $id)->update(['status' => 'rejected', 'updated_at' => now()]);
            DB::table('delivery_approvals')->insert(['delivery_batch_id' => $id, 'admin_id' => $admin->id, 'action' => 'rejected', 'reason' => $request->input('reason'), 'created_at' => now(), 'updated_at' => now()]);
            sawrni_audit($admin->id, 'deliveries.reject', 'delivery_batches', $id, null, ['reason' => $request->input('reason')]);
            return sawrni_response(true, 'Delivery rejected');
        });

        Route::get('/reviews/pending', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Pending reviews loaded', DB::table('reviews')->where('moderation_status', 'pending')->orderByDesc('id')->get());
        });

        Route::post('/reviews/{id}/approve', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $review = DB::table('reviews')->where('id', $id)->first();
            if (! $review) return sawrni_response(false, 'Review not found', null, [], [], 404);
            DB::table('reviews')->where('id', $id)->update(['moderation_status' => 'approved', 'updated_at' => now()]);
            DB::table('review_moderation_actions')->insert(['review_id' => $id, 'admin_id' => $admin->id, 'action' => 'approved', 'created_at' => now(), 'updated_at' => now()]);
            $stats = DB::table('reviews')->where('provider_id', $review->provider_id)->where('moderation_status', 'approved')->selectRaw('AVG(rating) as avg_rating, COUNT(*) as count_rating')->first();
            DB::table('provider_profiles')->where('id', $review->provider_id)->update(['rating_avg' => round((float) $stats->avg_rating, 2), 'rating_count' => $stats->count_rating, 'updated_at' => now()]);
            sawrni_audit($admin->id, 'reviews.approve', 'reviews', $id);
            return sawrni_response(true, 'Review approved', DB::table('reviews')->where('id', $id)->first());
        });

        Route::post('/reviews/{id}/reject', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('reviews')->where('id', $id)->update(['moderation_status' => 'rejected', 'updated_at' => now()]);
            DB::table('review_moderation_actions')->insert(['review_id' => $id, 'admin_id' => $admin->id, 'action' => 'rejected', 'reason' => $request->input('reason'), 'created_at' => now(), 'updated_at' => now()]);
            sawrni_audit($admin->id, 'reviews.reject', 'reviews', $id);
            return sawrni_response(true, 'Review rejected');
        });

        Route::get('/service-categories', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Service categories loaded', DB::table('service_categories')->orderBy('sort_order')->get());
        });

        Route::post('/service-categories', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $data = $request->validate(['name_ar' => ['required', 'string'], 'name_en' => ['required', 'string'], 'icon' => ['nullable', 'string']]);
            $id = DB::table('service_categories')->insertGetId(array_merge($data, ['status' => 'active', 'sort_order' => 99, 'created_at' => now(), 'updated_at' => now()]));
            return sawrni_response(true, 'Category created', DB::table('service_categories')->where('id', $id)->first(), [], [], 201);
        });

        Route::put('/service-categories/{id}', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            DB::table('service_categories')->where('id', $id)->update(array_merge($request->only(['name_ar', 'name_en', 'icon', 'status', 'sort_order']), ['updated_at' => now()]));
            return sawrni_response(true, 'Category updated', DB::table('service_categories')->where('id', $id)->first());
        });

        Route::get('/subscriptions', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Subscription plans loaded', DB::table('subscription_plans')->orderBy('price_iqd')->get());
        });

        Route::get('/roles-permissions', function (Request $request) {
            $admin = sawrni_require_roles($request, ['super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Roles and permissions loaded', [
                'roles' => DB::table('roles')->get(),
                'permissions' => DB::table('permissions')->get(),
                'overrides' => DB::table('admin_permission_overrides')->get(),
            ]);
        });

        Route::patch('/admins/{id}/permissions', function (Request $request, int $id) {
            $admin = sawrni_require_roles($request, ['super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            foreach ($request->input('permissions', []) as $permission => $allowed) {
                DB::table('admin_permission_overrides')->updateOrInsert(
                    ['admin_id' => $id, 'permission' => $permission],
                    ['is_allowed' => (bool) $allowed, 'granted_by' => $admin->id, 'updated_at' => now(), 'created_at' => now()]
                );
            }
            sawrni_audit($admin->id, 'admins.permissions.update', 'users', $id, null, $request->input('permissions', []));
            return sawrni_response(true, 'Admin permissions updated');
        });

        Route::patch('/settings', function (Request $request) {
            $admin = sawrni_require_roles($request, ['super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            foreach ($request->all() as $key => $value) {
                DB::table('system_settings')->updateOrInsert(['key' => $key], ['value' => (string) $value, 'updated_at' => now(), 'created_at' => now()]);
            }
            sawrni_audit($admin->id, 'settings.update', 'system_settings', null, null, $request->all());
            return sawrni_response(true, 'Settings updated', DB::table('system_settings')->get());
        });

        Route::get('/audit-logs', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            return sawrni_response(true, 'Audit logs loaded', DB::table('audit_logs')->orderByDesc('id')->limit(100)->get());
        });

        Route::post('/notification/broadcast', function (Request $request) {
            $admin = sawrni_require_roles($request, ['admin', 'super_admin']);
            if ($admin instanceof \Illuminate\Http\JsonResponse) return $admin;
            $title = $request->input('title_ar', 'إشعار من صورني');
            foreach (DB::table('users')->where('status', 'active')->pluck('id') as $userId) {
                sawrni_notify($userId, 'admin_broadcast', $title, $request->input('body_ar'), ['admin_id' => $admin->id]);
            }
            sawrni_audit($admin->id, 'notifications.broadcast', 'notifications');
            return sawrni_response(true, 'Broadcast notification created');
        });
    });
});
