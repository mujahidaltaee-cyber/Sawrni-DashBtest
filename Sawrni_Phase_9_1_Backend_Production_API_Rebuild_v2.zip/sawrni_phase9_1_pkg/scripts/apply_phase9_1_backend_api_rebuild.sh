#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend-laravel"
TOOLS_DIR="$ROOT/.sawrni-tools"
mkdir -p "$TOOLS_DIR"

echo "Sawrni Phase 9.1 — deterministic backend production API rebuild"
echo "Root: $ROOT"

# Resolve a real PHP 8.3+ binary. Do not trust Codespaces' /home/codespace/.php/current PHP 8.0.
choose_php() {
  for candidate in /usr/bin/php8.4 /usr/bin/php8.3 /usr/local/bin/php8.4 /usr/local/bin/php8.3; do
    if [ -x "$candidate" ]; then
      local major minor
      major="$($candidate -r 'echo PHP_MAJOR_VERSION;' 2>/dev/null || echo 0)"
      minor="$($candidate -r 'echo PHP_MINOR_VERSION;' 2>/dev/null || echo 0)"
      if [ "$major" -gt 8 ] || { [ "$major" -eq 8 ] && [ "$minor" -ge 3 ]; }; then
        echo "$candidate"
        return 0
      fi
    fi
  done
  return 1
}

install_php83() {
  if ! command -v sudo >/dev/null 2>&1; then
    echo "ERROR: PHP 8.3+ is required and sudo is unavailable to install it."
    exit 1
  fi

  echo "PHP 8.3+ not active/found. Installing PHP 8.3 runtime for this Codespace..."
  sudo apt-get update -y
  sudo apt-get install -y software-properties-common ca-certificates lsb-release apt-transport-https curl unzip git rsync

  if ! apt-cache policy php8.3-cli | grep -q Candidate; then
    sudo add-apt-repository ppa:ondrej/php -y
    sudo apt-get update -y
  fi

  sudo apt-get install -y \
    php8.3 php8.3-cli php8.3-common php8.3-mbstring php8.3-xml php8.3-curl \
    php8.3-sqlite3 php8.3-zip php8.3-bcmath php8.3-tokenizer php8.3-intl php8.3-gd
}

if PHP_BIN="$(choose_php)"; then
  true
else
  install_php83
  PHP_BIN="$(choose_php || true)"
fi

if [ -z "${PHP_BIN:-}" ] || [ ! -x "$PHP_BIN" ]; then
  echo "ERROR: Could not resolve PHP 8.3+ after installation."
  exit 1
fi

PHP_FULL="$($PHP_BIN -r 'echo PHP_VERSION;')"
PHP_MAJOR="$($PHP_BIN -r 'echo PHP_MAJOR_VERSION;')"
PHP_MINOR="$($PHP_BIN -r 'echo PHP_MINOR_VERSION;')"
if [ "$PHP_MAJOR" -lt 8 ] || { [ "$PHP_MAJOR" -eq 8 ] && [ "$PHP_MINOR" -lt 3 ]; }; then
  echo "ERROR: Resolved PHP is $PHP_FULL at $PHP_BIN, but Phase 9.1 requires PHP 8.3+."
  exit 1
fi

echo "Using deterministic PHP: $PHP_BIN ($PHP_FULL)"

# Use a local composer.phar executed explicitly by PHP 8.3+ so the Codespaces PHP 8.0 shim cannot interfere.
COMPOSER_PHAR="$TOOLS_DIR/composer.phar"
if [ ! -f "$COMPOSER_PHAR" ]; then
  echo "Downloading local Composer phar..."
  EXPECTED_CHECKSUM="$($PHP_BIN -r 'copy("https://composer.github.io/installer.sig", "php://stdout");')"
  $PHP_BIN -r 'copy("https://getcomposer.org/installer", "composer-setup.php");'
  ACTUAL_CHECKSUM="$($PHP_BIN -r 'echo hash_file("sha384", "composer-setup.php");')"
  if [ "$EXPECTED_CHECKSUM" != "$ACTUAL_CHECKSUM" ]; then
    rm -f composer-setup.php
    echo "ERROR: Invalid Composer installer checksum."
    exit 1
  fi
  $PHP_BIN composer-setup.php --install-dir="$TOOLS_DIR" --filename=composer.phar --quiet
  rm -f composer-setup.php
fi

$PHP_BIN "$COMPOSER_PHAR" --version
$PHP_BIN "$COMPOSER_PHAR" config --global audit.block-insecure false || true
$PHP_BIN "$COMPOSER_PHAR" config --global --unset platform.php || true
$PHP_BIN "$COMPOSER_PHAR" clear-cache || true

mkdir -p "$ROOT/_archive_old_phases"

# Archive legacy/broken backend folders instead of patching fragments.
STAMP="$(date +%Y%m%d%H%M%S)"
for old in backend backend_partial_restore; do
  if [ -d "$ROOT/$old" ]; then
    mv "$ROOT/$old" "$ROOT/_archive_old_phases/${old}-${STAMP}" || true
  fi
done
if [ -d "$BACKEND" ]; then
  mv "$BACKEND" "$ROOT/_archive_old_phases/backend-laravel-before-phase9-1-${STAMP}" || true
fi

# Create a clean Laravel application. This is a full rebuild foundation, not a fragment patch.
echo "Creating clean Laravel backend at backend-laravel..."
rm -rf "$BACKEND"
$PHP_BIN "$COMPOSER_PHAR" create-project laravel/laravel "$BACKEND" --no-interaction --prefer-dist

cd "$BACKEND"

# Remove default Laravel user migration to avoid conflict with Sawrni unified users table.
find database/migrations -type f -name '*create_users_table.php' -delete || true

mkdir -p routes database/migrations database/seeders config
cp "$PKG_DIR/backend-files/routes/api.php" routes/api.php
cp "$PKG_DIR/backend-files/database/migrations/2026_06_27_090100_create_sawrni_core_tables.php" database/migrations/2026_06_27_090100_create_sawrni_core_tables.php
cp "$PKG_DIR/backend-files/database/seeders/SawrniProductionSeeder.php" database/seeders/SawrniProductionSeeder.php
cp "$PKG_DIR/backend-files/database/seeders/DatabaseSeeder.php" database/seeders/DatabaseSeeder.php
cp "$PKG_DIR/backend-files/config/cors.php" config/cors.php

# Enable routes/api.php for Laravel 11/12/13 bootstrap.
if [ -f bootstrap/app.php ]; then
  $PHP_BIN -r '
  $p="bootstrap/app.php";
  $text=file_get_contents($p);
  if (strpos($text, "routes/api.php") === false) {
      $text=str_replace("web: __DIR__.\'/../routes/web.php\',", "web: __DIR__.\'/../routes/web.php\',\n        api: __DIR__.\'/../routes/api.php\',", $text);
  }
  file_put_contents($p,$text);
  echo "API route loading enabled.\n";
  '
fi

# Configure staging SQLite by default. Production will use PostgreSQL env.
cp .env.example .env
mkdir -p database
touch database/database.sqlite

$PHP_BIN -r '
$p=".env";
$text=file_get_contents($p);
$replacements = [
  "APP_NAME=Laravel" => "APP_NAME=Sawrni",
  "APP_ENV=local" => "APP_ENV=local",
  "APP_DEBUG=true" => "APP_DEBUG=true",
  "DB_CONNECTION=mysql" => "DB_CONNECTION=sqlite",
  "DB_HOST=127.0.0.1" => "# DB_HOST=127.0.0.1",
  "DB_PORT=3306" => "# DB_PORT=3306",
  "DB_DATABASE=laravel" => "# DB_DATABASE=laravel",
  "DB_USERNAME=root" => "# DB_USERNAME=root",
  "DB_PASSWORD=" => "# DB_PASSWORD=",
  "SESSION_DRIVER=database" => "SESSION_DRIVER=file",
  "CACHE_STORE=database" => "CACHE_STORE=file",
  "QUEUE_CONNECTION=database" => "QUEUE_CONNECTION=sync",
];
foreach ($replacements as $old=>$new) { $text=str_replace($old,$new,$text); }
file_put_contents($p,$text);
echo "Configured backend .env for staging SQLite.\n";
'

# Generate the backend exactly once using the deterministic PHP/composer runtime.
$PHP_BIN "$COMPOSER_PHAR" install --no-interaction --prefer-dist
$PHP_BIN artisan key:generate --force
$PHP_BIN artisan migrate:fresh --seed --force
$PHP_BIN artisan route:list | grep 'api/v1' | head -80 || true

mkdir -p "$ROOT/docs"
cp "$PKG_DIR/docs/PHASE_9_1_BACKEND_API_REBUILD.md" "$ROOT/docs/PHASE_9_1_BACKEND_API_REBUILD.md"

mkdir -p "$ROOT/tests/e2e"
cp "$PKG_DIR/tests/e2e/phase9_1_api_smoke.sh" "$ROOT/tests/e2e/phase9_1_api_smoke.sh"
chmod +x "$ROOT/tests/e2e/phase9_1_api_smoke.sh"

cat > "$ROOT/deployment/PHASE_9_1_RUNTIME_LOCK.md" <<EOF2
# Phase 9.1 Runtime Lock

This backend was generated with deterministic PHP:

- PHP binary: $PHP_BIN
- PHP version: $PHP_FULL
- Composer phar: $COMPOSER_PHAR

The installer does not rely on Codespaces' default /home/codespace/.php/current PHP path.
EOF2

echo "PASS: Phase 9.1 backend production API rebuild applied with PHP $PHP_FULL."
echo "Next: cd backend-laravel && $PHP_BIN artisan serve --host=0.0.0.0 --port=8010"
