# صورني Phase 9.1 — إعادة بناء Backend API v2

هذه النسخة تعيد بناء `backend-laravel` بشكل نظيف اعتمادًا على وثيقة Phase 3 Database/API Blueprint.

تصحيح مهم في v2:
- لا تعتمد على مسار PHP القديم في Codespaces `/home/codespace/.php/current`.
- تبحث عن PHP 8.3+ أو تثبته.
- تنزل Composer PHAR محلي وتقوم بتشغيله بواسطة PHP 8.3+ مباشرة.
- تؤرشف أجزاء الباك إند القديمة وتبني Laravel جديد ونظيف.

شغّل من جذر المشروع:

```bash
rm -rf _phase9_1
unzip -o Sawrni_Phase_9_1_Backend_Production_API_Rebuild_v2.zip -d _phase9_1
bash _phase9_1/sawrni_phase9_1_pkg/scripts/apply_phase9_1_backend_api_rebuild.sh
```
