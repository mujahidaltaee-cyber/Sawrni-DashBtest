#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-http://127.0.0.1:8010/api/v1}"

echo "Testing Sawrni API at $BASE_URL"

curl -fsS "$BASE_URL/health" >/tmp/sawrni_health.json
cat /tmp/sawrni_health.json && echo

ADMIN_TOKEN=$(curl -fsS -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{"phone":"07000000000","password":"password"}' | php -r '$j=json_decode(stream_get_contents(STDIN), true); echo $j["data"]["token"] ?? $j["data"]["access_token"] ?? "";')

if [ -z "$ADMIN_TOKEN" ]; then
  echo "Admin token not returned"
  exit 1
fi

curl -fsS "$BASE_URL/admin/dashboard" -H "Authorization: Bearer $ADMIN_TOKEN" >/tmp/sawrni_dashboard.json
cat /tmp/sawrni_dashboard.json && echo

CUSTOMER_TOKEN=$(curl -fsS -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{"phone":"07000000001","password":"password"}' | php -r '$j=json_decode(stream_get_contents(STDIN), true); echo $j["data"]["token"] ?? $j["data"]["access_token"] ?? "";')

PACKAGE_ID=$(curl -fsS "$BASE_URL/providers/1" | php -r '$j=json_decode(stream_get_contents(STDIN), true); echo $j["data"]["packages"][0]["id"] ?? "1";')

BOOKING_ID=$(curl -fsS -X POST "$BASE_URL/bookings" \
  -H "Authorization: Bearer $CUSTOMER_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"package_id\":$PACKAGE_ID,\"location_text\":\"Baghdad staging test\"}" | php -r '$j=json_decode(stream_get_contents(STDIN), true); echo $j["data"]["id"] ?? "";')

if [ -z "$BOOKING_ID" ]; then
  echo "Booking was not created"
  exit 1
fi

echo "Created booking $BOOKING_ID"

curl -fsS -X POST "$BASE_URL/bookings/$BOOKING_ID/pay-deposit" \
  -H "Authorization: Bearer $CUSTOMER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"method":"cash"}' >/tmp/sawrni_pay.json
cat /tmp/sawrni_pay.json && echo

echo "PASS: Phase 9.1 API smoke test passed."
