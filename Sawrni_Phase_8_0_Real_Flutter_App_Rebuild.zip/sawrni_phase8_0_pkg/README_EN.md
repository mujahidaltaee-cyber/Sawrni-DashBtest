# Sawrni Phase 8.0 — Real Flutter App Rebuild

This replaces scattered Flutter phase fragments with a single integrated Arabic RTL mobile app:

- Sawrni branding and slogan.
- Role choice for customer/provider.
- Phone sign-in + test OTP 123456.
- Customer home, provider list, details, booking request.
- Provider dashboard, approval status, accept/reject requests.
- Premium navy/purple/gold identity.
- Brand assets folder and GitHub Actions APK build workflow.

The apply script tries to detect uploaded Sawrni PNG logo/icon files in the repo and use them as `logo.png` and `app_icon.png`. If no uploaded PNG is found, it keeps a temporary premium placeholder.
