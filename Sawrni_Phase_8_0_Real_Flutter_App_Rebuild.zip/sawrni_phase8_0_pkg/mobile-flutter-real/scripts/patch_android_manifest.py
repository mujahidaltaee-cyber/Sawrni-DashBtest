from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    print('AndroidManifest.xml not found yet. Skipping manifest patch.')
    raise SystemExit(0)

text = manifest.read_text()
text = re.sub(r'android:label="[^"]*"', 'android:label="صورني"', text)
if 'android:usesCleartextTraffic=' not in text:
    text = text.replace('<application ', '<application android:usesCleartextTraffic="true" ', 1)
manifest.write_text(text)
print('Patched Android app label to صورني.')
