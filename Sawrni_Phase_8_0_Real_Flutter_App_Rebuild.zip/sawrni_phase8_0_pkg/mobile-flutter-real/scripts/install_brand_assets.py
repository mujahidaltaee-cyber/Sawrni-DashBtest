from pathlib import Path
import shutil

ROOT = Path.cwd().parent if Path.cwd().name == 'mobile-flutter' else Path.cwd()
MOBILE = ROOT / 'mobile-flutter'
BRAND = MOBILE / 'assets' / 'brand'
BRAND.mkdir(parents=True, exist_ok=True)

skip_parts = {'.git', 'node_modules', 'build', '.next', '_phase7_1', '_phase7_2', '_phase7_3', '_phase7_4', '_phase7_5', '_phase7_6', '_phase7_7', '_phase7_8', '_phase7_9', '_phase8_0'}
patterns = ['*sawwarni*.png', '*sawrni*.png', '*صورني*.png', '*logo*.png', '*icon*.png', '*brand*.png']

candidates = []
for pattern in patterns:
    for p in ROOT.rglob(pattern):
        if any(part in skip_parts for part in p.parts):
            continue
        if p.is_file() and p.suffix.lower() == '.png':
            score = 0
            lower = str(p).lower()
            for key, points in [('sawwarni', 50), ('sawrni', 50), ('صورني', 50), ('header', 20), ('logo', 15), ('icon', 15), ('brand', 8)]:
                if key in lower:
                    score += points
            candidates.append((score, p))

candidates.sort(reverse=True, key=lambda x: x[0])

if candidates:
    src = candidates[0][1]
    shutil.copy2(src, BRAND / 'logo.png')
    shutil.copy2(src, BRAND / 'app_icon.png')
    print(f'Using uploaded visual identity PNG as logo/app icon: {src}')
else:
    print('No uploaded Sawrni PNG logo/icon found. Keeping premium placeholder. Put your PNG at mobile-flutter/assets/brand/app_icon.png and logo.png, then rebuild.')
