import 'package:flutter/material.dart';
import 'core/theme/sawrni_theme.dart';
import 'features/auth/role_choice_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SawrniApp());
}

class SawrniApp extends StatelessWidget {
  const SawrniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'صورني',
      theme: SawrniTheme.light(),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: RoleChoiceScreen(),
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink());
      },
    );
  }
}
