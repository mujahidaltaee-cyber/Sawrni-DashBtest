import 'package:flutter/material.dart';
import '../brand/sawrni_brand.dart';

class SawrniTheme {
  SawrniTheme._();

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: SawrniBrand.purple,
      brightness: Brightness.light,
      primary: SawrniBrand.purple,
      secondary: SawrniBrand.gold,
      surface: SawrniBrand.card,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: SawrniBrand.paper,
      fontFamilyFallback: const ['SF Pro Display', 'Segoe UI', 'Arial'],
      textTheme: const TextTheme(
        displayLarge: TextStyle(fontWeight: FontWeight.w800, color: SawrniBrand.navy),
        displayMedium: TextStyle(fontWeight: FontWeight.w800, color: SawrniBrand.navy),
        headlineLarge: TextStyle(fontWeight: FontWeight.w800, color: SawrniBrand.navy),
        headlineMedium: TextStyle(fontWeight: FontWeight.w800, color: SawrniBrand.navy),
        titleLarge: TextStyle(fontWeight: FontWeight.w800, color: SawrniBrand.navy),
        titleMedium: TextStyle(fontWeight: FontWeight.w700, color: SawrniBrand.navy),
        bodyLarge: TextStyle(color: SawrniBrand.ink, height: 1.45),
        bodyMedium: TextStyle(color: SawrniBrand.ink, height: 1.45),
      ),
      appBarTheme: const AppBarTheme(
        centerTitle: false,
        elevation: 0,
        backgroundColor: SawrniBrand.paper,
        foregroundColor: SawrniBrand.navy,
        surfaceTintColor: Colors.transparent,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        hintStyle: const TextStyle(color: SawrniBrand.muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: SawrniBrand.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: SawrniBrand.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: SawrniBrand.purple, width: 1.4)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: SawrniBrand.purple,
          foregroundColor: Colors.white,
          elevation: 0,
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: SawrniBrand.navy,
          side: const BorderSide(color: SawrniBrand.border),
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: const BorderSide(color: SawrniBrand.border),
        ),
      ),
    );
  }
}
