import 'package:flutter/material.dart';

class SawrniBrand {
  SawrniBrand._();

  static const String arabicName = 'صورني';
  static const String englishName = 'Sawrni';
  static const String slogan = 'استوديو كامل بجيبك';

  // Premium Sawrni visual direction: deep navy, royal purple, soft gold, warm ivory.
  static const Color navy = Color(0xFF071426);
  static const Color ink = Color(0xFF0D1321);
  static const Color purple = Color(0xFF5B2FB0);
  static const Color purpleDark = Color(0xFF3F1F86);
  static const Color gold = Color(0xFFF4C04E);
  static const Color ivory = Color(0xFFFFF8EA);
  static const Color paper = Color(0xFFF6F3ED);
  static const Color card = Color(0xFFFFFFFF);
  static const Color muted = Color(0xFF667085);
  static const Color border = Color(0xFFE6E1D8);
  static const Color success = Color(0xFF11845B);
  static const Color danger = Color(0xFFC2410C);
}
