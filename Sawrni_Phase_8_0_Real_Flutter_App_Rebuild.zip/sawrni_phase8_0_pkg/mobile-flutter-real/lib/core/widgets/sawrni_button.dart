import 'package:flutter/material.dart';
import '../brand/sawrni_brand.dart';

class SawrniButton extends StatelessWidget {
  const SawrniButton({super.key, required this.label, required this.onPressed, this.icon, this.secondary = false});

  final String label;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool secondary;

  @override
  Widget build(BuildContext context) {
    final child = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      textDirection: TextDirection.rtl,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 20),
          const SizedBox(width: 8),
        ],
        Text(label, textDirection: TextDirection.rtl),
      ],
    );
    return secondary ? OutlinedButton(onPressed: onPressed, child: child) : ElevatedButton(onPressed: onPressed, child: child);
  }
}

class PremiumTag extends StatelessWidget {
  const PremiumTag({super.key, required this.text, this.icon});
  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: SawrniBrand.gold.withValues(alpha: .14),
        border: Border.all(color: SawrniBrand.gold.withValues(alpha: .45)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        textDirection: TextDirection.rtl,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16, color: SawrniBrand.purple),
            const SizedBox(width: 6),
          ],
          Text(text, textDirection: TextDirection.rtl, style: const TextStyle(color: SawrniBrand.navy, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}
