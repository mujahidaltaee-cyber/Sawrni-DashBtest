import 'package:flutter/material.dart';
import '../brand/sawrni_brand.dart';

class BrandLogo extends StatelessWidget {
  const BrandLogo({super.key, this.size = 76, this.showText = true, this.dark = false});

  final double size;
  final bool showText;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final nameColor = dark ? Colors.white : SawrniBrand.navy;
    final sloganColor = dark ? Colors.white70 : SawrniBrand.muted;
    return Row(
      mainAxisSize: MainAxisSize.min,
      textDirection: TextDirection.rtl,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: dark ? Colors.white.withValues(alpha: .09) : Colors.white,
            borderRadius: BorderRadius.circular(size * .28),
            border: Border.all(color: dark ? Colors.white24 : SawrniBrand.border),
            boxShadow: [
              BoxShadow(
                color: SawrniBrand.purple.withValues(alpha: .12),
                blurRadius: 24,
                offset: const Offset(0, 14),
              ),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Padding(
            padding: EdgeInsets.all(size * .12),
            child: Image.asset(
              'assets/brand/logo.png',
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => Center(
                child: Text(
                  'ص',
                  style: TextStyle(
                    color: dark ? SawrniBrand.gold : SawrniBrand.purple,
                    fontSize: size * .48,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ),
        ),
        if (showText) ...[
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                SawrniBrand.arabicName,
                textDirection: TextDirection.rtl,
                style: TextStyle(color: nameColor, fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -.5),
              ),
              Text(
                SawrniBrand.slogan,
                textDirection: TextDirection.rtl,
                style: TextStyle(color: sloganColor, fontSize: 13, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ],
      ],
    );
  }
}
