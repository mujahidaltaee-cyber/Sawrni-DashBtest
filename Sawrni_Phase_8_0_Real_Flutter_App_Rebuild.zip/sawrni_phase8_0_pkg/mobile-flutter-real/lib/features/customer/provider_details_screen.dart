import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/sawrni_button.dart';
import '../shared/models.dart';

class ProviderDetailsScreen extends StatelessWidget {
  const ProviderDetailsScreen({super.key, required this.provider});
  final ProviderProfile provider;

  @override
  Widget build(BuildContext context) {
    final commission = (provider.startingPrice * .15).round();
    return Scaffold(
      appBar: AppBar(title: Text(provider.name)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              height: 210,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(32), gradient: const LinearGradient(colors: [SawrniBrand.navy, SawrniBrand.purple])),
              child: Center(child: Text(provider.coverLabel, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900))),
            ),
            const SizedBox(height: 18),
            Text(provider.name, style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Row(textDirection: TextDirection.rtl, children: [
              const Icon(Icons.star_rounded, color: SawrniBrand.gold),
              const SizedBox(width: 4),
              Text('${provider.rating}', style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(width: 12),
              Text(provider.type, style: const TextStyle(color: SawrniBrand.muted, fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('تفاصيل الحجز', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 12),
                  _line('السعر الابتدائي', iq(provider.startingPrice)),
                  _line('عمولة المنصة 15%', iq(commission)),
                  _line('حالة التواصل', 'مخفي حتى تأكيد الحجز'),
                ]),
              ),
            ),
            const SizedBox(height: 18),
            SawrniButton(
              label: 'طلب حجز',
              icon: Icons.calendar_month_outlined,
              onPressed: () => _showBookingSheet(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _line(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(textDirection: TextDirection.rtl, children: [
          Expanded(child: Text(a, style: const TextStyle(color: SawrniBrand.muted, fontWeight: FontWeight.w700))),
          Text(b, style: const TextStyle(fontWeight: FontWeight.w900)),
        ]),
      );

  void _showBookingSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.fromLTRB(18, 12, 18, MediaQuery.of(context).viewInsets.bottom + 18),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('طلب حجز مع ${provider.name}', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            const TextField(decoration: InputDecoration(labelText: 'نوع التصوير المطلوب')),
            const SizedBox(height: 10),
            const TextField(decoration: InputDecoration(labelText: 'الموقع')),
            const SizedBox(height: 10),
            const TextField(decoration: InputDecoration(labelText: 'التاريخ والوقت المناسب')),
            const SizedBox(height: 14),
            SawrniButton(
              label: 'إرسال الطلب',
              icon: Icons.send_outlined,
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء طلب الحجز - بانتظار موافقة المزود')));
              },
            ),
          ]),
        ),
      ),
    );
  }
}
