import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/brand_logo.dart';
import '../shared/models.dart';
import 'provider_details_screen.dart';

class CustomerHomeScreen extends StatelessWidget {
  const CustomerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = [
      ('تصوير مناسبات', Icons.celebration_outlined),
      ('جلسات شخصية', Icons.portrait_outlined),
      ('مونتاج وتعديل', Icons.auto_fix_high_outlined),
      ('مودلز', Icons.groups_2_outlined),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const BrandLogo(size: 44),
        actions: const [Padding(padding: EdgeInsetsDirectional.only(end: 12), child: Icon(Icons.notifications_none_rounded))],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: const LinearGradient(colors: [SawrniBrand.navy, SawrniBrand.purpleDark]),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ماذا تريد أن تصوّر اليوم؟', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                  SizedBox(height: 8),
                  Text('اختر الخدمة، شاهد المزودين المعتمدين، وابدأ الحجز بدون كشف بياناتك قبل التأكيد.', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white70, height: 1.5, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text('الخدمات', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: categories.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.42, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemBuilder: (_, index) {
                final item = categories[index];
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(item.$2, color: SawrniBrand.purple, size: 30),
                      const Spacer(),
                      Text(item.$1, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    ]),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            Text('مزودون معتمدون', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...sampleProviders.map((p) => _ProviderCard(provider: p)),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'حجوزاتي'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class _ProviderCard extends StatelessWidget {
  const _ProviderCard({required this.provider});
  final ProviderProfile provider;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProviderDetailsScreen(provider: provider))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                height: 76,
                width: 76,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: LinearGradient(colors: [SawrniBrand.purple.withValues(alpha: .9), SawrniBrand.gold.withValues(alpha: .9)]),
                ),
                child: Center(child: Text(provider.coverLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11))),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(provider.name, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
                    const Icon(Icons.verified, color: SawrniBrand.purple, size: 18),
                  ]),
                  const SizedBox(height: 5),
                  Text('${provider.type} • ${provider.city}', textDirection: TextDirection.rtl, style: const TextStyle(color: SawrniBrand.muted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text('يبدأ من ${iq(provider.startingPrice)}', textDirection: TextDirection.rtl, style: const TextStyle(color: SawrniBrand.navy, fontWeight: FontWeight.w900)),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
