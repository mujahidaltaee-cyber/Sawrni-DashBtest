import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/brand_logo.dart';
import '../../core/widgets/sawrni_button.dart';
import '../shared/models.dart';
import 'otp_screen.dart';

class PhoneSignInScreen extends StatefulWidget {
  const PhoneSignInScreen({super.key, required this.role});
  final UserRole role;

  @override
  State<PhoneSignInScreen> createState() => _PhoneSignInScreenState();
}

class _PhoneSignInScreenState extends State<PhoneSignInScreen> {
  final controller = TextEditingController(text: '07');

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.role == UserRole.customer ? 'تسجيل دخول العميل' : 'تسجيل دخول مزود الخدمة';
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(22),
          children: [
            const BrandLogo(size: 64),
            const SizedBox(height: 32),
            Text(title, style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            const Text(
              'أدخل رقم الهاتف لإرسال رمز التحقق. نسخة الاختبار تقبل الرمز 123456.',
              textDirection: TextDirection.rtl,
              style: TextStyle(color: SawrniBrand.muted, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: controller,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                labelText: 'رقم الهاتف',
                hintText: '07XXXXXXXXX',
                prefixIcon: Icon(Icons.phone_iphone_outlined),
              ),
            ),
            const SizedBox(height: 18),
            SawrniButton(
              label: 'إرسال رمز التحقق',
              icon: Icons.sms_outlined,
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OtpScreen(role: widget.role, phone: controller.text.trim()),
                ));
              },
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: SawrniBrand.ivory, borderRadius: BorderRadius.circular(22), border: Border.all(color: SawrniBrand.border)),
              child: const Text(
                'ملاحظة الأمان: بيانات التواصل تبقى مخفية حتى تأكيد الحجز والدفع حسب قواعد صورني.',
                textDirection: TextDirection.rtl,
                style: TextStyle(color: SawrniBrand.navy, fontWeight: FontWeight.w700, height: 1.45),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
