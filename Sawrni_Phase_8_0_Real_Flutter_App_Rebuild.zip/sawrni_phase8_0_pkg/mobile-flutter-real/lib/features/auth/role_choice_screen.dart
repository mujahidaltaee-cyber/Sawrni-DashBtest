import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/brand_logo.dart';
import '../../core/widgets/sawrni_button.dart';
import '../shared/models.dart';
import 'phone_sign_in_screen.dart';

class RoleChoiceScreen extends StatelessWidget {
  const RoleChoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [SawrniBrand.navy, SawrniBrand.purpleDark],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 24),
                const Align(alignment: Alignment.centerRight, child: BrandLogo(dark: true)),
                const Spacer(),
                const Text(
                  'احجز مصور، محرر، أو مودل خلال دقائق.',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: Colors.white, fontSize: 34, height: 1.1, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 14),
                Text(
                  'من الطلب إلى التسليم داخل تجربة واحدة آمنة وواضحة.',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: Colors.white.withValues(alpha: .78), fontSize: 16, height: 1.55, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 22),
                const Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.end,
                  children: [
                    PremiumTag(text: 'بغداد أولاً', icon: Icons.location_on_outlined),
                    PremiumTag(text: 'حجز آمن', icon: Icons.lock_outline),
                    PremiumTag(text: 'مزودون معتمدون', icon: Icons.verified_outlined),
                  ],
                ),
                const Spacer(),
                SawrniButton(
                  label: 'الدخول كعميل',
                  icon: Icons.person_outline,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PhoneSignInScreen(role: UserRole.customer))),
                ),
                const SizedBox(height: 12),
                SawrniButton(
                  label: 'الدخول كمزود خدمة',
                  icon: Icons.camera_alt_outlined,
                  secondary: true,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PhoneSignInScreen(role: UserRole.provider))),
                ),
                const SizedBox(height: 18),
                Text(
                  SawrniBrand.slogan,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withValues(alpha: .68), fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
