import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/sawrni_button.dart';
import '../customer/customer_home_screen.dart';
import '../provider/provider_home_screen.dart';
import '../shared/models.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key, required this.role, required this.phone});
  final UserRole role;
  final String phone;

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final code = TextEditingController(text: '123456');
  String? error;

  @override
  void dispose() {
    code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التحقق')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(22),
          children: [
            Text('أدخل رمز التحقق', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('تم إرسال الرمز إلى ${widget.phone}', textDirection: TextDirection.rtl, style: const TextStyle(color: SawrniBrand.muted, fontWeight: FontWeight.w600)),
            const SizedBox(height: 24),
            TextField(
              controller: code,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
              maxLength: 6,
              style: const TextStyle(fontSize: 28, letterSpacing: 10, fontWeight: FontWeight.w900),
              decoration: InputDecoration(errorText: error, counterText: ''),
            ),
            const SizedBox(height: 18),
            SawrniButton(
              label: 'دخول',
              icon: Icons.login,
              onPressed: () {
                if (code.text.trim() != '123456') {
                  setState(() => error = 'رمز الاختبار هو 123456');
                  return;
                }
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => widget.role == UserRole.customer ? const CustomerHomeScreen() : const ProviderHomeScreen()),
                  (_) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
