enum UserRole { customer, provider }

class ProviderProfile {
  const ProviderProfile({
    required this.name,
    required this.type,
    required this.rating,
    required this.city,
    required this.startingPrice,
    required this.approved,
    required this.coverLabel,
  });

  final String name;
  final String type;
  final double rating;
  final String city;
  final int startingPrice;
  final bool approved;
  final String coverLabel;
}

class BookingRequest {
  const BookingRequest({
    required this.title,
    required this.customer,
    required this.date,
    required this.location,
    required this.price,
    required this.status,
  });

  final String title;
  final String customer;
  final String date;
  final String location;
  final int price;
  final String status;
}

const sampleProviders = [
  ProviderProfile(name: 'استوديو عدسة بغداد', type: 'تصوير مناسبات', rating: 4.9, city: 'بغداد', startingPrice: 150000, approved: true, coverLabel: 'Wedding'),
  ProviderProfile(name: 'نور فوتوغرافي', type: 'جلسات شخصية', rating: 4.8, city: 'المنصور', startingPrice: 90000, approved: true, coverLabel: 'Portrait'),
  ProviderProfile(name: 'Frame Edit', type: 'مونتاج وتعديل', rating: 4.7, city: 'أونلاين', startingPrice: 45000, approved: true, coverLabel: 'Editing'),
];

const sampleRequests = [
  BookingRequest(title: 'تصوير تخرج', customer: 'عميل محجوب حتى التأكيد', date: 'الأحد 7:00 مساءً', location: 'بغداد - الجادرية', price: 180000, status: 'بانتظار قرارك'),
  BookingRequest(title: 'جلسة منتجات', customer: 'عميل محجوب حتى التأكيد', date: 'الثلاثاء 4:30 مساءً', location: 'الكرادة', price: 220000, status: 'وديعة مطلوبة'),
];

String iq(int amount) => '${amount.toString().replaceAllMapped(RegExp(r"\B(?=(\d{3})+(?!\d))"), (m) => ',')} د.ع';
