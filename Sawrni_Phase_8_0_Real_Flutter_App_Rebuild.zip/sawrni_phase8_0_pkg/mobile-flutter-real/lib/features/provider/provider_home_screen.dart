import 'package:flutter/material.dart';
import '../../core/brand/sawrni_brand.dart';
import '../../core/widgets/brand_logo.dart';
import '../../core/widgets/sawrni_button.dart';
import '../shared/models.dart';

class ProviderHomeScreen extends StatelessWidget {
  const ProviderHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const BrandLogo(size: 44), actions: const [Padding(padding: EdgeInsetsDirectional.only(end: 12), child: Icon(Icons.notifications_none_rounded))]),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              color: SawrniBrand.navy,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('لوحة مزود الخدمة', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text('الحساب لا يظهر للعملاء إلا بعد موافقة COO / Super Admin.', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white.withValues(alpha: .74), fontWeight: FontWeight.w700, height: 1.5)),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(color: SawrniBrand.gold.withValues(alpha: .18), borderRadius: BorderRadius.circular(99)),
                    child: const Text('الحالة: بانتظار الاعتماد', style: TextStyle(color: SawrniBrand.gold, fontWeight: FontWeight.w900)),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 20),
            Text('طلبات الحجز الواردة', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...sampleRequests.map((r) => _BookingCard(request: r)),
            const SizedBox(height: 20),
            SawrniButton(label: 'تعديل ملفي كمزود', icon: Icons.badge_outlined, secondary: true, onPressed: () {}),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'لوحتي'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'الحجوزات'),
          NavigationDestination(icon: Icon(Icons.upload_file_outlined), label: 'التسليم'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  const _BookingCard({required this.request});
  final BookingRequest request;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(request.title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: SawrniBrand.purple.withValues(alpha: .1), borderRadius: BorderRadius.circular(99)), child: Text(request.status, style: const TextStyle(color: SawrniBrand.purple, fontSize: 12, fontWeight: FontWeight.w900))),
          ]),
          const SizedBox(height: 10),
          _info(Icons.person_outline, request.customer),
          _info(Icons.schedule_outlined, request.date),
          _info(Icons.location_on_outlined, request.location),
          _info(Icons.payments_outlined, iq(request.price)),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: SawrniButton(label: 'قبول', icon: Icons.check, onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم قبول الطلب'))))),
            const SizedBox(width: 10),
            Expanded(child: SawrniButton(label: 'رفض', icon: Icons.close, secondary: true, onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم رفض الطلب'))))),
          ]),
        ]),
      ),
    );
  }

  Widget _info(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(top: 7),
        child: Row(textDirection: TextDirection.rtl, children: [
          Icon(icon, size: 18, color: SawrniBrand.muted),
          const SizedBox(width: 8),
          Expanded(child: Text(text, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.w700, color: SawrniBrand.muted))),
        ]),
      );
}
