# صورني — حزمة الكود Phase 4 v0.7

هذه النسخة تنقل المشروع من مرحلة الـ scaffolding إلى مرحلة **ربط بيتا محلية** يمكن للمطور تركيبها وتشغيلها واختبارها محلياً.

## ما تمت إضافته في v0.7

- دمج فعلي للمسارات المهمة داخل routes/api.php.
- Docker Compose للتشغيل المحلي.
- ملفات بيئة محلية.
- Health endpoints للباك إند.
- Middleware aliases للأدوار، صلاحيات الأدمن، موافقة مزود الخدمة، و webhooks الدفع.
- سكربتات تشغيل واختبار أولي.
- Postman collection لاختبار الـ API.
- Flutter app shell متصل بطبقة الـ API.
- Admin Web shell مع login وحماية بسيطة.
- QA checklist للتأكد من الرحلة الكاملة.

## الحالة

هذه نسخة **Developer-run beta foundation** وليست نسخة إنتاج نهائية. يجب على المطور تشغيل dependencies، تنفيذ migrations، ثم إجراء smoke tests قبل اعتبارها نسخة بيتا عاملة.

## القواعد المحفوظة

- نسبة صورني 15% من كامل قيمة الحجز.
- حد الدين قبل التعليق: 75,000 دينار عراقي.
- تعديل الحجز خلال 3 ساعات بعد دفع العربون.
- الإلغاء المسترجع للعربون خلال ساعة بعد دفع العربون.
- الشات وأرقام الهاتف تفتح فقط بعد دفع العربون.
- مزود الخدمة لا يظهر إلا بعد الموافقة.
- ملفات التسليم لا تظهر للعميل إلا بعد موافقة الإدارة.


## Phase 4 v0.8

This package adds developer-verification wiring, booking flow state endpoint scaffold, Flutter booking flow model/repository, admin beta verification page, and environment verification scripts. It is still intended for developer/local beta use before staging.

## Phase 4 v0.9 — جاهزية الرفع إلى Staging

تضيف نسخة v0.9 ملفات وتجهيزات الرفع إلى بيئة Staging، مع أدوات فحص أولية. هذه الحزمة جاهزة ليبدأ المطور محاولة الرفع التجريبي، لكنها لم تُشغّل بعد داخل بيئة السيرفر النهائية.

أهم الملفات:

- `docs/STAGING_DEPLOYMENT_RUNBOOK_V0_9.md`
- `docs/STAGING_SMOKE_TEST_CHECKLIST_V0_9.md`
- `backend-laravel/.env.staging.example`
- `admin-web/.env.staging.example`
- `infrastructure/staging/docker-compose.staging.yml`
- `scripts/staging-smoke-test.sh`

بعد الرفع إلى Staging، يتم تشغيل فحص سريع:

```bash
API_BASE_URL=https://api-staging.sawrni.com/api/v1 ./scripts/staging-smoke-test.sh
```

## Phase 4 v1.0 — حزمة البيتا الموحّدة

هذه الحزمة توحّد كل تحديثات Phase 4 في ملف واحد جاهز للتسليم للمطور.

ابدأ من هنا:

- `START_HERE_EN.md`
- `START_HERE_AR.md`
- `docs/DEVELOPER_HANDOFF_GUIDE_V1_0.md`
- `docs/BETA_ACCEPTANCE_CHECKLIST_V1_0.md`
- `docs/PHASE_5_PLAN_RUNTIME_FIXES_AND_STAGING.md`

الحالة الحالية: جاهزة لفحص المطور والتشغيل المحلي، وليست جاهزة للإطلاق الإنتاجي العام.
