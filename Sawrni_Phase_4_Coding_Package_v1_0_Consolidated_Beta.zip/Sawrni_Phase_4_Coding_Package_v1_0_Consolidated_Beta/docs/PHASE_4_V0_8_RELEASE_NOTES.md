# Sawrni Phase 4 v0.8 Release Notes

## Purpose

Phase 4 v0.8 moves the project from **local runnable beta wiring** toward a **developer-verified beta package**. The goal is to make the end-to-end flow easier for a developer to install, verify, debug, and extend before staging deployment.

## Main additions

1. Added an end-to-end verification test plan for:
   - Customer registration/login
   - Provider approval
   - Provider service creation
   - Customer booking creation
   - Deposit intent creation
   - Fake deposit confirmation
   - Provider booking acceptance
   - Chat unlock
   - Delivery upload
   - Admin delivery approval
   - Customer download visibility

2. Added customer booking flow coordinator scaffold to simplify mobile integration.

3. Added admin beta data adapter patterns for tables that need real API data.

4. Added Flutter booking form wiring notes and payment callback handling notes.

5. Added environment verification script for local setup sanity checks.

6. Added route and permission acceptance checklist.

## Still not production-ready

The package still needs a developer to run it in a full Laravel/Flutter/Next environment and resolve runtime-specific issues. This release is a stronger beta handoff, not the final app-store or production deployment.

## Recommended next phase

Phase 4 v0.9 should focus on staging readiness:

- Real `.env` staging examples
- Server deployment checklist
- Database backup strategy
- Object storage bucket policy
- Admin dashboard API completion
- Flutter complete navigation polish
- Push notification live test path
