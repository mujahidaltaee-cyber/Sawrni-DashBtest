# v0.8 Runtime Issue Register

Use this file during the first developer-run session.

| ID | Area | Issue | Severity | Owner | Status | Fix notes |
|---|---|---|---|---|---|---|
| V08-001 | Backend | Pending first run | High | Backend developer | Open | Run composer/migrations/tests |
| V08-002 | Admin web | Pending first run | Medium | Frontend developer | Open | Run npm install/dev |
| V08-003 | Flutter | Pending first run | Medium | Mobile developer | Open | Run pub get/analyze |
| V08-004 | Payment | Live gateway not connected | High | Backend developer | Open | Replace fake gateway with live credentials later |
| V08-005 | iOS | Signing not configured | Medium | Mobile developer | Open | Needs Apple developer setup |
