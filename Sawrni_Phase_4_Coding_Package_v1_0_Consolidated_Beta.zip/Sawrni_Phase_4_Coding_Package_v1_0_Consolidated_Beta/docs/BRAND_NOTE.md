# Brand Direction

The UI starter uses the Sawrni visual direction:

- Primary color: dark navy
- Secondary color: gold
- Accent color: purple for location / pin elements
- Style: modern, clean, premium, and photography-focused

Official assets should be placed later in:

- `mobile-flutter/assets/images/`
- `mobile-flutter/assets/icons/`
- `admin-web/public/`
