# Developer Run and Build Instructions — v0.6

## 1. Backend Laravel

Create a clean Laravel project, then copy the `backend-laravel` folder contents into the project root.

Recommended local commands:

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan serve
```

For Sanctum:

```bash
php artisan vendor:publish --provider="Laravel\\Sanctum\\SanctumServiceProvider"
php artisan migrate
```

For queues:

```bash
php artisan queue:work
```

For scheduled debt checks:

```bash
php artisan schedule:work
```

## 2. Flutter Mobile

Create or open a Flutter project and merge the `mobile-flutter/lib` files.

```bash
flutter pub get
flutter analyze
flutter run
```

Update the API base URL in:

```text
lib/config/app_environment.dart
```

## 3. Admin Web

Use Next.js App Router structure.

```bash
npm install
npm run dev
```

Set the backend API URL in `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://127.0.0.1:8000/api/v1
```

## 4. Minimum Local Test Flow

1. Seed demo users.
2. Login as customer.
3. Browse categories and providers.
4. Create booking.
5. Create deposit intent.
6. Confirm deposit using fake gateway.
7. Login as provider.
8. Accept booking.
9. Upload final delivery.
10. Login as admin/super admin.
11. Approve delivery.
12. Confirm wallet ledger and 15% commission.
