# Production Readiness Gap Register v0.9

| Gap | Current Status | Required Before Production |
|---|---|---|
| Real payment gateway | Scaffold only | Complete sandbox certification and production credentials |
| SMS / OTP provider | Structure only | Select provider and implement real OTP delivery |
| Push notifications | Scaffold only | Configure Firebase project and service credentials |
| File scanning | Not implemented | Add malware/file safety scanning if needed |
| Legal documents | Not implemented | Terms, privacy policy, refund policy, provider agreement |
| Production monitoring | Not implemented | Add uptime, error, queue, and log monitoring |
| Full QA | Not executed here | Run manual and automated QA on staging |
| App store builds | Not prepared | Prepare Android AAB and iOS archive |
| Arabic/English translation polish | Initial strings | Review copy in both languages |
| Payment reconciliation | Scaffolded | Add final accounting export and settlement process |
| Provider subscription billing | Scaffolded | Connect to payment process and subscription renewal logic |
| Admin audit export | Partial | Add detailed audit filters/export if needed |

## Risk Rating

The highest risk before production is payment, OTP, and file-delivery security. These must be tested on staging before public launch.
