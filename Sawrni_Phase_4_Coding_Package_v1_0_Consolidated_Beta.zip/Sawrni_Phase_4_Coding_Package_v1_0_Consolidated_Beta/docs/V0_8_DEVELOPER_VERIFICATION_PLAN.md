# v0.8 Developer Verification Plan

## 1. Environment verification

Run:

```bash
make up
bash scripts/verify-environment.sh
```

Expected:

- PostgreSQL container is running.
- Redis container is running.
- MinIO console is reachable.
- Mailpit is reachable.
- Backend `.env` exists.
- Admin `.env.local` exists.
- Flutter dependencies can be resolved.

## 2. Backend verification

```bash
cd backend-laravel
composer install
php artisan key:generate
php artisan migrate:fresh --seed
php artisan test
php artisan serve --host=0.0.0.0 --port=8000
```

Check:

```text
GET /api/v1/health
GET /api/v1/local-beta/status
```

## 3. Admin verification

```bash
cd admin-web
npm install
npm run dev
```

Check:

```text
http://127.0.0.1:3000/login
http://127.0.0.1:3000/dashboard
```

## 4. Flutter verification

```bash
cd mobile-flutter
flutter pub get
flutter analyze
flutter run
```

Check:

- Login screen opens.
- Customer home opens.
- Bookings screen loads.
- Provider dashboard shell opens with provider account.
- API base URL points to local backend.

## 5. Business-rule verification

Confirm these rules:

- Provider does not appear publicly before approval.
- Customer cannot access chat before deposit.
- Customer can edit booking only within 3 hours after deposit payment.
- Customer can cancel with refund policy only within 1 hour after deposit payment.
- 15% platform commission is calculated on total booking amount.
- Provider account is suspendable when debt reaches 75,000 IQD.
- Final delivery package is hidden until admin/super-admin approval.
