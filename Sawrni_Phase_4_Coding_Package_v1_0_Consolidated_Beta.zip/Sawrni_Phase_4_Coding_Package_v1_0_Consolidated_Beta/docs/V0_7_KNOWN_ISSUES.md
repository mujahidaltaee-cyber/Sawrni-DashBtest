# v0.7 Known Issues Register

| Area | Issue | Status |
|---|---|---|
| Payment | Real gateway credentials are not configured | Pending provider selection |
| OTP | SMS provider is not connected | Pending provider selection |
| Push Notifications | Firebase credentials are not configured | Pending credentials |
| Mobile UI | Flutter screens are beta-level shells | To improve in v0.8 |
| Admin UI | Admin pages need final API data tables | To improve in v0.8 |
| Storage | MinIO/local storage ready; production S3 credentials needed | Pending deployment |
| Tests | Some tests are skeletons and need real factories/data coverage | Continue in v0.8 |
