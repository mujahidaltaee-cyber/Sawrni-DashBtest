# Phase 4 v0.6 Release Notes

## Objective

Phase 4 v0.6 strengthens the current coding package by adding integration boundaries, test coverage skeletons, upload security rules, and admin CRUD scaffolding.

## Backend Additions

- `PaymentGatewayContract` for replacing fake payments with a real gateway.
- `FakePaymentGateway` for local testing.
- `ZainCashPaymentGateway` scaffold as an Iraq-ready payment adapter placeholder.
- `PaymentWebhookController` for payment confirmation callbacks.
- `VerifyPaymentWebhookSignature` middleware scaffold.
- `FileSecurityService` for file size, MIME type, and extension validation.
- `DeliveryPackageService` for approving/rejecting delivery packages.
- Admin CRUD controllers for customers, providers, subscriptions, and admin-side booking actions.
- Feature test skeletons for booking, wallet, delivery, webhook, and admin flows.

## Flutter Additions

- Centralized `ApiEndpoints` class.
- Upload service with multipart upload scaffold.
- Payment gateway service with deposit intent and confirmation methods.
- Receipt screen.
- Delivery repository.

## Admin Web Additions

- Reusable `adminCrudApi.ts`.
- `DataTable`, `StatusBadge`, and `ConfirmAction` components.
- Customers, providers, subscriptions, and delivery details pages.

## Known Limitations

- The package still needs to be installed into real framework projects.
- Payment gateway credentials and final provider must be selected by the owners.
- End-to-end execution is targeted for v0.7.
