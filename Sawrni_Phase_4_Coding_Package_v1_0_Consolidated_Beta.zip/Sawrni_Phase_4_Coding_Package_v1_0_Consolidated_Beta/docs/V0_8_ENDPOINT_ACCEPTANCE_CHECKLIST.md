# v0.8 Endpoint Acceptance Checklist

## Public

- [ ] `GET /api/v1/health`
- [ ] `GET /api/v1/local-beta/status`
- [ ] `GET /api/v1/categories`
- [ ] `GET /api/v1/providers`
- [ ] `GET /api/v1/providers/{providerProfile}`
- [ ] `GET /api/v1/models-grid`

## Authentication

- [ ] `POST /api/v1/auth/register/customer`
- [ ] `POST /api/v1/auth/register/provider`
- [ ] `POST /api/v1/auth/login`
- [ ] `POST /api/v1/auth/logout`

## Customer

- [ ] `GET /api/v1/customer/bookings`
- [ ] `POST /api/v1/customer/bookings`
- [ ] `GET /api/v1/customer/bookings/{booking}`
- [ ] `PATCH /api/v1/customer/bookings/{booking}`
- [ ] `POST /api/v1/customer/bookings/{booking}/cancel`
- [ ] `POST /api/v1/customer/bookings/{booking}/deposit-intent`
- [ ] `POST /api/v1/customer/bookings/{booking}/confirm-deposit`
- [ ] `POST /api/v1/customer/bookings/{booking}/reviews`
- [ ] `GET /api/v1/customer/bookings/{booking}/flow-state`

## Provider

- [ ] `GET /api/v1/provider/profile`
- [ ] `PATCH /api/v1/provider/profile`
- [ ] `GET /api/v1/provider/services`
- [ ] `POST /api/v1/provider/services`
- [ ] `GET /api/v1/provider/bookings`
- [ ] `POST /api/v1/provider/bookings/{booking}/accept`
- [ ] `POST /api/v1/provider/bookings/{booking}/delivery-files`
- [ ] `GET /api/v1/provider/wallet`

## Admin

- [ ] `GET /api/v1/admin/dashboard`
- [ ] `GET /api/v1/admin/providers/pending`
- [ ] `POST /api/v1/admin/providers/{providerProfile}/approve`
- [ ] `GET /api/v1/admin/deliveries/pending`
- [ ] `POST /api/v1/admin/deliveries/{deliveryFile}/approve`
- [ ] `GET /api/v1/admin/wallets`
- [ ] `POST /api/v1/admin/wallets/{wallet}/record-payment`
- [ ] `GET /api/v1/admin/admins/{admin}/permissions`
