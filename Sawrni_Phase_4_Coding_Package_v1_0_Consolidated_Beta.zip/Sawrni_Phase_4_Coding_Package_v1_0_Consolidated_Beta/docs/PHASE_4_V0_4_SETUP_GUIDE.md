# Phase 4 v0.4 Setup Guide

## Backend Laravel

1. Create a clean Laravel project.
2. Copy the `backend-laravel` folder contents into the Laravel project.
3. Run:

```bash
composer install
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan migrate:fresh --seed
php artisan serve
```

4. Configure `.env`:

```env
APP_URL=http://localhost:8000
SANCTUM_STATEFUL_DOMAINS=localhost:3000,127.0.0.1:3000
FILESYSTEM_DISK=local
SAWRNI_PAYMENT_GATEWAY=fake
SAWRNI_COMMISSION_PERCENT=15
SAWRNI_DEBT_SUSPENSION_THRESHOLD_IQD=75000
```

## Flutter

1. Create or open the Flutter app.
2. Copy the `mobile-flutter/lib` files.
3. Install dependencies:

```bash
flutter pub get
flutter run
```

4. Update `AppEnvironment.apiBaseUrl` if needed.

## Admin Web

1. Create or open the Next.js admin project.
2. Copy the `admin-web/src` files.
3. Install and run:

```bash
npm install
npm run dev
```

4. Configure `.env.local`:

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000/api/v1
```

## Known Merge Tasks

- Confirm namespaces and imports after merging into full projects.
- Confirm Laravel version-specific middleware structure.
- Replace `FakePaymentGateway` with the selected real payment provider.
- Replace FCM scaffold with real Firebase service-account configuration.
- Wire actual file upload UI in Flutter.
