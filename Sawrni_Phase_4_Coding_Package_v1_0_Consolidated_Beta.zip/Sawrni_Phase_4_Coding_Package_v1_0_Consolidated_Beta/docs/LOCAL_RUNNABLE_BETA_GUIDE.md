# Sawrni Local Runnable Beta Guide — v0.7

## 1. Requirements

Install:

- PHP 8.2+
- Composer
- Node.js 20+
- Flutter SDK
- Docker Desktop
- Git

## 2. Start Infrastructure

From the package root:

```bash
docker compose up -d postgres redis minio mailpit
```

## 3. Backend Setup

```bash
cd backend-laravel
cp .env.local.example .env
composer install
php artisan key:generate
php artisan migrate:fresh --seed
php artisan serve --host=0.0.0.0 --port=8000
```

Check:

```bash
curl http://127.0.0.1:8000/api/v1/health
```

## 4. Admin Web Setup

```bash
cd admin-web
cp .env.local.example .env.local
npm install
npm run dev
```

Open:

```text
http://127.0.0.1:3000
```

## 5. Flutter Setup

```bash
cd mobile-flutter
flutter pub get
flutter analyze
flutter run
```

Set API base URL inside:

```text
lib/config/app_environment.dart
```

## 6. Demo Accounts

Seeders should create demo users. If not, run:

```bash
php artisan db:seed --class=DatabaseSeeder
```

Suggested accounts are documented in:

```text
backend-laravel/database/seeders/DemoDataSeeder.php
```

## 7. First Local Test Flow

1. Open backend health endpoint.
2. Register or login customer.
3. Browse categories.
4. Browse approved providers.
5. Create booking.
6. Create deposit intent.
7. Confirm fake deposit.
8. Verify chat opens.
9. Login provider.
10. Accept booking.
11. Finish booking.
12. Upload delivery package.
13. Login admin.
14. Approve delivery.
15. Confirm wallet ledger and 15% commission.
