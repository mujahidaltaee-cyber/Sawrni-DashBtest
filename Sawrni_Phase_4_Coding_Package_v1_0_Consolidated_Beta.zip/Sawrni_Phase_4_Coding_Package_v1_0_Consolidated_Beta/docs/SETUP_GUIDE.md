# Sawrni Setup Guide — Phase 4 v0.1

## 1. Backend Setup

Create a fresh Laravel API project, then copy the provided files into the matching folders.

```bash
composer create-project laravel/laravel sawrni-backend
cd sawrni-backend
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
```

Copy the contents of `backend-laravel/` into the Laravel project.

Configure `.env`:

```env
APP_NAME=Sawrni
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=sawrni
DB_USERNAME=postgres
DB_PASSWORD=password

SAWRNI_COMMISSION_RATE=15
SAWRNI_DEBT_THRESHOLD_IQD=75000
SAWRNI_BOOKING_EDIT_WINDOW_HOURS=3
SAWRNI_BOOKING_CANCEL_REFUND_WINDOW_HOURS=1
```

Run:

```bash
php artisan migrate
php artisan db:seed --class=RolePermissionSeeder
php artisan serve
```

## 2. Mobile Setup

Create a Flutter project, then copy files from `mobile-flutter/`.

```bash
flutter create sawrni_mobile
cd sawrni_mobile
```

Copy `lib/`, `pubspec.yaml`, and localization files from the package.

Run:

```bash
flutter pub get
flutter run
```

## 3. Admin Web Setup

Create a frontend project using the selected stack, then copy the `admin-web/` files.

```bash
npm install
npm run dev
```

## 4. First Integration Test

1. Register customer.
2. Register provider.
3. Approve provider from admin/super-admin.
4. Create service offering.
5. Create booking.
6. Confirm deposit payment.
7. Confirm chat unlocks.
8. Accept booking from provider.
9. Complete booking.
10. Upload final delivery.
11. Approve delivery.
12. Download as customer.
