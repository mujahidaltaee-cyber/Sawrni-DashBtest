# Sawrni Developer Handoff Guide v1.0

## 1. Project Structure

```text
Sawrni_Phase_4_Coding_Package_v1_0_Consolidated_Beta/
├── backend-laravel/
├── mobile-flutter/
├── admin-web/
├── infrastructure/
├── scripts/
├── docs/
├── START_HERE_EN.md
├── START_HERE_AR.md
├── VERSION.txt
└── MANIFEST_PHASE_4_V1_0.txt
```

## 2. Backend

Framework target: Laravel API with Sanctum-style token authentication.

Main backend areas:

- authentication;
- users and roles;
- provider approval;
- provider subscriptions;
- bookings;
- payments;
- wallet ledger;
- provider debt handling;
- file delivery;
- reviews;
- notifications;
- admin permissions.

## 3. Mobile App

Framework target: Flutter.

Main mobile areas:

- customer app flow;
- provider app flow;
- Arabic/English support;
- booking flow;
- deposit payment flow;
- chat unlock after deposit;
- notification center;
- delivery download;
- provider wallet;
- provider upload flow.

## 4. Admin Dashboard

Framework target: Next.js / React.

Main admin areas:

- login;
- dashboard;
- provider approval;
- bookings;
- payments;
- wallets;
- subscriptions;
- reviews;
- delivery approval;
- notifications;
- admin permissions;
- staging verification.

## 5. Critical Business Rules To Preserve

| Rule | Value |
|---|---:|
| Commission | 15% |
| Provider debt suspension threshold | 75,000 IQD |
| Booking edit window | 3 hours after deposit payment |
| Refundable cancel window | 1 hour after deposit payment |
| Chat unlock | After deposit payment |
| Phone number unlock | After deposit payment |
| Delivery visibility | After admin approval |
| Provider public visibility | After COO/super-admin approval |

## 6. First Developer Tasks

1. Extract the package.
2. Install Docker, PHP 8.2+, Composer, Node.js 20+, Flutter SDK.
3. Run Docker services.
4. Install Laravel dependencies.
5. Run migrations and seeders.
6. Run Laravel locally.
7. Run API smoke test.
8. Run Admin Web locally.
9. Run Flutter locally.
10. Record runtime errors in `docs/RUNTIME_FIX_LOG_V1_0.md`.

## 7. Do Not Start Production Before

- real payment gateway is certified;
- OTP provider is selected and implemented;
- staging QA is passed;
- legal policies are finalized;
- monitoring and backups are configured;
- app store builds are tested;
- admin security is reviewed.
