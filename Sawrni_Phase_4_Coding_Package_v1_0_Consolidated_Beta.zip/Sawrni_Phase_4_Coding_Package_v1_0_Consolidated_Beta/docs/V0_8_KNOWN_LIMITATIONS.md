# v0.8 Known Limitations

- Package has not been executed inside this chat environment as a full Laravel/Flutter/Next application.
- Some tests are contract skeletons and intentionally marked incomplete until first developer run.
- Payment gateway is not live; fake gateway remains default for local beta.
- Push notifications require Firebase project credentials.
- iOS builds require Apple signing assets.
- Admin CRUD pages still need production-grade filtering, pagination, and error UX.
