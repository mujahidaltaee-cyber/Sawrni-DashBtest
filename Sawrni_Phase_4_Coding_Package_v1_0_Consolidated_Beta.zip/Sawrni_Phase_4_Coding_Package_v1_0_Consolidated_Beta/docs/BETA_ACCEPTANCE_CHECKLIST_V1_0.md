# Sawrni Beta Acceptance Checklist v1.0

## Backend Setup

- [ ] `composer install` succeeds.
- [ ] `.env` is configured.
- [ ] `php artisan key:generate` succeeds.
- [ ] `php artisan migrate:fresh --seed` succeeds.
- [ ] `php artisan serve` starts API.
- [ ] `GET /api/v1/health` returns 200.
- [ ] `GET /api/v1/local-beta/status` returns 200.

## Authentication

- [ ] Customer can login/register.
- [ ] Provider can register and remains pending until approval.
- [ ] Admin can login.
- [ ] Unauthorized admin actions are blocked.

## Customer Flow

- [ ] Customer browses categories.
- [ ] Customer browses models grid.
- [ ] Customer browses providers.
- [ ] Customer views provider profile.
- [ ] Customer selects service/package.
- [ ] Customer selects date/time.
- [ ] Customer sets map/current location.
- [ ] Customer creates booking.
- [ ] Customer creates deposit payment intent.
- [ ] Deposit confirmation unlocks chat and phone visibility.
- [ ] Customer can edit booking within 3 hours after deposit.
- [ ] Customer cannot edit after 3 hours.
- [ ] Customer can cancel with refundable deposit within 1 hour.
- [ ] Customer cancellation after 1 hour marks deposit non-refundable.

## Provider Flow

- [ ] Provider cannot appear publicly before approval.
- [ ] Provider appears after approval.
- [ ] Provider can see booking details after deposit.
- [ ] Provider can accept booking.
- [ ] Provider can reject booking.
- [ ] Provider can update status.
- [ ] Provider can upload final delivery package.
- [ ] Provider can view wallet and debt.

## Admin Flow

- [ ] Super admin can manage admin permissions.
- [ ] COO permission can approve providers.
- [ ] Admin cannot manually create booking.
- [ ] Admin can reassign provider only with customer approval path.
- [ ] Admin can approve final delivery package.
- [ ] Admin can approve/reject reviews.
- [ ] Admin can suspend provider when debt reaches threshold.

## Financial Rules

- [ ] Commission is 15% of total amount.
- [ ] Provider share is 85% of total amount.
- [ ] Wallet ledger records commission, provider share, payments, and debt.
- [ ] Debt threshold is 75,000 IQD.
- [ ] Electronic receipt is generated.

## Delivery Rules

- [ ] Customer cannot access files before approval.
- [ ] Admin approves only final delivery package.
- [ ] Customer can download approved files.
- [ ] Files are not configured with expiry in v1.0.

## Admin Web

- [ ] Login page loads.
- [ ] Dashboard loads.
- [ ] Provider approval page loads.
- [ ] Booking table loads.
- [ ] Payments table loads.
- [ ] Wallet table loads.
- [ ] Reviews page loads.
- [ ] Delivery approval page loads.

## Flutter

- [ ] Flutter project installs dependencies.
- [ ] App starts on Android emulator/device.
- [ ] Language selection works conceptually.
- [ ] Customer navigation works.
- [ ] Provider navigation works.
- [ ] Booking form screen loads.
- [ ] Payment screen loads.
- [ ] Chat screen loads after deposit state.

## Staging Readiness

- [ ] Staging env files are reviewed.
- [ ] Secrets are replaced.
- [ ] Staging smoke test passes.
- [ ] Known runtime issues are documented.
