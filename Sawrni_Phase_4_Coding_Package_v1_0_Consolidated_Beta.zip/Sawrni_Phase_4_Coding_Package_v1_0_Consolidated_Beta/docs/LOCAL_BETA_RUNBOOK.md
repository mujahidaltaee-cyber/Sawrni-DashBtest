# Local Beta Runbook — Sawrni v0.5

## 1. Backend

Merge `backend-laravel` into a clean Laravel project, then run:

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan serve
```

For Docker-assisted services:

```bash
docker compose -f docker-compose.dev.yml up -d postgres redis minio mailpit
```

## 2. Mobile Flutter

Merge `mobile-flutter/lib` and `pubspec.yaml` into a clean Flutter project.

```bash
flutter pub get
flutter run
```

Set the API URL in:

```text
lib/config/app_environment.dart
```

## 3. Admin Web

Merge `admin-web` into a clean Next.js app.

```bash
npm install
npm run dev
```

## 4. Demo priorities

The first beta demo should prove the following only:

1. Provider approval gate.
2. Customer booking creation.
3. Deposit confirmation.
4. Chat unlock.
5. Wallet/commission posting.
6. Delivery approval.
7. Review approval.

Do not demo production payment or store submission in v0.5.
