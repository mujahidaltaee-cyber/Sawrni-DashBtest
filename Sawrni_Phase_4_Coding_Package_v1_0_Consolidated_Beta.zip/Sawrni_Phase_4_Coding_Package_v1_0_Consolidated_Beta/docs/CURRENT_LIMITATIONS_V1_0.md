# Sawrni Current Limitations v1.0

This file lists what still requires developer verification or integration before production.

## Not Production-Ready Yet

1. Real payment gateway credentials are not included.
2. Real OTP/SMS provider is not integrated.
3. Real Firebase push notification credentials are not included.
4. The package has not been executed in your own environment.
5. App Store and Play Store builds are not prepared.
6. Production monitoring and alerting are not configured.
7. Legal documents are not included inside the app yet.
8. Full security review is not complete.
9. UI polish is not final.
10. Photo/file storage must be tested under large uploads.
11. Admin permission edge cases require manual QA.
12. Provider subscription renewal logic requires payment integration.
13. Wallet reconciliation requires final accounting rules.

## Recommended Order To Remove Limitations

1. Run locally.
2. Fix runtime errors.
3. Deploy staging.
4. Integrate real/sandbox payment.
5. Integrate OTP.
6. Integrate Firebase.
7. Complete staging QA.
8. Prepare app store builds.
9. Prepare production deployment.
