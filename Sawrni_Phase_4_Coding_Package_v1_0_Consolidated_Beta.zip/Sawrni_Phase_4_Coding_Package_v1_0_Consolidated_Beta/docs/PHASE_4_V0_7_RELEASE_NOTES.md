# Phase 4 v0.7 Release Notes

## Objective

Phase 4 v0.7 prepares Sawrni for a local developer-run beta by wiring the backend, mobile app, admin dashboard, environment files, run scripts, and first smoke tests.

## Backend Additions

- Merged active routes for v0.5/v0.6 features.
- Added payment webhook middleware alias.
- Added `HealthController` and `LocalBetaStatusController`.
- Added local `.env` sample and Docker-ready configuration.
- Added `api-smoke-test.sh` for first-pass API verification.
- Added Postman collection.
- Added route inventory documentation.

## Flutter Additions

- Local app shell with API base config.
- Token store with secure-storage interface placeholder.
- App bootstrap routing.
- Login screen wired to API service.
- Customer home, booking list, receipt, wallet, and delivery entry screens.
- Provider dashboard shell.

## Admin Web Additions

- Local `.env` sample.
- `package.json` for Next.js starter.
- Login page and API token persistence.
- Protected dashboard shell.
- Beta nav structure.

## Known Limitations

- Payment gateway remains fake/stub until the real merchant credentials are available.
- OTP is scaffolded and must be connected to an SMS provider.
- Push notifications require Firebase credentials.
- UI is functional beta-level, not final polish.
- The package should be tested by a developer after installation.
