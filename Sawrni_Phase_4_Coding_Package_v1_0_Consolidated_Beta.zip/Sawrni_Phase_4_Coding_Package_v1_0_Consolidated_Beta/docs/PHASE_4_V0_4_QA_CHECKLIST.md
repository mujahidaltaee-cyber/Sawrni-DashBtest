# Phase 4 v0.4 QA Checklist

## Backend Setup

- [ ] `composer install` completes in a clean Laravel host project.
- [ ] Sanctum package is installed and config published.
- [ ] `auth:sanctum`, `role`, `admin.permission`, and `provider.approved` middleware aliases resolve.
- [ ] `php artisan migrate:fresh --seed` creates demo data.
- [ ] Demo super admin can login.
- [ ] Demo customer and provider accounts can login.
- [ ] Pending providers do not appear in public catalog.
- [ ] Approved providers appear in public catalog.

## Payment Flow

- [ ] Customer can create a deposit payment intent.
- [ ] Fake payment gateway returns a successful pending/paid simulation.
- [ ] Deposit confirmation updates booking status.
- [ ] 15% commission is calculated correctly from full booking total.
- [ ] Electronic receipt record is created.

## Wallet/Debt

- [ ] Wallet balance updates after completed paid booking.
- [ ] Provider debt is tracked correctly.
- [ ] Provider is suspended when debt reaches 75,000 IQD.
- [ ] Suspended provider cannot receive new public bookings.

## Notifications

- [ ] Notification records are created for booking state changes.
- [ ] FCM job can be queued without crashing when Firebase credentials are absent.
- [ ] Device token registration works.

## Flutter

- [ ] Token is stored securely after login.
- [ ] API client sends bearer token.
- [ ] Route guard sends unauthenticated users to login.
- [ ] API errors are shown instead of silent failure.

## Admin Web

- [ ] Login stores token.
- [ ] Protected layout blocks unauthenticated access.
- [ ] Admin API client sends bearer token.
- [ ] Dashboard and sections load without crashing.
