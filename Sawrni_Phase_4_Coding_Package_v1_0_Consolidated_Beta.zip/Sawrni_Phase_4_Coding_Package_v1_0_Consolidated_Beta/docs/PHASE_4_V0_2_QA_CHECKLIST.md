# Phase 4 v0.2 QA Checklist

## Authentication

- [ ] Customer registration requires phone number.
- [ ] Email is optional.
- [ ] Provider registration creates profile with pending approval.
- [ ] Provider is not public before approval.
- [ ] Login returns an API token.
- [ ] Logout revokes current token.

## Provider Approval

- [ ] Super admin with COO permission can approve providers.
- [ ] Admin without permission cannot approve providers.
- [ ] Approved provider becomes public.
- [ ] Rejected provider remains hidden.

## Payment and Wallet

- [ ] Deposit can be confirmed for a pending booking.
- [ ] Deposit paid timestamp is set.
- [ ] Receipt number is generated.
- [ ] Platform commission equals 15% of total booking value.
- [ ] Provider wallet transaction is created.
- [ ] Provider debt can be recorded.
- [ ] Provider account can be flagged if debt reaches 75,000 IQD.

## Booking Rules

- [ ] Customer can edit booking within 3 hours after deposit payment.
- [ ] Customer cannot edit after 3 hours.
- [ ] Customer can cancel with refund within 1 hour after deposit payment.
- [ ] Customer can cancel without refund after 1 hour.

## Chat

- [ ] Chat is blocked before deposit payment.
- [ ] Chat is opened after deposit payment.
- [ ] Customer/provider phone visibility follows deposit rule.

## Delivery

- [ ] Provider can upload final delivery files.
- [ ] Customer cannot access before approval.
- [ ] Admin/super-admin approval releases files.
