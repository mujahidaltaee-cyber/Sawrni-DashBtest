# First Staging Decision Checklist

Before spending time on production deployment, answer these:

1. What staging domain/subdomain will be used?
2. Who will provide the server credentials?
3. Which payment gateway will be used first: fake, sandbox ZainCash, or another gateway?
4. Which SMS/OTP provider will be used?
5. Will image/file storage use MinIO, AWS S3, Wasabi, Cloudflare R2, or another S3-compatible provider?
6. Who can approve providers as COO inside super admins?
7. Who can approve final delivery packages?
8. Who can approve public reviews?
9. What is the initial provider subscription billing method?
10. Will launch use Android first, or Android+iOS together?

Recommended staging path:

- Start with fake payment.
- Start with local/S3-compatible storage.
- Start with admin-only provider approval.
- Run full workflow using demo accounts.
- Replace fake payment only after core workflow passes.
