# Next Phase — Phase 4 v0.8 Plan

Phase 4 v0.8 should move from local beta wiring into a stronger **developer-verified beta**.

## Targets

1. Run the backend locally and fix syntax/runtime errors.
2. Complete factories for all integration tests.
3. Complete admin dashboard data tables with real API data.
4. Complete Flutter booking creation form.
5. Complete fake payment confirmation UI.
6. Add real provider approval workflow UI.
7. Add full delivery approval UI.
8. Add staging deployment checklist.

## Expected Output

- Backend passes migrations and core tests.
- Admin dashboard can be used for core management tasks.
- Flutter can complete the main customer booking flow against local API.
- Known issues reduced and prioritized.
