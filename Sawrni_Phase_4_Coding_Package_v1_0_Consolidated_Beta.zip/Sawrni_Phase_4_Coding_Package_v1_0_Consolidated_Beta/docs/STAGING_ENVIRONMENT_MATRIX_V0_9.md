# Sawrni Staging Environment Matrix v0.9

| Area | Variable | Example | Required |
|---|---|---:|---:|
| App | APP_ENV | staging | Yes |
| App | APP_URL | https://api-staging.sawrni.com | Yes |
| App | FRONTEND_ADMIN_URL | https://admin-staging.sawrni.com | Yes |
| Database | DB_CONNECTION | pgsql | Yes |
| Database | DB_HOST | postgres | Yes |
| Database | DB_DATABASE | sawrni_staging | Yes |
| Cache | REDIS_HOST | redis | Yes |
| Queue | QUEUE_CONNECTION | redis | Yes |
| Storage | FILESYSTEM_DISK | s3 | Yes |
| Storage | AWS_BUCKET | sawrni-staging | Yes |
| Payments | PAYMENT_GATEWAY | fake / zaincash | Yes |
| Payments | PAYMENT_WEBHOOK_SECRET | change-me | Yes |
| Notifications | FCM_PROJECT_ID | project-id | Optional for v0.9 |
| Mail | MAIL_MAILER | smtp | Optional for v0.9 |
| Admin | NEXT_PUBLIC_API_BASE_URL | https://api-staging.sawrni.com/api/v1 | Yes |
| Flutter | SAWRNI_API_BASE_URL | https://api-staging.sawrni.com/api/v1 | Yes |

## Notes

- No production secret should be used in staging.
- Fake payment is acceptable for first staging.
- Real payment sandbox should replace fake payment before user pilot.
