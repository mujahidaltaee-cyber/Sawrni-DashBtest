# Admin CRUD Matrix — v0.6

| Module | View | Create | Update | Delete/Suspend | Approval |
|---|---|---|---|---|---|
| Customers | Yes | No | Limited | Suspend | No |
| Providers | Yes | No | Limited | Suspend | Approve/Reject |
| Bookings | Yes | No | Limited | Cancel/Resolve | Reassignment approval flow |
| Service Categories | Yes | Yes | Yes | Soft delete | No |
| Provider Subscriptions | Yes | Assign/Renew | Yes | Cancel | No |
| Wallets | Yes | Record payment | Adjust with reason | No | No |
| Reviews | Yes | No | No | Reject/Hide | Approve/Reject |
| Deliveries | Yes | No | No | Reject | Approve/Reject |
| Admin Permissions | Yes | Grant | Update | Revoke | Super admin only |
