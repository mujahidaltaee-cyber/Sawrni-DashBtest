# Next Phase Plan — Phase 4 v0.9

## Goal

Prepare Sawrni for staging deployment.

## Planned work

- Staging `.env.example` files.
- Nginx/Apache deployment notes.
- Laravel queue worker setup.
- Cron/scheduler setup for debt suspension.
- MinIO/S3 bucket policy checklist.
- Admin dashboard real tables for bookings, providers, wallets, deliveries.
- Flutter booking flow polish.
- Push notification test path.
- Payment gateway staging callback instructions.
- Staging smoke test script.

## Expected output

- `Sawrni_Phase_4_Coding_Package_v0_9.zip`
- Staging deployment runbook
- Staging smoke test checklist
