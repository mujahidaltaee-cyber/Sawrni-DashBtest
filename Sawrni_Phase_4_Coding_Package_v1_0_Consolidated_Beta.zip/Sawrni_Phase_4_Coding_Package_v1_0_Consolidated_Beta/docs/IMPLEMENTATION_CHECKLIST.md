# Sawrni Phase 4 Implementation Checklist

## Backend Foundation

- [ ] Create fresh Laravel project.
- [ ] Install Sanctum or selected API authentication package.
- [ ] Configure PostgreSQL database.
- [ ] Copy migrations into `database/migrations`.
- [ ] Copy models into `app/Models`.
- [ ] Copy enums into `app/Enums`.
- [ ] Copy services into `app/Services`.
- [ ] Copy controllers into `app/Http/Controllers/Api`.
- [ ] Register API routes from `routes/api.php`.
- [ ] Run migrations.
- [ ] Run role and subscription seeders.
- [ ] Test login, registration, and provider approval.

## Customer Flow

- [ ] Customer registration.
- [ ] Service category listing.
- [ ] Model tiny-square listing.
- [ ] Provider listing.
- [ ] Provider profile.
- [ ] Booking creation.
- [ ] Deposit payment confirmation.
- [ ] Booking edit within 3 hours.
- [ ] Booking cancellation within 1 hour.
- [ ] Chat after deposit payment.
- [ ] Review after completed booking.

## Provider Flow

- [ ] Provider registration.
- [ ] Provider approval by COO/super-admin permission.
- [ ] Subscription selection.
- [ ] Portfolio upload.
- [ ] Service offering management.
- [ ] Booking accept/reject.
- [ ] Booking status update.
- [ ] Final delivery upload.
- [ ] Wallet and debt viewing.

## Admin Flow

- [ ] Login to web dashboard.
- [ ] Provider approval queue.
- [ ] Booking monitoring.
- [ ] Delivery approval.
- [ ] Review approval.
- [ ] Wallet/debt management.
- [ ] Admin permissions management.
- [ ] Settings: commission, debt threshold, edit/cancel windows.

## Mobile App

- [ ] Configure API base URL.
- [ ] Add localization Arabic/English.
- [ ] Configure RTL support.
- [ ] Connect auth screens.
- [ ] Connect customer booking screens.
- [ ] Connect provider booking screens.
- [ ] Connect wallet, delivery, chat, and notifications.

## QA Gates

- [ ] Customer cannot chat before deposit payment.
- [ ] Provider cannot appear publicly before approval.
- [ ] Deposit becomes non-refundable after 1 hour.
- [ ] Booking edit closes after 3 hours.
- [ ] Provider debt above 75,000 IQD triggers suspension eligibility.
- [ ] Delivery files do not appear before approval.
- [ ] Admin actions follow assigned permissions.
- [ ] RTL and LTR interfaces work correctly.
