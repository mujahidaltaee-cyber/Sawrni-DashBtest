# Sawrni Staging Deployment Runbook v0.9

## Purpose

This runbook explains how to deploy Sawrni to a controlled staging environment before production.

## Recommended Staging Server

Minimum recommended server:

- 2 vCPU
- 4 GB RAM
- 60 GB SSD
- Ubuntu 22.04 or 24.04 LTS
- Docker + Docker Compose
- Domain or subdomain access

Recommended staging subdomains:

- `api-staging.sawrni.com`
- `admin-staging.sawrni.com`
- `storage-staging.sawrni.com`

## Required Services

- Laravel API
- PostgreSQL
- Redis
- Queue worker
- Scheduler
- Admin Web
- Object storage, MinIO or S3-compatible
- Mail testing or transactional email provider
- Payment sandbox gateway
- Push notification credentials, if available

## Deployment Order

1. Create staging server.
2. Install Docker and Docker Compose.
3. Configure DNS records.
4. Copy the project package to the server.
5. Create Laravel `.env.staging` from `.env.staging.example`.
6. Create Admin Web `.env.staging` from `.env.staging.example`.
7. Start infrastructure services.
8. Install Laravel dependencies.
9. Generate Laravel app key.
10. Run migrations and seed staging demo accounts.
11. Start queue worker and scheduler.
12. Build and start Admin Web.
13. Configure Nginx reverse proxy.
14. Enable SSL using a certificate manager.
15. Run smoke tests.
16. Freeze staging build version.

## Laravel Commands

```bash
cd backend-laravel
cp .env.staging.example .env
composer install --no-dev --optimize-autoloader
php artisan key:generate
php artisan migrate:fresh --seed
php artisan config:cache
php artisan route:cache
php artisan storage:link
```

## Queue Worker

```bash
php artisan queue:work redis --queue=default,notifications,payments --tries=3
```

## Scheduler

```bash
php artisan schedule:work
```

## Admin Web Commands

```bash
cd admin-web
cp .env.staging.example .env.local
npm install
npm run build
npm run start
```

## Mobile Staging Build

Android debug staging:

```bash
cd mobile-flutter
flutter pub get
flutter run --dart-define=SAWRNI_ENV=staging
```

## Staging Acceptance Rules

Staging is accepted only when:

- API health endpoint returns success.
- Admin web login page loads.
- Database migrations run cleanly.
- Demo users are seeded.
- Customer can login.
- Customer can create booking.
- Deposit fake/sandbox payment can be confirmed.
- Provider can accept/reject booking.
- Provider can upload final delivery package.
- Admin can approve delivery package.
- Customer can see downloadable delivery package.
- Wallet commission ledger calculates 15% correctly.
- Provider debt suspension threshold of 75,000 IQD is enforced.
