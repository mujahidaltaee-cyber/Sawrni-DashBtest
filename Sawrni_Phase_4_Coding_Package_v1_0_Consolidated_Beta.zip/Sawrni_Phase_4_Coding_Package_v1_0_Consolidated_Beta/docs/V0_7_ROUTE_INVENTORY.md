# v0.7 Route Inventory

## Public

- GET `/api/v1/health`
- GET `/api/v1/local-beta/status`
- POST `/api/v1/auth/register/customer`
- POST `/api/v1/auth/register/provider`
- POST `/api/v1/auth/login`
- GET `/api/v1/categories`
- GET `/api/v1/providers`
- GET `/api/v1/providers/{providerProfile}`
- GET `/api/v1/models-grid`

## Customer

- GET `/api/v1/customer/bookings`
- POST `/api/v1/customer/bookings`
- GET `/api/v1/customer/bookings/{booking}`
- PATCH `/api/v1/customer/bookings/{booking}`
- POST `/api/v1/customer/bookings/{booking}/cancel`
- POST `/api/v1/customer/bookings/{booking}/deposit-intent`
- POST `/api/v1/customer/bookings/{booking}/confirm-deposit`
- POST `/api/v1/customer/bookings/{booking}/reviews`

## Provider

- GET `/api/v1/provider/profile`
- PATCH `/api/v1/provider/profile`
- GET `/api/v1/provider/services`
- POST `/api/v1/provider/services`
- GET `/api/v1/provider/bookings`
- POST `/api/v1/provider/bookings/{booking}/{action}`
- POST `/api/v1/provider/bookings/{booking}/delivery-files`
- GET `/api/v1/provider/wallet`

## Admin

- GET `/api/v1/admin/dashboard`
- GET `/api/v1/admin/customers`
- GET `/api/v1/admin/providers`
- GET `/api/v1/admin/providers/pending`
- POST `/api/v1/admin/providers/{providerProfile}/approve`
- POST `/api/v1/admin/providers/{providerProfile}/reject`
- GET `/api/v1/admin/bookings`
- GET `/api/v1/admin/deliveries/pending`
- POST `/api/v1/admin/deliveries/{deliveryFile}/approve`
- POST `/api/v1/admin/deliveries/{deliveryFile}/reject`
- GET `/api/v1/admin/reviews/pending`
- POST `/api/v1/admin/reviews/{review}/approve`
- POST `/api/v1/admin/reviews/{review}/reject`
- GET `/api/v1/admin/wallets`
- POST `/api/v1/admin/wallets/{wallet}/record-payment`
- GET `/api/v1/admin/subscriptions`

## Payment Webhook

- POST `/api/v1/payments/{gateway}/webhook`
