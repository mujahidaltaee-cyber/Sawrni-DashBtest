# Sawrni Phase 4 v0.4 — Release Notes

## Backend

- Added Laravel 11 style `bootstrap/app.php` with middleware aliases.
- Added `EnsureUserRole`, `EnsureAdminPermission`, and `EnsureProviderApproved` middleware.
- Added development factories and seeders for users, providers, categories, services, bookings, and wallets.
- Added Sanctum, CORS, and filesystems configuration files.
- Added payment gateway adapter interface with `FakePaymentGateway`.
- Added deposit payment intent controller.
- Added push notification job and FCM service scaffold.
- Added provider debt suspension command.
- Added API resources for users, providers, bookings, services, and wallets.
- Added v0.4 OpenAPI additions.

## Mobile Flutter

- Upgraded API client with token support, errors, PATCH/PUT/DELETE, and multipart placeholder.
- Added secure token store.
- Added app bootstrap and authenticated route guard structure.
- Added startup auth context model.
- Added environment config file.

## Admin Web

- Added auth helper.
- Added login page.
- Added protected admin layout component.
- Upgraded API client with token handling and PATCH/PUT/DELETE.
- Added dashboard shell.

## Developer Note

v0.4 improves implementation readiness but still expects developer merge work inside fresh Laravel, Flutter, and Next.js projects.
