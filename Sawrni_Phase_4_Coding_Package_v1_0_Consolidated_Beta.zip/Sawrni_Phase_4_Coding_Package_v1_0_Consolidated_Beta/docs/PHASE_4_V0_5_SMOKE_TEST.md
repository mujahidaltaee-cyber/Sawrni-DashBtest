# Sawrni v0.5 Internal Beta Smoke Test

## Backend

- [ ] Start PostgreSQL, Redis, MinIO, and Mailpit.
- [ ] Run migrations and seeders.
- [ ] Login as super admin.
- [ ] Register a new provider.
- [ ] Confirm the provider is pending and hidden from public catalog.
- [ ] Approve provider using super-admin/COO permission.
- [ ] Confirm provider appears in public catalog.
- [ ] Register/login as customer.
- [ ] Create booking with approved provider.
- [ ] Create deposit intent.
- [ ] Confirm deposit with fake gateway payload.
- [ ] Confirm booking status is deposit paid / confirmed.
- [ ] Confirm chat is unlocked.
- [ ] Confirm customer can edit booking within 3 hours.
- [ ] Confirm customer can cancel with refundable status within 1 hour.
- [ ] Confirm late cancellation marks deposit as non-refundable.
- [ ] Complete booking.
- [ ] Confirm 15% commission is posted.
- [ ] Confirm provider wallet updates.
- [ ] Upload final delivery package.
- [ ] Approve delivery as admin.
- [ ] Confirm customer can download approved delivery.
- [ ] Create review.
- [ ] Confirm review is hidden until approved.
- [ ] Approve review.
- [ ] Confirm review appears publicly.

## Flutter

- [ ] Login screen stores token.
- [ ] Customer home loads categories.
- [ ] Provider list loads approved providers.
- [ ] Booking checkout posts to API.
- [ ] Deposit screen calls payment endpoint.
- [ ] My bookings refreshes after payment.
- [ ] Chat screen is blocked before payment and open after payment.

## Admin Web

- [ ] Login stores admin token.
- [ ] Dashboard loads summary numbers.
- [ ] Pending providers page can approve/reject.
- [ ] Bookings page can view booking details.
- [ ] Deliveries page can approve/reject final packages.
- [ ] Reviews page can approve/reject reviews.
- [ ] Wallets page can record provider payment.
