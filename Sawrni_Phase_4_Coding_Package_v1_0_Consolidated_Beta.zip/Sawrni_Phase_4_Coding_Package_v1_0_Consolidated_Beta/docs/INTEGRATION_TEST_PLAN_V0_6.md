# Integration Test Plan — v0.6

## Booking Flow

- Customer cannot book hidden/unapproved providers.
- Customer can create a booking only with valid service, date/time, and map location.
- Provider schedule conflict must block double booking.
- Booking can be edited only within 3 hours after deposit payment.
- Booking can be cancelled with refundable deposit only within 1 hour after deposit payment.

## Payment Flow

- Deposit intent creates a pending payment.
- Payment webhook must reject invalid signatures.
- Confirmed payment unlocks chat and phone visibility.
- 15% commission must be calculated from total booking value.

## Wallet Flow

- Completed booking credits provider wallet.
- Platform commission is recorded separately.
- Provider debt >= 75,000 IQD triggers suspension eligibility.

## Delivery Flow

- Provider can upload final files only for eligible bookings.
- File type and size checks must run before storage.
- Delivery remains hidden until management approval.
- Rejected delivery requires reason.

## Admin Flow

- Admin can only perform actions allowed by assigned permissions.
- Super admin can grant/revoke admin permissions.
- Admin cannot create manual bookings.
- Provider reassignment requires customer approval if original provider cancels.
