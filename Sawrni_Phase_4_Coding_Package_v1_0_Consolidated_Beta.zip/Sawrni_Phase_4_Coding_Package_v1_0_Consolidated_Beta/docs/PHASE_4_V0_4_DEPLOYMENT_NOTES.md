# Phase 4 v0.4 Deployment Notes

## Backend Production Checklist

- Set `APP_ENV=production`.
- Set `APP_DEBUG=false`.
- Use HTTPS domain.
- Use production database.
- Use queue worker for notifications.
- Use S3-compatible storage for delivery files.
- Use real payment gateway adapter.
- Configure scheduled command for provider debt suspension.
- Configure daily backups.
- Configure log rotation and error monitoring.

## Queue Worker

```bash
php artisan queue:work --tries=3 --timeout=90
```

## Scheduler

Add Laravel scheduler to server cron:

```bash
* * * * * cd /path/to/project && php artisan schedule:run >> /dev/null 2>&1
```

## Storage

For production, prefer S3-compatible storage with private buckets and temporary signed URLs.
