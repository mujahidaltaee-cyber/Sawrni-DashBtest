# Admin Data Tables Plan v0.9

## Tables To Be Used in Admin Dashboard

### Providers

Columns:

- Provider name
- Type
- Phone
- Approval status
- Subscription plan
- Debt balance
- Created date
- Actions

Filters:

- Type
- Approval status
- Subscription plan
- Debt threshold

### Bookings

Columns:

- Booking reference
- Customer
- Provider
- Service
- Date/time
- Status
- Payment status
- Total amount
- Actions

Filters:

- Booking status
- Payment status
- Date range
- Provider type

### Payments

Columns:

- Payment reference
- Booking reference
- Customer
- Method
- Deposit amount
- Total amount
- Status
- Created date

Filters:

- Status
- Method
- Date range

### Wallets

Columns:

- Provider
- Current balance
- Debt balance
- Suspension status
- Last transaction
- Actions

Filters:

- Debt over 75,000 IQD
- Suspended only
- Provider type

### Deliveries

Columns:

- Booking reference
- Provider
- Customer
- Status
- Uploaded date
- Approved by
- Actions

Filters:

- Pending approval
- Approved
- Rejected

### Reviews

Columns:

- Provider
- Customer
- Rating
- Status
- Submitted date
- Actions

Filters:

- Pending
- Approved
- Rejected
- Rating
