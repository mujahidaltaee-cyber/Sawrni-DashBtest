# Next Phase — v0.7 Plan

Phase 4 v0.7 should focus on creating a locally executable beta repository.

## Targets

1. Merge scaffolds into a clean Laravel project.
2. Run composer install and resolve namespaces.
3. Run migrations and seeders.
4. Execute feature tests.
5. Connect Flutter to local API.
6. Connect Admin Web to local API.
7. Verify the full booking-to-delivery journey.
8. Prepare deployment profile for staging.

## Expected Output

- Runnable backend beta.
- Runnable admin dashboard beta.
- Flutter beta with connected API services.
- Known issues log.
- Staging deployment checklist.
