# File Upload Security Rules

## Allowed Delivery File Types

- jpg
- jpeg
- png
- webp
- zip
- pdf
- mp4
- mov

## Required Checks

- File size limit.
- MIME type check.
- Extension check.
- Booking ownership check.
- Booking status check.
- Provider approval check.
- Virus scanning hook if hosting provider supports it.
- Private storage by default.

## Storage Rule

Final delivery files must not be public immediately. They should be stored privately and exposed to the customer only after management approval.
