# Sawrni Staging Smoke-Test Checklist v0.9

## API

- [ ] `GET /api/v1/health` returns 200.
- [ ] `GET /api/v1/local-beta/status` returns package information.
- [ ] `GET /api/v1/staging/status` returns staging readiness data.
- [ ] Login endpoint returns token.
- [ ] Authenticated `me` endpoint works.

## Customer Flow

- [ ] Customer login.
- [ ] Browse categories.
- [ ] Browse providers.
- [ ] Create booking.
- [ ] Create deposit payment intent.
- [ ] Confirm deposit through fake/sandbox payment.
- [ ] Chat is unlocked after deposit.
- [ ] Booking edit is allowed within 3 hours after deposit.
- [ ] Booking cancellation refund path is allowed within 1 hour after deposit.
- [ ] Deposit is non-refundable after 1 hour.

## Provider Flow

- [ ] Provider login.
- [ ] Pending provider does not appear publicly.
- [ ] Approved provider appears publicly.
- [ ] Provider sees assigned booking.
- [ ] Provider accepts booking.
- [ ] Provider rejects booking.
- [ ] Provider uploads final delivery package.
- [ ] Provider wallet is updated.

## Admin Flow

- [ ] Admin login.
- [ ] Pending providers table loads.
- [ ] Provider approval action works.
- [ ] Bookings table loads.
- [ ] Payments table loads.
- [ ] Wallet table loads.
- [ ] Reviews pending table loads.
- [ ] Delivery approval table loads.
- [ ] Admin permission guard blocks unauthorized action.

## Financial Rules

- [ ] Platform commission = 15% of total booking amount.
- [ ] Provider share = 85% of total booking amount.
- [ ] Wallet ledger records all movements.
- [ ] Provider account can be suspended when unpaid debt reaches 75,000 IQD.

## Files and Delivery

- [ ] Upload validation blocks unsupported files.
- [ ] Customer cannot see delivery before admin approval.
- [ ] Customer can download delivery after admin approval.

## Infrastructure

- [ ] Queue worker processes notification jobs.
- [ ] Redis connection works.
- [ ] Storage bucket is reachable.
- [ ] Logs are written.
- [ ] CORS is correct for admin and mobile clients.
