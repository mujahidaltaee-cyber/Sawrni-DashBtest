# Sawrni Phase 4 v0.9 Release Notes

## Release Goal

Phase 4 v0.9 prepares Sawrni for first staging deployment. It does not claim production readiness yet. The package organizes the backend, admin, mobile, and infrastructure files so a developer can deploy a controlled staging instance and verify the core workflows.

## Added in v0.9

### Staging Readiness

- Laravel `.env.staging.example`.
- Admin Web `.env.staging.example`.
- Flutter staging environment file.
- Infrastructure folder for staging.
- Docker Compose staging template.
- Nginx reverse proxy examples.
- GitHub Actions staging CI scaffold.

### Backend

- Staging verification controller scaffold.
- Staging readiness route group notes.
- Staging check service.
- Deployment health checklist.

### Admin Web

- Staging verification page.
- Reusable paginated data table.
- Reusable search/filter bar.
- Money and date cells.
- Resource endpoint helper.

### Scripts

- `scripts/staging-smoke-test.sh`.
- `scripts/prepare-staging-env.sh`.
- `scripts/check-required-env.sh`.

### Documentation

- Staging deployment runbook.
- Staging smoke-test checklist.
- Staging environment matrix.
- Production readiness gap register.
- Admin data tables plan.

## Not Yet Completed

- Real payment gateway credentials and live payment certification.
- Actual staging deployment execution.
- App Store / Play Store build preparation.
- Full UI polish and final QA pass.
- Production monitoring integration.

## Recommended Next Step

Phase 4 v1.0 should be the first consolidated beta package after the developer runs v0.9 locally or on staging and reports runtime errors.
