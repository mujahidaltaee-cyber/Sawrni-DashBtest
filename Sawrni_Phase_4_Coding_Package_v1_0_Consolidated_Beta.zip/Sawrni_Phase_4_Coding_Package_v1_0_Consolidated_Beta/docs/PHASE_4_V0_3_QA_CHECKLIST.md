# Phase 4 v0.3 QA Checklist

## Booking CRUD

- [ ] Customer can list own bookings only.
- [ ] Customer can view own booking details.
- [ ] Customer cannot view another customer's booking.
- [ ] Customer can create booking with approved provider only.
- [ ] Customer cannot create booking when provider has schedule conflict.
- [ ] Customer can edit booking only within the allowed 3-hour window after deposit payment.
- [ ] Customer can cancel booking and refund eligibility is calculated from the 1-hour rule.

## Provider Workflow

- [ ] Provider can list assigned bookings.
- [ ] Provider can accept pending booking.
- [ ] Provider can reject pending booking.
- [ ] Provider can start accepted booking.
- [ ] Provider can mark session finished.
- [ ] Provider cannot access bookings assigned to another provider.

## Profile and Services

- [ ] Provider can update own profile.
- [ ] Provider can create service offering.
- [ ] Provider can update own service offering.
- [ ] Provider cannot update another provider's service offering.
- [ ] Provider can add portfolio items.

## Delivery Files

- [ ] Provider can upload final delivery files after valid booking status.
- [ ] Customer cannot download before approval.
- [ ] Admin can approve/reject delivery files.
- [ ] Approved delivery files appear to customer.

## Notifications

- [ ] Device token registration stores platform and token.
- [ ] Notification center lists current user's notifications.
- [ ] Booking changes create notification logs.
- [ ] Admin broadcast scaffold creates queued notification records.

## Admin Dashboard

- [ ] Admin can list bookings.
- [ ] Admin can filter bookings by status.
- [ ] Admin can list categories.
- [ ] Admin can create/update categories based on permission.
- [ ] Admin can review pending deliveries.
