# Sawrni Phase 4 v0.3 — Release Notes

## Added Backend Features

- Customer booking index, show, create, update, cancel.
- Provider booking action endpoints.
- Schedule conflict service for provider availability.
- Provider profile controller.
- Provider service offering controller.
- Provider portfolio controller.
- Upload service abstraction.
- Delivery file upload request and controller upgrades.
- Notification center controller.
- Device token registration endpoint.
- Admin bookings controller.
- Admin service category controller.
- Admin notification broadcast scaffold.
- Additional migrations for provider availability and booking audit metadata.
- Additional feature test skeletons.

## Added Mobile Features

- App navigation shell.
- Customer booking details screen.
- Customer booking edit screen.
- Provider booking details/action screen.
- Provider profile and services screens.
- Delivery upload screen.
- Notification center screen.
- Updated booking and provider services.

## Added Admin Web Features

- Booking management page.
- Provider review/detail page scaffold.
- Service category management page.
- Notifications page.
- Delivery review page integration.
- API helpers for admin module requests.

## Implementation Notes

- The upload service currently stores metadata and assumes S3/local disk configuration will be wired in the Laravel host project.
- Notification dispatch is logged into `notification_logs`; real FCM dispatch is planned for v0.4.
- Provider conflict checking uses booking time ranges and status filtering.
- Route middleware names should be mapped inside the host Laravel app.
