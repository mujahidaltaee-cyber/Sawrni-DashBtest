# Payment Gateway Integration Notes

## Current Design

The system uses a payment gateway contract so the fake gateway can be replaced later without rewriting booking or wallet logic.

## Required Gateway Features

The selected payment provider should support:

- Create payment intent.
- Confirm payment status.
- Webhook callback.
- Signature verification.
- Refund support if required by policy.
- Transaction reference ID.
- Amount in IQD.

## Sawrni Payment Rules

- Deposit is required to confirm a booking.
- Platform commission is 15% of the total booking amount.
- Final wallet settlement is calculated after the booking is completed and paid.
- If cash is used, provider debt to the platform may increase based on the 15% commission.

## Recommended Implementation

Keep all gateway-specific code inside:

```text
app/Payments/
```

Do not put payment gateway logic directly inside controllers.
