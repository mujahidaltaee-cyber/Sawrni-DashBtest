# Phase 4 Roadmap After v0.3

## v0.4 — Runnable Backend Target

- Install and configure Laravel Sanctum.
- Add full factories and seeders.
- Add policy auto-discovery.
- Wire file storage disks.
- Implement FCM notification job.
- Add payment provider interface and fake gateway.
- Add audit logging middleware.
- Add OpenAPI full endpoint coverage.

## v0.5 — Flutter Functional Beta Target

- Add state management.
- Add token persistence.
- Add authenticated route guards.
- Add real API error UI.
- Add booking creation form with map placeholder.
- Add provider dashboard API integration.
- Add delivery download UI.

## v0.6 — Admin Dashboard Functional Beta Target

- Add login.
- Add protected routes.
- Add sidebar layout.
- Add tables with filters.
- Add provider approval screens.
- Add booking management views.
- Add wallet/debt management views.
