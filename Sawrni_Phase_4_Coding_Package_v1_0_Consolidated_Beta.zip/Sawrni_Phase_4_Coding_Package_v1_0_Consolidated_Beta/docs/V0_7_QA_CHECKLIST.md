# v0.7 QA Checklist

## Backend

- [ ] `composer install` completes.
- [ ] `.env.local.example` copies to `.env`.
- [ ] `php artisan key:generate` works.
- [ ] `php artisan migrate:fresh --seed` works.
- [ ] `/api/v1/health` returns OK.
- [ ] Public categories endpoint returns data.
- [ ] Customer login works.
- [ ] Provider login works.
- [ ] Admin login works.

## Customer Flow

- [ ] Customer sees only approved providers.
- [ ] Customer can create booking.
- [ ] Deposit intent is created.
- [ ] Fake payment confirmation works.
- [ ] Chat opens only after deposit.
- [ ] Booking edit window is enforced.
- [ ] Booking cancellation window is enforced.

## Provider Flow

- [ ] Provider cannot use app before approval.
- [ ] Approved provider can view bookings.
- [ ] Provider can accept booking.
- [ ] Provider can upload final delivery package.
- [ ] Provider can see wallet.

## Admin Flow

- [ ] Admin sees dashboard.
- [ ] Admin can approve/reject providers if permission exists.
- [ ] Admin can approve/reject deliveries.
- [ ] Admin can approve/reject reviews.
- [ ] Super admin can manage permissions.

## Finance

- [ ] 15% commission calculates correctly.
- [ ] Wallet transaction is recorded.
- [ ] Debt threshold flag works at 75,000 IQD.
