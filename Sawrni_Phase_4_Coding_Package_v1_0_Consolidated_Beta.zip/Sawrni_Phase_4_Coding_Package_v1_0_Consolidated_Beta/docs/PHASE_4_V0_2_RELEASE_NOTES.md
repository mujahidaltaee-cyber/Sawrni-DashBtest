# Sawrni Phase 4 v0.2 — Release Notes

## Added Backend Code

- Auth request validation classes.
- OTP service scaffold.
- Auth service for customer/provider registration and token login.
- Admin permission service.
- Payment service for deposit confirmation and wallet calculations.
- Receipt service for electronic receipt numbers.
- Provider suspension service based on debt threshold.
- Chat gate service.
- Payment and receipt models.
- Payment and receipt migrations.
- Device token and OTP migrations.
- Admin permissions migration.
- Expanded API routes.
- New controllers for payments, chat, wallet, admin permissions, and admin wallet review.
- Feature test skeletons.

## Added Mobile Code

- API result and exception helpers.
- Payment service.
- Wallet service.
- Chat service.
- Deposit payment screen.
- Provider wallet screen.
- Chat screen.

## Added Admin Web Code

- Admin API client helpers.
- Payments review page.
- Wallets/debt page.
- Admin permissions page.
- Provider approval queue page with API call structure.

## Important Notes

- External SMS/OTP and payment gateway integrations are intentionally abstracted.
- Electronic payment can be wired later to a provider available for Iraq.
- Cash payment confirmation is supported through admin confirmation logic.
- Tests are included as developer targets; they may need factory additions inside the final Laravel project.
