# Phase 5 Plan — Developer Run, Runtime Fixes, and Staging Deployment

## Goal

Move Sawrni from consolidated beta package to a verified staging deployment.

## Phase 5 Workstreams

### 1. Local Developer Run

- Install backend dependencies.
- Install admin web dependencies.
- Install Flutter dependencies.
- Start Docker services.
- Run migrations.
- Seed demo accounts.
- Run local API smoke tests.

### 2. Runtime Fixes

- Fix namespace errors.
- Fix missing imports.
- Fix route mismatches.
- Fix model relationships.
- Fix migration ordering.
- Fix Flutter compile errors.
- Fix admin web build errors.
- Fix CORS or API base URL issues.

### 3. Staging Deployment

- Prepare staging server.
- Configure DNS/subdomains.
- Configure SSL.
- Deploy Laravel API.
- Deploy admin web.
- Configure storage.
- Configure queue worker and scheduler.
- Run staging smoke tests.

### 4. Staging QA

- Verify customer workflow.
- Verify provider workflow.
- Verify admin workflow.
- Verify payment fake/sandbox workflow.
- Verify delivery upload/approval/download.
- Verify wallet and debt logic.
- Verify permissions.

### 5. Decision Gate

After Phase 5, decide one of these:

- proceed to Phase 6: mobile app polish and real integrations;
- repeat Phase 5 for fixes;
- reduce v1.0 scope if a dependency blocks launch.

## Expected Output

- Running staging URL.
- Staging API URL.
- Staging admin URL.
- Runtime fix log.
- QA checklist result.
- Updated v1.1 package if fixes are required.
