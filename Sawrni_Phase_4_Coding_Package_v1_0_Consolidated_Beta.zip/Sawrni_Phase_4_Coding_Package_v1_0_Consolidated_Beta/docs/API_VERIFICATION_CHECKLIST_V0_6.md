# API Verification Checklist — v0.6

## Auth

- Register customer.
- Register provider.
- Request OTP.
- Verify OTP.
- Login.
- Logout.

## Catalog

- List categories.
- List approved providers only.
- Show provider profile.
- Show models grid.

## Customer

- Create booking.
- Pay deposit.
- Edit booking within allowed window.
- Cancel booking within allowed window.
- Open chat after deposit.
- View receipt.

## Provider

- View assigned bookings.
- Accept/reject booking.
- Update status.
- Upload delivery.
- View wallet.

## Admin

- Approve/reject providers.
- Review deliveries.
- Review ratings.
- Manage subscriptions.
- Manage service categories.
- View wallets.
- Record provider payment.
- Grant/revoke permissions.
