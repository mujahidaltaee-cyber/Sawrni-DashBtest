# Sawrni Phase 4 v0.5 — Release Notes

## Backend

- Added Docker Compose development stack: PostgreSQL, Redis, MinIO, and Mailpit.
- Added `BookingWorkflowService` to centralize booking creation, edit, cancel, and state checks.
- Added `AvailabilityService` to prevent provider schedule conflicts.
- Added `PaymentWorkflowService` to confirm deposit payments and unlock booking features.
- Added `WalletLedgerService` to post platform commission, provider earnings, debt, and repayments.
- Added `DeliveryWorkflowService` to approve/reject final delivery packages.
- Added request classes for booking, payment confirmation, provider services, delivery upload, and reviews.
- Added review flow scaffold with admin approval requirement.
- Added admin provider reassignment scaffold with customer approval pending state.

## Flutter

- Added repositories for bookings, payments, providers, deliveries, reviews, notifications, and chat.
- Added simple controllers to support internal beta wiring.
- Added DTO helpers to reduce screen-level API parsing.

## Admin Web

- Added beta API helpers for provider approval, booking reassignment, delivery approval, wallet payment recording, review approval, and notification broadcast.
- Added improved page placeholders for internal testing.

## QA

- Added smoke-test checklist for the first internal developer beta.
- Added beta runbook.

## Remaining for v0.6

- Replace fake payment gateway with real provider adapter.
- Add complete file upload implementation and antivirus/size validation policy.
- Complete full integration tests.
- Finalize admin CRUD screens.
- Add Firebase credentials and real push sending.
