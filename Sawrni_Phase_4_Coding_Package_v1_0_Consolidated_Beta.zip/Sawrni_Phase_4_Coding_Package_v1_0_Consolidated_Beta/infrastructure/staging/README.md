# Sawrni Staging Infrastructure

This folder contains staging templates. They are not intended to be copied blindly to production.

## Files

- `docker-compose.staging.yml`: database, Redis, MinIO, and Mailpit.
- `nginx-api.conf`: Laravel API reverse proxy example.
- `nginx-admin.conf`: Next.js admin reverse proxy example.

## Before Use

- Replace all passwords.
- Configure HTTPS.
- Configure DNS.
- Move secrets into secure environment management.
