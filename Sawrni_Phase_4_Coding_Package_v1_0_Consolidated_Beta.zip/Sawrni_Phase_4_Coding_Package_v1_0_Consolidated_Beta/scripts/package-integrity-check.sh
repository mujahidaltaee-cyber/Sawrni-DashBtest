#!/usr/bin/env bash
set -euo pipefail

required=(
  "backend-laravel"
  "mobile-flutter"
  "admin-web"
  "docs"
  "scripts"
  "START_HERE_EN.md"
  "START_HERE_AR.md"
  "VERSION.txt"
  "MANIFEST_PHASE_4_V1_0.txt"
)

for path in "${required[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "Missing required package path: $path"
    exit 1
  fi
done

echo "Sawrni package structure check passed."
