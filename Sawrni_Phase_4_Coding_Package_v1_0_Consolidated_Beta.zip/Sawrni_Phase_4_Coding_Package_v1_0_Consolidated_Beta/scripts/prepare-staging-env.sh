#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f backend-laravel/.env ]]; then
  cp backend-laravel/.env.staging.example backend-laravel/.env
  echo "Created backend-laravel/.env from staging example."
fi

if [[ ! -f admin-web/.env.local ]]; then
  cp admin-web/.env.staging.example admin-web/.env.local
  echo "Created admin-web/.env.local from staging example."
fi

echo "Review all staging secrets before deployment."
