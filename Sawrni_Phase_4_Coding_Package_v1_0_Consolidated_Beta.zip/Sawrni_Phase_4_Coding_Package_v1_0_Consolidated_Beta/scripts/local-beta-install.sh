#!/usr/bin/env bash
set -euo pipefail

echo "[Sawrni] Starting local infrastructure..."
docker compose up -d postgres redis minio mailpit

echo "[Sawrni] Preparing backend..."
cd backend-laravel
cp -n .env.local.example .env || true
composer install
php artisan key:generate
php artisan migrate:fresh --seed

echo "[Sawrni] Backend ready. Run: php artisan serve --host=0.0.0.0 --port=8000"
