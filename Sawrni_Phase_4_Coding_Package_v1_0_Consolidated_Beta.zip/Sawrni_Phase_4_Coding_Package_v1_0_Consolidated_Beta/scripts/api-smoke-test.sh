#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://127.0.0.1:8000/api/v1}"

echo "Checking health endpoint..."
curl -fsS "$BASE_URL/health" | tee /tmp/sawrni-health.json

echo "Checking local beta status..."
curl -fsS "$BASE_URL/local-beta/status" | tee /tmp/sawrni-beta-status.json

echo "Checking categories endpoint..."
curl -fsS "$BASE_URL/categories" | head -c 500 || true

echo "\nSmoke test completed. Continue with Postman collection for auth-protected flows."
