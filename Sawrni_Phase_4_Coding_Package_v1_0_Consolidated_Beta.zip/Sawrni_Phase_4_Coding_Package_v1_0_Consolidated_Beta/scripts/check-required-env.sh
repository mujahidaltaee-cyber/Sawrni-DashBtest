#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${1:-backend-laravel/.env}"

required=(
  APP_ENV
  APP_URL
  DB_CONNECTION
  DB_HOST
  DB_DATABASE
  DB_USERNAME
  DB_PASSWORD
  REDIS_HOST
  FILESYSTEM_DISK
  PAYMENT_GATEWAY
  PAYMENT_WEBHOOK_SECRET
)

missing=0
for key in "${required[@]}"; do
  if ! grep -q "^${key}=" "$ENV_FILE"; then
    echo "Missing ${key} in ${ENV_FILE}"
    missing=1
  fi
done

if [[ "$missing" -eq 1 ]]; then
  exit 1
fi

echo "Required env check passed for ${ENV_FILE}."
