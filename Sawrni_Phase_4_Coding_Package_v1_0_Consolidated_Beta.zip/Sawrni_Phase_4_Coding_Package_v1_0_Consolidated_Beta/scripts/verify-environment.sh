#!/usr/bin/env bash
set -e

echo "Sawrni v0.8 environment verification"

echo "Checking Docker..."
docker --version || { echo "Docker is required"; exit 1; }

echo "Checking docker compose..."
docker compose version || { echo "Docker Compose is required"; exit 1; }

echo "Checking backend env..."
if [ ! -f backend-laravel/.env ]; then
  echo "backend-laravel/.env is missing. Copy .env.local.example to .env"
else
  echo "backend env exists"
fi

echo "Checking admin env..."
if [ ! -f admin-web/.env.local ]; then
  echo "admin-web/.env.local is missing. Copy .env.local.example to .env.local"
else
  echo "admin env exists"
fi

echo "Checking PHP..."
php -v || true

echo "Checking Composer..."
composer --version || true

echo "Checking Node..."
node -v || true

echo "Checking Flutter..."
flutter --version || true

echo "Done. Resolve any missing tools before full beta run."
