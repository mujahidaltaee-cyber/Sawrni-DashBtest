#!/usr/bin/env bash
set -euo pipefail

API_BASE_URL="${API_BASE_URL:-https://api-staging.sawrni.com/api/v1}"

echo "Running Sawrni staging smoke test against: ${API_BASE_URL}"

check() {
  local name="$1"
  local url="$2"
  echo "- ${name}: ${url}"
  code=$(curl -s -o /tmp/sawrni_smoke_response.json -w "%{http_code}" "$url" || true)
  if [[ "$code" != "200" ]]; then
    echo "FAILED: ${name} returned HTTP ${code}"
    cat /tmp/sawrni_smoke_response.json || true
    exit 1
  fi
  echo "OK: ${name}"
}

check "API health" "${API_BASE_URL}/health"
check "Local beta status" "${API_BASE_URL}/local-beta/status"
check "Staging status" "${API_BASE_URL}/staging/status"

echo "Staging smoke test completed."
