#!/usr/bin/env bash
set -e
BASE_URL=${BASE_URL:-http://127.0.0.1:8000/api/v1}

echo "Checking Sawrni API at $BASE_URL"
curl -s "$BASE_URL/health" | python3 -m json.tool || curl -s "$BASE_URL/health"
echo ""
curl -s "$BASE_URL/local-beta/status" | python3 -m json.tool || curl -s "$BASE_URL/local-beta/status"
echo ""
echo "Manual token-based endpoints should be checked with the Postman collection after login."
