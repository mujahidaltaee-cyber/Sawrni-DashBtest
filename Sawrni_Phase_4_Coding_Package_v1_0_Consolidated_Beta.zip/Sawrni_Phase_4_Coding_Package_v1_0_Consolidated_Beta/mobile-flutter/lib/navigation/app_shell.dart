import 'package:flutter/material.dart';
import '../screens/customer/customer_home_screen.dart';
import '../screens/customer/my_bookings_screen.dart';
import '../screens/notifications/notification_center_screen.dart';
import '../screens/provider/provider_dashboard_screen.dart';

class AppShell extends StatefulWidget {
  final String role;
  const AppShell({super.key, required this.role});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final isProvider = widget.role == 'provider';
    final pages = isProvider
        ? const [ProviderDashboardScreen(), NotificationCenterScreen()]
        : const [CustomerHomeScreen(), MyBookingsScreen(), NotificationCenterScreen()];

    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: isProvider
            ? const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
                NavigationDestination(icon: Icon(Icons.notifications_outlined), label: 'Alerts'),
              ]
            : const [
                NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
                NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Bookings'),
                NavigationDestination(icon: Icon(Icons.notifications_outlined), label: 'Alerts'),
              ],
      ),
    );
  }
}
