import '../core/auth_context.dart';

class AuthRouteGuard {
  const AuthRouteGuard(this.auth);
  final AuthContext auth;

  bool canOpenCustomerArea() => auth.isAuthenticated && auth.isCustomer;
  bool canOpenProviderArea() => auth.isAuthenticated && auth.isProvider;
}
