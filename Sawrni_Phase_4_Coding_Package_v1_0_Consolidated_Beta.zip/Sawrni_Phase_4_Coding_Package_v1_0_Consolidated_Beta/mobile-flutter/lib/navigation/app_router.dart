import 'package:flutter/material.dart';
import '../screens/auth/login_screen_v07.dart';
import '../screens/customer/customer_home_screen_v07.dart';
import '../screens/customer/customer_bookings_screen_v07.dart';
import '../screens/provider/provider_dashboard_screen_v07.dart';

class AppRouter {
  static const login = '/login';
  static const customerHome = '/customer';
  static const customerBookings = '/customer/bookings';
  static const providerDashboard = '/provider';

  static final routes = <String, WidgetBuilder>{
    login: (_) => const LoginScreenV07(),
    customerHome: (_) => const CustomerHomeScreenV07(),
    customerBookings: (_) => const CustomerBookingsScreenV07(),
    providerDashboard: (_) => const ProviderDashboardScreenV07(),
  };
}
