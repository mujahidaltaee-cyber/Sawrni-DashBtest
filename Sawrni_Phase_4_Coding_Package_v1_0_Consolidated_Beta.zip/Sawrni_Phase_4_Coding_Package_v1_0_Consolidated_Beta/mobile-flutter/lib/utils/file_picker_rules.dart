class FilePickerRules {
  static const allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'zip', 'pdf', 'mp4', 'mov'];
  static const maxDeliveryMegabytes = 2048;

  static bool isAllowedExtension(String fileName) {
    final parts = fileName.toLowerCase().split('.');
    if (parts.length < 2) return false;
    return allowedExtensions.contains(parts.last);
  }
}
