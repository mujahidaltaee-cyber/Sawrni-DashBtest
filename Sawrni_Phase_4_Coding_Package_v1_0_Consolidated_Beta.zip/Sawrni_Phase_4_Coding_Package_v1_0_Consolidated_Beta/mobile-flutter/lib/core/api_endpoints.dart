class ApiEndpoints {
  static const String authLogin = '/auth/login';
  static const String authRequestOtp = '/auth/request-otp';
  static const String categories = '/categories';
  static const String providers = '/providers';
  static const String modelsGrid = '/models-grid';

  static String customerBookings() => '/customer/bookings';
  static String customerBooking(int id) => '/customer/bookings/$id';
  static String depositIntent(int bookingId) => '/customer/bookings/$bookingId/deposit-intent';
  static String confirmDeposit(int bookingId) => '/customer/bookings/$bookingId/confirm-deposit';
  static String bookingChat(int bookingId) => '/bookings/$bookingId/chat';

  static String providerBookings() => '/provider/bookings';
  static String providerBookingAction(int bookingId, String action) => '/provider/bookings/$bookingId/$action';
  static String uploadDelivery(int bookingId) => '/provider/bookings/$bookingId/delivery-files';
  static String providerWallet() => '/provider/wallet';

  static String receipt(int paymentId) => '/payments/$paymentId/receipt';
}
