class AuthContext {
  final String? token;
  final String? role;

  const AuthContext({this.token, this.role});

  bool get isAuthenticated => token != null && token!.isNotEmpty;
  bool get isProvider => role == 'provider';
  bool get isCustomer => role == 'customer';
}
