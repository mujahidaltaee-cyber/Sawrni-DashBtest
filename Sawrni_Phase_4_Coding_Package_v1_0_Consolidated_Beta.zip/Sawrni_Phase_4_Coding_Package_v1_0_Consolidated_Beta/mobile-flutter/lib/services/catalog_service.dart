import 'api_client.dart';

class CatalogService {
  CatalogService(this.api);
  final ApiClient api;

  Future<Map<String, dynamic>> categories() => api.get('/catalog/categories');
  Future<Map<String, dynamic>> providers() => api.get('/catalog/providers');
  Future<Map<String, dynamic>> modelsGrid() => api.get('/catalog/models-grid');
}
