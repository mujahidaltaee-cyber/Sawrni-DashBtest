import 'api_client.dart';

class WalletService {
  final ApiClient api;
  WalletService(this.api);

  Future<Map<String, dynamic>> providerWallet() async {
    return api.get('/v1/provider/wallet');
  }
}
