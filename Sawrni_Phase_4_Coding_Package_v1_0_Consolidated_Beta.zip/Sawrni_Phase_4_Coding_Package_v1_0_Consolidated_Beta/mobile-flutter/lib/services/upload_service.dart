import 'dart:io';
import 'package:http/http.dart' as http;
import '../core/api_endpoints.dart';
import '../core/token_store.dart';
import '../config/app_environment.dart';

class UploadService {
  final TokenStore tokenStore;
  UploadService(this.tokenStore);

  Future<http.StreamedResponse> uploadDeliveryFile({
    required int bookingId,
    required File file,
    String? notes,
  }) async {
    final token = await tokenStore.readToken();
    final uri = Uri.parse('${AppEnvironment.apiBaseUrl}${ApiEndpoints.uploadDelivery(bookingId)}');
    final request = http.MultipartRequest('POST', uri)
      ..headers['Authorization'] = 'Bearer $token'
      ..files.add(await http.MultipartFile.fromPath('file', file.path));

    if (notes != null && notes.trim().isNotEmpty) {
      request.fields['notes'] = notes.trim();
    }

    return request.send();
  }
}
