import 'api_client.dart';

class NotificationService {
  final ApiClient api;
  NotificationService(this.api);

  Future<Map<String, dynamic>> list() async {
    return api.get('/notifications');
  }

  Future<Map<String, dynamic>> markRead(int id) async {
    return api.post('/notifications/$id/read', {});
  }

  Future<Map<String, dynamic>> registerDeviceToken({required String token, required String platform}) async {
    return api.post('/device-tokens', {'token': token, 'platform': platform});
  }
}
