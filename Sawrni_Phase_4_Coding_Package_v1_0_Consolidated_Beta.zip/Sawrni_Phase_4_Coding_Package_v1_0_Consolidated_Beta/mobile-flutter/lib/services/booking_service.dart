import 'api_client.dart';

class BookingService {
  BookingService(this.api);
  final ApiClient api;

  Future<Map<String, dynamic>> createBooking(Map<String, dynamic> payload) {
    return api.post('/customer/bookings', payload);
  }

  Future<Map<String, dynamic>> myBookings() => api.get('/customer/bookings');
}
