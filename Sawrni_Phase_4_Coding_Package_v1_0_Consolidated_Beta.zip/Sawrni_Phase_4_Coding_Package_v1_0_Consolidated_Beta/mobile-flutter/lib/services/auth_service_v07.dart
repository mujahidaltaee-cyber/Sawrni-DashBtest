import '../core/token_store.dart';
import 'api_client.dart';

class AuthServiceV07 {
  final ApiClient api;
  final TokenStore tokenStore;
  AuthServiceV07(this.api, this.tokenStore);

  Future<void> login(String phone, String otp) async {
    final data = await api.post('/auth/login', {'phone': phone, 'otp': otp});
    final token = (data['token'] ?? data['access_token'] ?? '').toString();
    if (token.isEmpty) throw Exception('Login response did not include token');
    await tokenStore.saveToken(token);
  }
}
