import '../core/api_endpoints.dart';
import 'api_client.dart';

class PaymentGatewayService {
  final ApiClient api;
  PaymentGatewayService(this.api);

  Future<Map<String, dynamic>> createDepositIntent(int bookingId) async {
    return api.post(ApiEndpoints.depositIntent(bookingId), {});
  }

  Future<Map<String, dynamic>> confirmDeposit(int bookingId, String gatewayReference) async {
    return api.post(ApiEndpoints.confirmDeposit(bookingId), {
      'gateway_reference': gatewayReference,
    });
  }
}
