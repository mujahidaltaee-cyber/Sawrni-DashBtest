import 'api_client.dart';

class AuthService {
  AuthService(this.api);
  final ApiClient api;

  Future<Map<String, dynamic>> login({required String phone, String? password}) {
    return api.post('/auth/login', {'phone': phone, if (password != null) 'password': password});
  }

  Future<Map<String, dynamic>> registerCustomer({required String name, required String phone, String? email}) {
    return api.post('/auth/register/customer', {'name': name, 'phone': phone, if (email != null) 'email': email});
  }
}
