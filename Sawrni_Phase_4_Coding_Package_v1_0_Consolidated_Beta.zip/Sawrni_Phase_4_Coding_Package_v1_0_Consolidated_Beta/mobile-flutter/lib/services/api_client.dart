import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_environment.dart';
import '../core/token_store.dart';

class ApiClient {
  final TokenStore tokenStore;
  ApiClient(this.tokenStore);

  Future<Map<String, dynamic>> get(String path) async {
    final response = await http.get(await _uri(path), headers: await _headers());
    return _decode(response);
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final response = await http.post(await _uri(path), headers: await _headers(), body: jsonEncode(body));
    return _decode(response);
  }

  Future<Uri> _uri(String path) async => Uri.parse('${AppEnvironment.apiBaseUrl}$path');

  Future<Map<String, String>> _headers() async {
    final token = await tokenStore.readToken();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  Map<String, dynamic> _decode(http.Response response) {
    final body = response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(body['message'] ?? 'API error ${response.statusCode}');
    }
    return body;
  }
}
