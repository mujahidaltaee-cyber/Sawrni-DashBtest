import 'api_client.dart';

class DeliveryService {
  final ApiClient api;
  DeliveryService(this.api);

  // In the host Flutter project, implement multipart support inside ApiClient.
  Future<Map<String, dynamic>> uploadDeliveryPlaceholder(int bookingId) async {
    return api.post('/provider/bookings/$bookingId/delivery-files', {
      'implementation_note': 'Use multipart/form-data for the real file upload.',
    });
  }
}
