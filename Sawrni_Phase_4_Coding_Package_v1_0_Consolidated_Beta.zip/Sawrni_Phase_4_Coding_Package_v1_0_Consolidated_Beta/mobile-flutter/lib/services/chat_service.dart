import 'api_client.dart';

class ChatService {
  final ApiClient api;
  ChatService(this.api);

  Future<Map<String, dynamic>> messages(int bookingId) {
    return api.get('/v1/bookings/$bookingId/chat');
  }

  Future<Map<String, dynamic>> send(int bookingId, String message) {
    return api.post('/v1/bookings/$bookingId/chat', {'message': message});
  }
}
