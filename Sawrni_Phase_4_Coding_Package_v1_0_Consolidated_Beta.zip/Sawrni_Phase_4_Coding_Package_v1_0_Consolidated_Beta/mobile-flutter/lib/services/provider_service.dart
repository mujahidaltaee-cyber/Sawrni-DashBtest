import 'api_client.dart';

class ProviderService {
  final ApiClient api;
  ProviderService(this.api);

  Future<Map<String, dynamic>> profile() async {
    return api.get('/provider/profile');
  }

  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> payload) async {
    return api.patch('/provider/profile', payload);
  }

  Future<Map<String, dynamic>> services() async {
    return api.get('/provider/services');
  }

  Future<Map<String, dynamic>> createService(Map<String, dynamic> payload) async {
    return api.post('/provider/services', payload);
  }

  Future<Map<String, dynamic>> actionBooking(int bookingId, String action, {String? note}) async {
    return api.post('/provider/bookings/$bookingId/$action', {'note': note});
  }
}
