import 'api_client.dart';

class PaymentService {
  final ApiClient api;
  PaymentService(this.api);

  Future<Map<String, dynamic>> confirmDeposit({
    required int bookingId,
    required String paymentMethod,
    String? providerReference,
  }) async {
    final res = await api.post('/v1/customer/bookings/$bookingId/deposit', {
      'payment_method': paymentMethod,
      if (providerReference != null) 'provider_reference': providerReference,
    });
    return res;
  }
}
