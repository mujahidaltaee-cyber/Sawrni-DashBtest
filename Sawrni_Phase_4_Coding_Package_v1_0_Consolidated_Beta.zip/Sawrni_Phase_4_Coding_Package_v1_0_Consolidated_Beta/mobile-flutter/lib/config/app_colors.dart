import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF07162B);
  static const gold = Color(0xFFD8AA3D);
  static const purple = Color(0xFF7653FF);
  static const surface = Color(0xFFF8F9FB);
}
