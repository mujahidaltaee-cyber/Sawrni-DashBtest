class SawrniStagingEnvironment {
  static const String name = 'staging';
  static const String apiBaseUrl = String.fromEnvironment(
    'SAWRNI_API_BASE_URL',
    defaultValue: 'https://api-staging.sawrni.com/api/v1',
  );
  static const String storageBaseUrl = String.fromEnvironment(
    'SAWRNI_STORAGE_BASE_URL',
    defaultValue: 'https://storage-staging.sawrni.com',
  );
  static const bool useSandboxPayments = bool.fromEnvironment(
    'SAWRNI_USE_SANDBOX_PAYMENTS',
    defaultValue: true,
  );
}
