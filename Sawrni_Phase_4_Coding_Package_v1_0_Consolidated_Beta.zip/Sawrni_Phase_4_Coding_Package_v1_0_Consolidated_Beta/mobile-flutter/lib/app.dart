import 'package:flutter/material.dart';
import 'navigation/app_router.dart';
import 'config/app_colors.dart';

class SawrniApp extends StatelessWidget {
  const SawrniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sawrni',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.navy),
        useMaterial3: true,
      ),
      initialRoute: AppRouter.login,
      routes: AppRouter.routes,
    );
  }
}
