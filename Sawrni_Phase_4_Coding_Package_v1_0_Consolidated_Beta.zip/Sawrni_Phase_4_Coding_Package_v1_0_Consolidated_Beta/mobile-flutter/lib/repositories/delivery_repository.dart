import 'dart:io';
import 'package:http/http.dart' as http;
import '../services/upload_service.dart';

class DeliveryRepository {
  final UploadService uploadService;
  DeliveryRepository(this.uploadService);

  Future<bool> uploadFinalDelivery({required int bookingId, required File file, String? notes}) async {
    final http.StreamedResponse response = await uploadService.uploadDeliveryFile(
      bookingId: bookingId,
      file: file,
      notes: notes,
    );

    return response.statusCode >= 200 && response.statusCode < 300;
  }
}
