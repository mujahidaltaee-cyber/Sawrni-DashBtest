import '../services/api_client.dart';

class ReviewRepository {
  ReviewRepository(this.api);
  final ApiClient api;

  Future<Map<String, dynamic>> submitReview(int bookingId, int rating, String? comment) async {
    final data = await api.post('/api/v1/customer/bookings/$bookingId/reviews', {
      'rating': rating,
      'comment': comment,
    });
    return data['data'] as Map<String, dynamic>;
  }
}
