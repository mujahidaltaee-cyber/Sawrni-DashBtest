import '../services/api_client.dart';

class BookingRepository {
  BookingRepository(this.api);
  final ApiClient api;

  Future<List<dynamic>> myBookings() async {
    final data = await api.get('/api/v1/customer/bookings');
    return data['data'] as List<dynamic>? ?? [];
  }

  Future<Map<String, dynamic>> createBooking(Map<String, dynamic> payload) async {
    final data = await api.post('/api/v1/customer/bookings', payload);
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> updateBooking(int id, Map<String, dynamic> payload) async {
    final data = await api.patch('/api/v1/customer/bookings/$id', payload);
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> cancelBooking(int id) async {
    final data = await api.post('/api/v1/customer/bookings/$id/cancel', {});
    return data['data'] as Map<String, dynamic>;
  }
}
