import '../services/api_client.dart';

class PaymentRepository {
  PaymentRepository(this.api);
  final ApiClient api;

  Future<Map<String, dynamic>> createDepositIntent(int bookingId) async {
    final data = await api.post('/api/v1/customer/bookings/$bookingId/deposit-intent', {});
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> confirmDeposit(int bookingId, Map<String, dynamic> payload) async {
    final data = await api.post('/api/v1/customer/bookings/$bookingId/confirm-deposit', payload);
    return data['data'] as Map<String, dynamic>;
  }
}
