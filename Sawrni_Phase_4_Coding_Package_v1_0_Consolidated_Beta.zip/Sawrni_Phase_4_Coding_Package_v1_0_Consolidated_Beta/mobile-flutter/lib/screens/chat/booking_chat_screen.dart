import 'package:flutter/material.dart';

class BookingChatScreen extends StatefulWidget {
  final int bookingId;
  const BookingChatScreen({super.key, required this.bookingId});

  @override
  State<BookingChatScreen> createState() => _BookingChatScreenState();
}

class _BookingChatScreenState extends State<BookingChatScreen> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Chat')),
      body: Column(
        children: [
          const Expanded(
            child: Center(child: Text('Messages load only after deposit payment.')),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Message'))),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.send)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
