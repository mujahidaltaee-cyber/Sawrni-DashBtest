import 'package:flutter/material.dart';

class MyBookingsScreen extends StatelessWidget {
  const MyBookingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حجوزاتي')),
        body: ListView.builder(
          itemCount: 5,
          itemBuilder: (_, i) => Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(title: Text('حجز رقم ${i + 1}'), subtitle: const Text('بانتظار قبول مزود الخدمة')),
          ),
        ),
      ),
    );
  }
}
