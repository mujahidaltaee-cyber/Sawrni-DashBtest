import 'package:flutter/material.dart';
import '../../navigation/app_router.dart';

class CustomerHomeScreenV07 extends StatelessWidget {
  const CustomerHomeScreenV07({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = ['Graduation', 'Wedding', 'Personal', 'Products', 'Sports', 'Video Edit', 'Models'];
    return Scaffold(
      appBar: AppBar(title: const Text('Sawrni')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Choose service type', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: categories.map((c) => ActionChip(label: Text(c), onPressed: () {})).toList()),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: () => Navigator.pushNamed(context, AppRouter.customerBookings), child: const Text('My bookings')),
        ],
      ),
    );
  }
}
