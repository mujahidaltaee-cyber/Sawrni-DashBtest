import 'package:flutter/material.dart';
import 'booking_checkout_screen.dart';

class ProviderProfileScreen extends StatelessWidget {
  const ProviderProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ملف مزود الخدمة')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const CircleAvatar(radius: 44, child: Icon(Icons.camera_alt)),
            const SizedBox(height: 16),
            const Text('اسم مزود الخدمة', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('نبذة مختصرة عن الخدمة والخبرة.', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BookingCheckoutScreen())), child: const Text('احجز الآن')),
          ],
        ),
      ),
    );
  }
}
