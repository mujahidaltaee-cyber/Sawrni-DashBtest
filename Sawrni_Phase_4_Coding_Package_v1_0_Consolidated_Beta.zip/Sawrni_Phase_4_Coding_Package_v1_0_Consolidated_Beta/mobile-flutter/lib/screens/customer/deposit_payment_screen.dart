import 'package:flutter/material.dart';

class DepositPaymentScreen extends StatefulWidget {
  final int bookingId;
  final int depositIqd;

  const DepositPaymentScreen({super.key, required this.bookingId, required this.depositIqd});

  @override
  State<DepositPaymentScreen> createState() => _DepositPaymentScreenState();
}

class _DepositPaymentScreenState extends State<DepositPaymentScreen> {
  String method = 'electronic';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Deposit Payment')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Deposit: ${widget.depositIqd} IQD', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            RadioListTile(
              value: 'electronic',
              groupValue: method,
              onChanged: (v) => setState(() => method = v!),
              title: const Text('Electronic Payment'),
            ),
            RadioListTile(
              value: 'cash',
              groupValue: method,
              onChanged: (v) => setState(() => method = v!),
              title: const Text('Cash / Admin Confirmation'),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                // Connect to PaymentService.confirmDeposit in integration package.
              },
              child: const Text('Confirm Deposit'),
            ),
          ],
        ),
      ),
    );
  }
}
