import 'package:flutter/material.dart';

class EditBookingScreen extends StatelessWidget {
  final int bookingId;
  const EditBookingScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit booking')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Editing is available only within 3 hours after deposit payment.'),
            const SizedBox(height: 16),
            TextFormField(decoration: const InputDecoration(labelText: 'New date/time')),
            TextFormField(decoration: const InputDecoration(labelText: 'Location')),
            TextFormField(decoration: const InputDecoration(labelText: 'Notes')),
            const SizedBox(height: 24),
            FilledButton(onPressed: () {}, child: const Text('Save changes')),
          ],
        ),
      ),
    );
  }
}
