import 'package:flutter/material.dart';
import '../../core/token_store.dart';
import '../../services/api_client.dart';

class CustomerBookingsScreenV07 extends StatefulWidget {
  const CustomerBookingsScreenV07({super.key});

  @override
  State<CustomerBookingsScreenV07> createState() => _CustomerBookingsScreenV07State();
}

class _CustomerBookingsScreenV07State extends State<CustomerBookingsScreenV07> {
  bool loading = true;
  String? error;
  dynamic data;

  @override
  void initState() {
    super.initState();
    ApiClient(TokenStore()).get('/customer/bookings').then((value) => setState(() { data = value; loading = false; })).catchError((e) => setState(() { error = e.toString(); loading = false; }));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Bookings')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: loading ? const Center(child: CircularProgressIndicator()) : Text(error ?? data.toString()),
      ),
    );
  }
}
