import 'package:flutter/material.dart';

class BookingDetailsScreen extends StatelessWidget {
  final int bookingId;
  const BookingDetailsScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Booking #$bookingId')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('Booking details will be loaded from /customer/bookings/{id}.'),
          SizedBox(height: 12),
          ListTile(title: Text('Provider'), subtitle: Text('Name, phone after deposit, service')),
          ListTile(title: Text('Schedule'), subtitle: Text('Date, time, duration')),
          ListTile(title: Text('Location'), subtitle: Text('Map pin and address')),
          ListTile(title: Text('Payment'), subtitle: Text('Deposit, total, receipt')),
        ],
      ),
    );
  }
}
