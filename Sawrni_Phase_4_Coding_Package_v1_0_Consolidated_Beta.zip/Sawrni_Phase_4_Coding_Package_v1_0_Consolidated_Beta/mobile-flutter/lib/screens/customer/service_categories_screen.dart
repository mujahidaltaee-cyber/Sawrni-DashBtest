import 'package:flutter/material.dart';
import 'providers_screen.dart';

class ServiceCategoriesScreen extends StatelessWidget {
  const ServiceCategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = ['تصوير شخصي', 'تصوير تخرج', 'تصوير أعراس', 'تصوير منتجات', 'تصوير رياضي', 'Video Edit'];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('أنواع التصوير')),
        body: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12),
          itemCount: categories.length,
          itemBuilder: (_, i) => InkWell(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProvidersScreen())),
            child: Card(child: Center(child: Text(categories[i], textAlign: TextAlign.center))),
          ),
        ),
      ),
    );
  }
}
