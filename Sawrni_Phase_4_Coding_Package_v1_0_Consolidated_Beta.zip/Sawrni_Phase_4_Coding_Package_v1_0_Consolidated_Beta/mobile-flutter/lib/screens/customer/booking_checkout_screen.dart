import 'package:flutter/material.dart';

class BookingCheckoutScreen extends StatelessWidget {
  const BookingCheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('إكمال الحجز')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const TextField(decoration: InputDecoration(labelText: 'التاريخ والوقت')),
              const SizedBox(height: 12),
              const TextField(decoration: InputDecoration(labelText: 'الموقع')),
              const SizedBox(height: 12),
              const TextField(maxLines: 3, decoration: InputDecoration(labelText: 'ملاحظات')),
              const Spacer(),
              ElevatedButton(onPressed: () {}, child: const Text('دفع العربون وتأكيد الحجز')),
            ],
          ),
        ),
      ),
    );
  }
}
