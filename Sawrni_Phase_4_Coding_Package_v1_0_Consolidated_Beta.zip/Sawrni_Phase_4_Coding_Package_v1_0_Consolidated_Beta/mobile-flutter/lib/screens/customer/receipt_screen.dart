import 'package:flutter/material.dart';
import '../../config/app_colors.dart';

class ReceiptScreen extends StatelessWidget {
  final String receiptNumber;
  final int totalAmount;
  final int platformCommission;
  final int providerShare;

  const ReceiptScreen({
    super.key,
    required this.receiptNumber,
    required this.totalAmount,
    required this.platformCommission,
    required this.providerShare,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Receipt')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Sawrni Receipt', style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 12),
                Text('Receipt No: $receiptNumber'),
                const Divider(height: 28),
                Text('Total: $totalAmount IQD'),
                Text('Platform commission: $platformCommission IQD'),
                Text('Provider share: $providerShare IQD'),
                const SizedBox(height: 18),
                const Text('This receipt is generated electronically.'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
