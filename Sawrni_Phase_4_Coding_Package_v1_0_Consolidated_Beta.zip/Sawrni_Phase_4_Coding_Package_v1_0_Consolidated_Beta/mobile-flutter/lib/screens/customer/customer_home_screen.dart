import 'package:flutter/material.dart';
import 'service_categories_screen.dart';
import 'models_grid_screen.dart';
import 'my_bookings_screen.dart';

class CustomerHomeScreen extends StatelessWidget {
  const CustomerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('صورني')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _HomeCard(title: 'أنواع التصوير', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ServiceCategoriesScreen()))),
            _HomeCard(title: 'المودلز', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ModelsGridScreen()))),
            _HomeCard(title: 'حجوزاتي', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyBookingsScreen()))),
          ],
        ),
      ),
    );
  }
}

class _HomeCard extends StatelessWidget {
  const _HomeCard({required this.title, required this.onTap});
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(title: Text(title), trailing: const Icon(Icons.arrow_back_ios_new), onTap: onTap),
    );
  }
}
