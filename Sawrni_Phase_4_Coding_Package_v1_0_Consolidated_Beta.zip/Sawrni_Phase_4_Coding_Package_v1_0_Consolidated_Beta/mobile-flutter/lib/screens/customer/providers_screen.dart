import 'package:flutter/material.dart';
import 'provider_profile_screen.dart';

class ProvidersScreen extends StatelessWidget {
  const ProvidersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مزودو الخدمة')),
        body: ListView.builder(
          itemCount: 12,
          itemBuilder: (_, i) => Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text('مزود خدمة ${i + 1}'),
              subtitle: const Text('تصوير / تعديل / مودل'),
              trailing: const Icon(Icons.arrow_back_ios_new),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProviderProfileScreen())),
            ),
          ),
        ),
      ),
    );
  }
}
