import 'package:flutter/material.dart';

class ProviderWalletScreen extends StatelessWidget {
  const ProviderWalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _WalletCard(title: 'Balance', value: '0 IQD'),
          _WalletCard(title: 'Total Earned', value: '0 IQD'),
          _WalletCard(title: 'Debt Threshold', value: '75,000 IQD'),
          SizedBox(height: 16),
          Text('Transactions will be loaded from /v1/provider/wallet'),
        ],
      ),
    );
  }
}

class _WalletCard extends StatelessWidget {
  final String title;
  final String value;
  const _WalletCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(title: Text(title), trailing: Text(value)),
    );
  }
}
