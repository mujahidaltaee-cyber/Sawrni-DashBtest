import 'package:flutter/material.dart';

class ProviderDashboardScreenV07 extends StatelessWidget {
  const ProviderDashboardScreenV07({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Provider Dashboard')),
      body: const Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Assigned bookings'),
            SizedBox(height: 12),
            Text('Wallet and commission'),
            SizedBox(height: 12),
            Text('Delivery upload'),
          ],
        ),
      ),
    );
  }
}
