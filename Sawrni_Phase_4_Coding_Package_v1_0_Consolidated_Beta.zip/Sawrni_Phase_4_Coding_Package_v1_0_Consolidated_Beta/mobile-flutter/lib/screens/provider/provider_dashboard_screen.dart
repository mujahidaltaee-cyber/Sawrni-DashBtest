import 'package:flutter/material.dart';

class ProviderDashboardScreen extends StatelessWidget {
  const ProviderDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('لوحة مزود الخدمة')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: const [
            Card(child: ListTile(title: Text('الحجوزات الجديدة'))),
            Card(child: ListTile(title: Text('المحفظة والأرباح'))),
            Card(child: ListTile(title: Text('رفع ملفات التسليم'))),
            Card(child: ListTile(title: Text('الاشتراك'))),
          ],
        ),
      ),
    );
  }
}
