import 'package:flutter/material.dart';

class ProviderBookingDetailsScreen extends StatelessWidget {
  final int bookingId;
  const ProviderBookingDetailsScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Booking #$bookingId')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Provider booking actions'),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton(onPressed: () {}, child: const Text('Accept')),
              OutlinedButton(onPressed: () {}, child: const Text('Reject')),
              FilledButton(onPressed: () {}, child: const Text('Start')),
              FilledButton(onPressed: () {}, child: const Text('Finish')),
            ],
          ),
          const Divider(height: 32),
          const ListTile(title: Text('Customer'), subtitle: Text('Visible after deposit payment')),
          const ListTile(title: Text('Location'), subtitle: Text('Map/location details')),
          const ListTile(title: Text('Payment'), subtitle: Text('Deposit and total status')),
        ],
      ),
    );
  }
}
