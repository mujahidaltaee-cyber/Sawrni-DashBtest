import 'package:flutter/material.dart';

class DeliveryUploadScreen extends StatelessWidget {
  final int bookingId;
  const DeliveryUploadScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload final delivery')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Booking #$bookingId'),
            const SizedBox(height: 12),
            const Text('Upload the final delivery package only. Management approval is required before customer access.'),
            const SizedBox(height: 20),
            OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.upload_file), label: const Text('Choose file')),
            TextFormField(decoration: const InputDecoration(labelText: 'Label')),
            TextFormField(maxLines: 3, decoration: const InputDecoration(labelText: 'Notes')),
            const SizedBox(height: 20),
            FilledButton(onPressed: () {}, child: const Text('Upload for approval')),
          ],
        ),
      ),
    );
  }
}
