import 'package:flutter/material.dart';

class ProviderProfileScreen extends StatelessWidget {
  const ProviderProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Provider profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(decoration: const InputDecoration(labelText: 'Display name')),
          TextFormField(maxLines: 4, decoration: const InputDecoration(labelText: 'Arabic bio')),
          TextFormField(maxLines: 4, decoration: const InputDecoration(labelText: 'English bio')),
          SwitchListTile(value: true, onChanged: (_) {}, title: const Text('General Baghdad area')),
          TextFormField(decoration: const InputDecoration(labelText: 'Service radius km')),
          const SizedBox(height: 16),
          FilledButton(onPressed: () {}, child: const Text('Save profile')),
        ],
      ),
    );
  }
}
