import 'package:flutter/material.dart';

class ProviderServicesScreen extends StatelessWidget {
  const ProviderServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My services')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const Text('Add service'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: 3,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, index) => Card(
          child: ListTile(
            title: Text('Service offering ${index + 1}'),
            subtitle: const Text('Price, deposit, duration, delivery days'),
            trailing: const Icon(Icons.edit_outlined),
          ),
        ),
      ),
    );
  }
}
