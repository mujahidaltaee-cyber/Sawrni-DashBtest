import 'dart:io';
import 'package:flutter/material.dart';
import '../../utils/file_picker_rules.dart';

class DeliveryUploadScreenV06 extends StatefulWidget {
  final int bookingId;
  const DeliveryUploadScreenV06({super.key, required this.bookingId});

  @override
  State<DeliveryUploadScreenV06> createState() => _DeliveryUploadScreenV06State();
}

class _DeliveryUploadScreenV06State extends State<DeliveryUploadScreenV06> {
  File? selectedFile;
  String? error;

  void validateFileName(String fileName) {
    setState(() {
      error = FilePickerRules.isAllowedExtension(fileName) ? null : 'Unsupported file type';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload final delivery')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Upload the final delivery package. It will be reviewed before the customer can download it.'),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: () {
                validateFileName('sample.zip');
              },
              child: const Text('Select file'),
            ),
            if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: error == null ? () {} : null, child: const Text('Submit for approval')),
            ),
          ],
        ),
      ),
    );
  }
}
