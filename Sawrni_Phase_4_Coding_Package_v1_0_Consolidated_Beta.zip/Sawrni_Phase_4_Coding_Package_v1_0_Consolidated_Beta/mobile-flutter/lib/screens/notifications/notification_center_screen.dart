import 'package:flutter/material.dart';

class NotificationCenterScreen extends StatelessWidget {
  const NotificationCenterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: 6,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (_, index) => ListTile(
          leading: const Icon(Icons.notifications_outlined),
          title: Text('Notification ${index + 1}'),
          subtitle: const Text('Booking/payment/delivery update appears here.'),
          trailing: const Icon(Icons.chevron_right),
        ),
      ),
    );
  }
}
