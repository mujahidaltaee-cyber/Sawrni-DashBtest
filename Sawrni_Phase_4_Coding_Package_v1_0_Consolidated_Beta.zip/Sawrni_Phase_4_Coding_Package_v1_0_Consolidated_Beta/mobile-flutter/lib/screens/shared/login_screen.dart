import 'package:flutter/material.dart';
import '../../core/token_store.dart';
import '../../services/api_client.dart';

class LoginScreen extends StatefulWidget {
  final ApiClient? apiClient;
  final TokenStore? tokenStore;
  final VoidCallback? onLoggedIn;

  const LoginScreen({super.key, this.apiClient, this.tokenStore, this.onLoggedIn});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(text: '07111111111');
  final password = TextEditingController(text: 'password');
  bool loading = false;
  String? error;

  Future<void> login() async {
    if (widget.apiClient == null || widget.tokenStore == null) return;
    setState(() { loading = true; error = null; });
    try {
      final res = await widget.apiClient!.post('/auth/login', {
        'phone': phone.text.trim(),
        'password': password.text,
      });
      final data = (res['data'] ?? res) as Map<String, dynamic>;
      final token = data['token']?.toString() ?? data['access_token']?.toString();
      final role = data['user']?['role']?.toString() ?? 'customer';
      if (token == null) throw Exception('Token missing from login response.');
      await widget.tokenStore!.save(token: token, role: role);
      widget.onLoggedIn?.call();
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sawrni Login')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: phone, decoration: const InputDecoration(labelText: 'Phone number')),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 20),
          FilledButton(onPressed: loading ? null : login, child: Text(loading ? 'Loading...' : 'Login')),
        ],
      ),
    );
  }
}
