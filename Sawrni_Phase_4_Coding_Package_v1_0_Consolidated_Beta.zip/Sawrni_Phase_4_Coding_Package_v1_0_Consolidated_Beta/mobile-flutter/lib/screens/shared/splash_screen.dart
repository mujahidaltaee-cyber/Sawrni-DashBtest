import 'package:flutter/material.dart';
import '../../config/app_colors.dart';
import 'login_screen.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(milliseconds: 900), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
    });

    return const Scaffold(
      backgroundColor: AppColors.navy,
      body: Center(
        child: Text('صورني', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
