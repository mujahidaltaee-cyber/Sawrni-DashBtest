import 'package:flutter/material.dart';
import '../../core/token_store.dart';
import '../../services/api_client.dart';
import '../../services/auth_service_v07.dart';
import '../../navigation/app_router.dart';

class LoginScreenV07 extends StatefulWidget {
  const LoginScreenV07({super.key});

  @override
  State<LoginScreenV07> createState() => _LoginScreenV07State();
}

class _LoginScreenV07State extends State<LoginScreenV07> {
  final phone = TextEditingController(text: '07700000000');
  final otp = TextEditingController(text: '123456');
  String? error;
  bool loading = false;

  Future<void> submit() async {
    setState(() { loading = true; error = null; });
    try {
      final tokenStore = TokenStore();
      final auth = AuthServiceV07(ApiClient(tokenStore), tokenStore);
      await auth.login(phone.text, otp.text);
      if (mounted) Navigator.pushReplacementNamed(context, AppRouter.customerHome);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 48),
              Text('Sawrni', style: Theme.of(context).textTheme.displaySmall),
              const SizedBox(height: 8),
              const Text('Local beta login'),
              const SizedBox(height: 32),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone')),
              const SizedBox(height: 12),
              TextField(controller: otp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'OTP')),
              if (error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(error!, style: const TextStyle(color: Colors.red))),
              const Spacer(),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: loading ? null : submit, child: Text(loading ? 'Loading...' : 'Login'))),
            ],
          ),
        ),
      ),
    );
  }
}
