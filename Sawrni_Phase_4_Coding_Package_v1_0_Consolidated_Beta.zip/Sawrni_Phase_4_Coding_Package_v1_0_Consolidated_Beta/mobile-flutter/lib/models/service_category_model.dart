class ServiceCategoryModel {
  final int id;
  final String nameAr;
  final String nameEn;
  final String slug;
  final String type;

  ServiceCategoryModel({required this.id, required this.nameAr, required this.nameEn, required this.slug, required this.type});

  factory ServiceCategoryModel.fromJson(Map<String, dynamic> json) => ServiceCategoryModel(
    id: json['id'],
    nameAr: json['name_ar'],
    nameEn: json['name_en'],
    slug: json['slug'],
    type: json['type'],
  );
}
