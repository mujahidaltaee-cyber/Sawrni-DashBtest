class UserModel {
  final int id;
  final String name;
  final String phone;
  final String role;
  final String preferredLanguage;

  UserModel({required this.id, required this.name, required this.phone, required this.role, required this.preferredLanguage});

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'],
    name: json['name'],
    phone: json['phone'],
    role: json['role'],
    preferredLanguage: json['preferred_language'] ?? 'ar',
  );
}
