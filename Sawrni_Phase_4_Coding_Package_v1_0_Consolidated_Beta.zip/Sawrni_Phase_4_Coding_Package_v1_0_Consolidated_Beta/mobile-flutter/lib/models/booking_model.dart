class BookingModel {
  final int id;
  final String status;
  final int totalPriceIqd;
  final int depositIqd;
  final String scheduledAt;

  BookingModel({required this.id, required this.status, required this.totalPriceIqd, required this.depositIqd, required this.scheduledAt});

  factory BookingModel.fromJson(Map<String, dynamic> json) => BookingModel(
    id: json['id'],
    status: json['status'],
    totalPriceIqd: json['total_price_iqd'],
    depositIqd: json['deposit_iqd'],
    scheduledAt: json['scheduled_at'],
  );
}
