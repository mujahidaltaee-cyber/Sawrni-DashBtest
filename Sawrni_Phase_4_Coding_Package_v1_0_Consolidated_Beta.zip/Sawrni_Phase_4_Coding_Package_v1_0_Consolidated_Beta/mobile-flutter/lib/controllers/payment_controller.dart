import '../repositories/payment_repository.dart';

class PaymentController {
  PaymentController(this.repository);
  final PaymentRepository repository;

  bool loading = false;
  String? error;

  Future<Map<String, dynamic>?> payFakeDeposit(int bookingId, int amountIqd) async {
    loading = true;
    error = null;
    try {
      await repository.createDepositIntent(bookingId);
      return await repository.confirmDeposit(bookingId, {
        'payment_reference': 'fake-${DateTime.now().millisecondsSinceEpoch}',
        'method': 'electronic',
        'amount_iqd': amountIqd,
        'gateway_payload': {'mode': 'fake'},
      });
    } catch (e) {
      error = e.toString();
      return null;
    } finally {
      loading = false;
    }
  }
}
