import '../repositories/booking_repository.dart';

class BookingController {
  BookingController(this.repository);
  final BookingRepository repository;

  bool loading = false;
  String? error;
  List<dynamic> bookings = [];

  Future<void> refresh() async {
    loading = true;
    error = null;
    try {
      bookings = await repository.myBookings();
    } catch (e) {
      error = e.toString();
    } finally {
      loading = false;
    }
  }
}
