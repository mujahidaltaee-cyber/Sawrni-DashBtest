import 'package:flutter/material.dart';
import 'config/app_environment.dart';
import 'core/auth_context.dart';
import 'core/token_store.dart';
import 'navigation/app_shell.dart';
import 'screens/shared/login_screen.dart';
import 'services/api_client.dart';

class AppBootstrap extends StatefulWidget {
  const AppBootstrap({super.key});

  @override
  State<AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<AppBootstrap> {
  final tokenStore = TokenStore();
  AuthContext? contextState;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = await tokenStore.readToken();
    final role = await tokenStore.readRole();
    setState(() => contextState = AuthContext(token: token, role: role));
  }

  @override
  Widget build(BuildContext context) {
    final auth = contextState;
    if (auth == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final api = ApiClient(baseUrl: AppEnvironment.apiBaseUrl, token: auth.token);

    if (!auth.isAuthenticated) {
      return LoginScreen(apiClient: api, tokenStore: tokenStore, onLoggedIn: _load);
    }

    return AppShell(role: auth.role ?? 'customer');
  }
}
