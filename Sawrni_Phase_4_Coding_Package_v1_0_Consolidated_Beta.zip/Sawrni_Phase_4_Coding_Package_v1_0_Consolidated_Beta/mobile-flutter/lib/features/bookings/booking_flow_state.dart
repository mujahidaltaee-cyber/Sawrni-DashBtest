class BookingFlowState {
  final int bookingId;
  final String status;
  final bool depositPaid;
  final bool chatUnlocked;
  final bool canEdit;
  final bool canCancelWithDepositRefund;
  final String nextRequiredAction;

  const BookingFlowState({
    required this.bookingId,
    required this.status,
    required this.depositPaid,
    required this.chatUnlocked,
    required this.canEdit,
    required this.canCancelWithDepositRefund,
    required this.nextRequiredAction,
  });

  factory BookingFlowState.fromJson(Map<String, dynamic> json) {
    return BookingFlowState(
      bookingId: json['booking_id'] as int,
      status: json['status']?.toString() ?? 'unknown',
      depositPaid: json['deposit_paid'] == true,
      chatUnlocked: json['chat_unlocked'] == true,
      canEdit: json['can_edit'] == true,
      canCancelWithDepositRefund: json['can_cancel_with_deposit_refund'] == true,
      nextRequiredAction: json['next_required_action']?.toString() ?? 'view_booking_details',
    );
  }
}
