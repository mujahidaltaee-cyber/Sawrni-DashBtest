import '../../core/api_client.dart';
import 'booking_flow_state.dart';

class BookingFlowRepository {
  final ApiClient api;

  BookingFlowRepository(this.api);

  Future<BookingFlowState> fetchFlowState(int bookingId) async {
    final json = await api.get('/customer/bookings/$bookingId/flow-state');
    return BookingFlowState.fromJson(json['data'] as Map<String, dynamic>);
  }
}
