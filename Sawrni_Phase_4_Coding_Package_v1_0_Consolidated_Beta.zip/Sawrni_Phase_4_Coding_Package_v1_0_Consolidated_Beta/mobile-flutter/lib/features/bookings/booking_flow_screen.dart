import 'package:flutter/material.dart';

class BookingFlowScreen extends StatelessWidget {
  final int bookingId;

  const BookingFlowScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Flow')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Booking #$bookingId', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            const Text('v0.8 screen scaffold: connect to BookingFlowRepository during Flutter integration.'),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: () {}, child: const Text('Continue next action')),
          ],
        ),
      ),
    );
  }
}
