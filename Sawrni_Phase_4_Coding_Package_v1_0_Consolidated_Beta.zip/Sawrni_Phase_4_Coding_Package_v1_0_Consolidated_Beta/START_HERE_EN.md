# Sawrni v1.0 Consolidated Beta — Start Here

This package is the first consolidated beta coding package for Sawrni. It contains the Laravel backend, Flutter mobile app foundation, admin dashboard foundation, infrastructure templates, scripts, and documentation.

## What This Package Is

A developer-ready beta code package for local installation and staging preparation.

## What This Package Is Not

It is not yet a production deployment, app-store build, or publicly tested system.

## Recommended Review Order

1. Read `VERSION.txt`.
2. Read `docs/PHASE_4_V1_0_RELEASE_NOTES.md`.
3. Read `docs/DEVELOPER_HANDOFF_GUIDE_V1_0.md`.
4. Follow `docs/LOCAL_BETA_RUNBOOK.md`.
5. Run `scripts/verify-environment.sh`.
6. Run local backend migration and seed.
7. Run local API smoke test.
8. Run admin web locally.
9. Run Flutter locally.
10. Use `docs/BETA_ACCEPTANCE_CHECKLIST_V1_0.md` before declaring beta accepted.

## Local Service URLs

- Laravel API: `http://127.0.0.1:8000/api/v1`
- API Health: `http://127.0.0.1:8000/api/v1/health`
- Admin Web: `http://127.0.0.1:3000`
- MinIO Console: `http://127.0.0.1:9001`
- Mailpit: `http://127.0.0.1:8025`

## Key Business Rules Included

- Provider subscriptions: Basic 15,000 IQD, Standard 35,000 IQD, Premium 50,000 IQD.
- Platform commission: 15% of the total booking amount.
- Provider debt suspension threshold: 75,000 IQD.
- Booking edit window: 3 hours after deposit payment.
- Refundable cancellation window: 1 hour after deposit payment.
- Chat unlocks only after deposit payment.
- Customer/provider phone numbers unlock only after deposit payment.
- Delivery files are visible to the customer only after admin/super-admin approval.

## Next Phase

Phase 5 should be Developer Run + Runtime Fixes + First Staging Deployment.
