<?php

return [
    'platform_commission_percent' => (int) env('SAWRNI_COMMISSION_PERCENT', 15),
    'debt_suspension_threshold_iqd' => (int) env('SAWRNI_DEBT_SUSPENSION_THRESHOLD_IQD', 75000),
    'booking_edit_hours_after_deposit' => (int) env('SAWRNI_BOOKING_EDIT_HOURS', 3),
    'booking_cancel_refund_hours_after_deposit' => (int) env('SAWRNI_BOOKING_REFUND_CANCEL_HOURS', 1),
    'initial_city' => 'Baghdad',
    'default_currency' => 'IQD',
];
