<?php

return [
    'default' => env('PAYMENT_GATEWAY', 'fake'),

    'fake' => [
        'webhook_secret' => env('FAKE_PAYMENT_WEBHOOK_SECRET', 'local'),
    ],

    'zaincash' => [
        'stub_mode' => env('ZAINCASH_STUB_MODE', true),
        'api_token' => env('ZAINCASH_API_TOKEN'),
        'intent_url' => env('ZAINCASH_INTENT_URL'),
        'refund_url' => env('ZAINCASH_REFUND_URL'),
        'webhook_secret' => env('ZAINCASH_WEBHOOK_SECRET'),
    ],
];
