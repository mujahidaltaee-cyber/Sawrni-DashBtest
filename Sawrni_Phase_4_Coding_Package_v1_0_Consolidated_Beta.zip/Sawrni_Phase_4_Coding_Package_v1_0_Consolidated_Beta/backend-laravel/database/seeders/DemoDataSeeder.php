<?php

namespace Database\Seeders;

use App\Models\ProviderProfile;
use App\Models\ServiceCategory;
use App\Models\ServiceOffering;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        $customer = User::updateOrCreate(
            ['phone' => '07111111111'],
            ['name' => 'Demo Customer', 'password' => Hash::make('password'), 'role' => 'customer', 'is_active' => true]
        );

        $providerUser = User::updateOrCreate(
            ['phone' => '07222222222'],
            ['name' => 'Demo Photographer', 'password' => Hash::make('password'), 'role' => 'provider', 'is_active' => true]
        );

        $profile = ProviderProfile::updateOrCreate(
            ['user_id' => $providerUser->id],
            [
                'provider_type' => 'photographer',
                'display_name' => 'Sawrni Demo Studio',
                'bio' => 'Demo approved provider for development testing.',
                'approval_status' => 'approved',
                'city' => 'Baghdad',
                'service_radius_km' => 20,
                'service_area_mode' => 'radius',
                'is_public' => true,
                'is_suspended' => false,
            ]
        );

        Wallet::firstOrCreate(['provider_profile_id' => $profile->id], ['balance_iqd' => 0, 'debt_iqd' => 0]);

        $category = ServiceCategory::query()->first();
        if ($category) {
            ServiceOffering::firstOrCreate(
                ['provider_profile_id' => $profile->id, 'service_category_id' => $category->id, 'title_en' => 'Demo Package'],
                [
                    'title_ar' => 'باقة تجريبية',
                    'description_ar' => 'باقة تصوير تجريبية.',
                    'description_en' => 'Demo photography package.',
                    'price_iqd' => 100000,
                    'deposit_iqd' => 20000,
                    'duration_minutes' => 120,
                    'delivery_days' => 5,
                    'is_active' => true,
                ]
            );
        }
    }
}
