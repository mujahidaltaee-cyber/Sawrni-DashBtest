<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['phone' => '07000000000'],
            [
                'name' => 'Sawrni Super Admin',
                'email' => 'owner@sawrni.local',
                'password' => Hash::make('password'),
                'role' => 'super_admin',
                'is_active' => true,
                'preferred_language' => 'ar',
            ]
        );
    }
}
