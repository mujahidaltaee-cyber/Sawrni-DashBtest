<?php

namespace Database\Seeders;

use App\Enums\AdminPermission;
use App\Models\AdminPermissionModel;
use Illuminate\Database\Seeder;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            AdminPermission::CooOperations->value => ['COO Operations', 'صلاحيات تشغيل COO'],
            AdminPermission::ProvidersApprove->value => ['Approve Providers', 'الموافقة على مزودي الخدمة'],
            AdminPermission::ProvidersSuspend->value => ['Suspend Providers', 'تعليق مزودي الخدمة'],
            AdminPermission::BookingsView->value => ['View Bookings', 'عرض الحجوزات'],
            AdminPermission::BookingsReassign->value => ['Reassign Bookings', 'تحويل الحجوزات'],
            AdminPermission::PaymentsReview->value => ['Review Payments', 'مراجعة المدفوعات'],
            AdminPermission::WalletsManage->value => ['Manage Wallets', 'إدارة المحافظ'],
            AdminPermission::DeliveriesApprove->value => ['Approve Deliveries', 'الموافقة على التسليمات'],
            AdminPermission::ReviewsApprove->value => ['Approve Reviews', 'الموافقة على التقييمات'],
            AdminPermission::AdminsManage->value => ['Manage Admins', 'إدارة الأدمنز'],
            AdminPermission::SettingsManage->value => ['Manage Settings', 'إدارة الإعدادات'],
            AdminPermission::ReportsView->value => ['View Reports', 'عرض التقارير'],
        ];

        foreach ($permissions as $key => [$en, $ar]) {
            AdminPermissionModel::updateOrCreate(
                ['key' => $key],
                ['name_en' => $en, 'name_ar' => $ar]
            );
        }
    }
}
