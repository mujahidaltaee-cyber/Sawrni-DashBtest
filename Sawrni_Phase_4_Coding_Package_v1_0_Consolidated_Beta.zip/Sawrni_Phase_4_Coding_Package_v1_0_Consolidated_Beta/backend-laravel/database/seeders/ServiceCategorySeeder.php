<?php

namespace Database\Seeders;

use App\Models\ServiceCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ServiceCategorySeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            ['تصوير شخصي', 'Personal Photography', 'photography'],
            ['تصوير تخرج', 'Graduation Photography', 'photography'],
            ['تصوير أعراس', 'Wedding Photography', 'photography'],
            ['تصوير منتجات', 'Product Photography', 'photography'],
            ['تصوير مناسبات', 'Event Photography', 'photography'],
            ['مطاعم وكافيهات', 'Restaurants and Cafes', 'photography'],
            ['عيادات وشركات', 'Clinics and Companies', 'photography'],
            ['تصوير رياضي', 'Sports Photography', 'photography'],
            ['تعديل فيديو', 'Video Editing', 'editing'],
            ['اختيار مودلز', 'Model Choosing', 'model'],
        ];

        foreach ($items as $index => [$ar, $en, $type]) {
            ServiceCategory::updateOrCreate(
                ['slug' => Str::slug($en)],
                [
                    'name_ar' => $ar,
                    'name_en' => $en,
                    'type' => $type,
                    'is_active' => true,
                    'sort_order' => $index + 1,
                ]
            );
        }
    }
}
