<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('bookings', function (Blueprint $table) {
            $table->timestamp('provider_accepted_at')->nullable()->after('deposit_paid_at');
            $table->timestamp('provider_rejected_at')->nullable()->after('provider_accepted_at');
            $table->timestamp('started_at')->nullable()->after('provider_rejected_at');
            $table->timestamp('finished_at')->nullable()->after('started_at');
            $table->timestamp('completed_at')->nullable()->after('finished_at');
            $table->boolean('refund_eligible')->default(false)->after('cancellation_reason');
            $table->index(['provider_profile_id', 'scheduled_at']);
            $table->index(['customer_id', 'status']);
        });
    }

    public function down(): void {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn([
                'provider_accepted_at',
                'provider_rejected_at',
                'started_at',
                'finished_at',
                'completed_at',
                'refund_eligible',
            ]);
        });
    }
};
