<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProviderProfileFactory extends Factory
{
    public function definition(): array
    {
        return [
            'user_id' => User::factory()->provider(),
            'provider_type' => fake()->randomElement(['photographer', 'editor', 'model']),
            'display_name' => fake()->company(),
            'bio' => fake()->paragraph(),
            'approval_status' => 'approved',
            'city' => 'Baghdad',
            'service_radius_km' => fake()->numberBetween(5, 25),
            'service_area_mode' => 'radius',
            'is_public' => true,
            'is_suspended' => false,
        ];
    }

    public function pending(): static
    {
        return $this->state(fn () => ['approval_status' => 'pending', 'is_public' => false]);
    }
}
