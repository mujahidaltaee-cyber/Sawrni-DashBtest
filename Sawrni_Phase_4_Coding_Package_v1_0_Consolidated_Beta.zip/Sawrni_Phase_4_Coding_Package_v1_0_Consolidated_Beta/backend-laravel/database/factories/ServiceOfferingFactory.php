<?php

namespace Database\Factories;

use App\Models\ProviderProfile;
use App\Models\ServiceCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

class ServiceOfferingFactory extends Factory
{
    public function definition(): array
    {
        $price = fake()->numberBetween(50000, 300000);
        return [
            'provider_profile_id' => ProviderProfile::factory(),
            'service_category_id' => ServiceCategory::factory(),
            'title_ar' => 'باقة تصوير',
            'title_en' => 'Photography Package',
            'description_ar' => 'باقة تجريبية للتطوير.',
            'description_en' => 'Development demo package.',
            'price_iqd' => $price,
            'deposit_iqd' => max(10000, (int) round($price * 0.2)),
            'duration_minutes' => 120,
            'delivery_days' => 7,
            'is_active' => true,
        ];
    }
}
