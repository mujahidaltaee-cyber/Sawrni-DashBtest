<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class UserFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'phone' => '07' . fake()->unique()->numerify('#########'),
            'email' => fake()->unique()->safeEmail(),
            'password' => Hash::make('password'),
            'role' => 'customer',
            'is_active' => true,
            'preferred_language' => 'ar',
        ];
    }

    public function customer(): static { return $this->state(fn () => ['role' => 'customer']); }
    public function provider(): static { return $this->state(fn () => ['role' => 'provider']); }
    public function admin(): static { return $this->state(fn () => ['role' => 'admin']); }
    public function superAdmin(): static { return $this->state(fn () => ['role' => 'super_admin']); }
}
