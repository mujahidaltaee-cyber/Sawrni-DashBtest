<?php

namespace Database\Factories;

use App\Models\ProviderProfile;
use App\Models\ServiceOffering;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class BookingFactory extends Factory
{
    public function definition(): array
    {
        $offering = ServiceOffering::factory()->create();
        return [
            'customer_id' => User::factory()->customer(),
            'provider_profile_id' => $offering->provider_profile_id,
            'service_offering_id' => $offering->id,
            'status' => 'pending_provider',
            'scheduled_at' => now()->addDays(fake()->numberBetween(2, 20)),
            'duration_minutes' => $offering->duration_minutes,
            'location_address' => 'Baghdad demo location',
            'latitude' => 33.3152,
            'longitude' => 44.3661,
            'customer_notes' => 'Demo booking.',
            'total_price_iqd' => $offering->price_iqd,
            'deposit_iqd' => $offering->deposit_iqd,
        ];
    }
}
