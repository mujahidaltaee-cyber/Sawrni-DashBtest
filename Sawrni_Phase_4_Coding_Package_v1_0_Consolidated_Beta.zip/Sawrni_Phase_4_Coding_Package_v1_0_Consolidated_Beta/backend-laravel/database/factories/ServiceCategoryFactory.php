<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ServiceCategoryFactory extends Factory
{
    public function definition(): array
    {
        $nameEn = fake()->words(2, true);
        return [
            'name_ar' => 'تصوير ' . fake()->word(),
            'name_en' => Str::title($nameEn),
            'slug' => Str::slug($nameEn),
            'type' => 'photography',
            'is_active' => true,
            'sort_order' => 10,
        ];
    }
}
