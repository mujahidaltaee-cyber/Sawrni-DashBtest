<?php

namespace App\Jobs;

use App\Models\NotificationLog;
use App\Services\Push\FcmPushService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendPushNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public int $notificationId) {}

    public function handle(FcmPushService $fcm): void
    {
        $notification = NotificationLog::with('user.deviceTokens')->find($this->notificationId);
        if (! $notification || ! $notification->user) return;

        foreach ($notification->user->deviceTokens as $token) {
            $fcm->send($token, $notification->title, $notification->body, $notification->payload ?? []);
        }
    }
}
