<?php

namespace App\Console\Commands;

use App\Models\ProviderProfile;
use Illuminate\Console\Command;

class SuspendProviderDebtsCommand extends Command
{
    protected $signature = 'sawrni:suspend-provider-debts';
    protected $description = 'Suspend providers whose debt reaches the Sawrni debt threshold.';

    public function handle(): int
    {
        $threshold = (int) config('sawrni.debt_suspension_threshold_iqd', 75000);
        $count = 0;

        ProviderProfile::query()
            ->where('is_suspended', false)
            ->whereHas('wallet', fn ($q) => $q->where('debt_iqd', '>=', $threshold))
            ->with('wallet')
            ->chunkById(100, function ($providers) use (&$count, $threshold) {
                foreach ($providers as $provider) {
                    $provider->update([
                        'is_suspended' => true,
                        'suspension_reason' => "Debt threshold reached: {$threshold} IQD.",
                    ]);
                    $count++;
                }
            });

        $this->info("Suspended {$count} providers.");
        return self::SUCCESS;
    }
}
