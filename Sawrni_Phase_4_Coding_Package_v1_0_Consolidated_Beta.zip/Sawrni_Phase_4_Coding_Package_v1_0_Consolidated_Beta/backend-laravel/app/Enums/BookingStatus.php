<?php

namespace App\Enums;

enum BookingStatus: string
{
    case PendingProvider = 'pending_provider';
    case Accepted = 'accepted';
    case Rejected = 'rejected';
    case DepositPaid = 'deposit_paid';
    case Confirmed = 'confirmed';
    case InProgress = 'in_progress';
    case Completed = 'completed';
    case CancelledRefundable = 'cancelled_refundable';
    case CancelledNonRefundable = 'cancelled_non_refundable';
}
