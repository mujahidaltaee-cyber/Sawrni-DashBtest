<?php

namespace App\Enums;

enum SubscriptionPlan: string
{
    case Basic = 'basic';
    case Standard = 'standard';
    case Premium = 'premium';

    public function priceIqd(): int
    {
        return match ($this) {
            self::Basic => 15000,
            self::Standard => 35000,
            self::Premium => 50000,
        };
    }
}
