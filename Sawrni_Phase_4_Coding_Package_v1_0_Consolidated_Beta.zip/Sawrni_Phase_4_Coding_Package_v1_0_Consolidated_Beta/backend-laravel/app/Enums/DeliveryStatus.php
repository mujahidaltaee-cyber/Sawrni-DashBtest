<?php

namespace App\Enums;

enum DeliveryStatus: string
{
    case Uploaded = 'uploaded';
    case PendingApproval = 'pending_approval';
    case Approved = 'approved';
    case Rejected = 'rejected';
}
