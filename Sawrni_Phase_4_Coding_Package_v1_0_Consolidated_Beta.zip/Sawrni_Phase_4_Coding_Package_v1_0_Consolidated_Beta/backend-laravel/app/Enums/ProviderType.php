<?php

namespace App\Enums;

enum ProviderType: string
{
    case Photographer = 'photographer';
    case Editor = 'editor';
    case Model = 'model';
}
