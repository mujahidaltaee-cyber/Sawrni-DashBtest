<?php

namespace App\Enums;

enum BookingAction: string
{
    case Accept = 'accept';
    case Reject = 'reject';
    case Start = 'start';
    case Finish = 'finish';
    case Complete = 'complete';
}
