<?php

namespace App\Enums;

enum WalletTransactionType: string
{
    case BookingCredit = 'booking_credit';
    case PlatformCommission = 'platform_commission';
    case ProviderDebt = 'provider_debt';
    case DebtPayment = 'debt_payment';
    case ManualAdjustment = 'manual_adjustment';
}
