<?php

namespace App\Enums;

enum NotificationType: string
{
    case BookingCreated = 'booking_created';
    case BookingAccepted = 'booking_accepted';
    case BookingRejected = 'booking_rejected';
    case BookingCancelled = 'booking_cancelled';
    case DepositPaid = 'deposit_paid';
    case DeliveryUploaded = 'delivery_uploaded';
    case DeliveryApproved = 'delivery_approved';
    case DeliveryRejected = 'delivery_rejected';
    case WalletDebtWarning = 'wallet_debt_warning';
    case AdminBroadcast = 'admin_broadcast';
}
