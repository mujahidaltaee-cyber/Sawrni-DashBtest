<?php

namespace App\Enums;

enum AdminPermission: string
{
    case CooOperations = 'coo.operations';
    case ProvidersApprove = 'providers.approve';
    case ProvidersSuspend = 'providers.suspend';
    case BookingsView = 'bookings.view';
    case BookingsReassign = 'bookings.reassign';
    case PaymentsReview = 'payments.review';
    case WalletsManage = 'wallets.manage';
    case DeliveriesApprove = 'deliveries.approve';
    case ReviewsApprove = 'reviews.approve';
    case AdminsManage = 'admins.manage';
    case SettingsManage = 'settings.manage';
    case ReportsView = 'reports.view';
}
