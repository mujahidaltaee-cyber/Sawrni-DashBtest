<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProviderProfileResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'provider_type' => $this->provider_type,
            'display_name' => $this->display_name,
            'bio' => $this->bio,
            'city' => $this->city,
            'approval_status' => $this->approval_status,
            'is_public' => (bool) $this->is_public,
            'is_suspended' => (bool) $this->is_suspended,
            'service_radius_km' => $this->service_radius_km,
            'services' => ServiceOfferingResource::collection($this->whenLoaded('services')),
            'user' => new UserResource($this->whenLoaded('user')),
        ];
    }
}
