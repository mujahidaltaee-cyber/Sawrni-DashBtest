<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'scheduled_at' => optional($this->scheduled_at)->toISOString(),
            'duration_minutes' => (int) $this->duration_minutes,
            'location_address' => $this->location_address,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'total_price_iqd' => (int) $this->total_price_iqd,
            'deposit_iqd' => (int) $this->deposit_iqd,
            'deposit_paid_at' => optional($this->deposit_paid_at)->toISOString(),
            'refund_eligible' => (bool) $this->refund_eligible,
            'customer' => new UserResource($this->whenLoaded('customer')),
            'provider' => new ProviderProfileResource($this->whenLoaded('providerProfile')),
            'service' => new ServiceOfferingResource($this->whenLoaded('serviceOffering')),
        ];
    }
}
