<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ServiceOfferingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'service_category_id' => $this->service_category_id,
            'title_ar' => $this->title_ar,
            'title_en' => $this->title_en,
            'price_iqd' => (int) $this->price_iqd,
            'deposit_iqd' => (int) $this->deposit_iqd,
            'duration_minutes' => (int) $this->duration_minutes,
            'delivery_days' => $this->delivery_days,
            'is_active' => (bool) $this->is_active,
        ];
    }
}
