<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WalletResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'provider_profile_id' => $this->provider_profile_id,
            'balance_iqd' => (int) $this->balance_iqd,
            'debt_iqd' => (int) $this->debt_iqd,
            'suspension_threshold_iqd' => (int) config('sawrni.debt_suspension_threshold_iqd', 75000),
        ];
    }
}
