<?php

namespace App\Http\Middleware;

use App\Contracts\PaymentGatewayContract;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerifyPaymentWebhookSignature
{
    public function __construct(private readonly PaymentGatewayContract $gateway) {}

    public function handle(Request $request, Closure $next): Response
    {
        $signature = $request->header('X-Sawrni-Signature')
            ?? $request->header('X-Gateway-Signature');

        if (! $this->gateway->verifyWebhook($request->all(), $signature)) {
            return response()->json(['message' => 'Invalid payment webhook signature.'], 401);
        }

        return $next($request);
    }
}
