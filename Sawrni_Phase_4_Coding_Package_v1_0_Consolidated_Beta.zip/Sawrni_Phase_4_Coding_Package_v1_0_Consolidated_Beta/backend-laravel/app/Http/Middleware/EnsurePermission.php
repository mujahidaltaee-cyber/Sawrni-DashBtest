<?php

namespace App\Http\Middleware;

use App\Services\AdminPermissionService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsurePermission
{
    public function __construct(private AdminPermissionService $permissions) {}

    public function handle(Request $request, Closure $next, string $permission): Response
    {
        if (!$request->user() || !$this->permissions->userHas($request->user(), $permission)) {
            abort(403, 'Missing required permission: ' . $permission);
        }

        return $next($request);
    }
}
