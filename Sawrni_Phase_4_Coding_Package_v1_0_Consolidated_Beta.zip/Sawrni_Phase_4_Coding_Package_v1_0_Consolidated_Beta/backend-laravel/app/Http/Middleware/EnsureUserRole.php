<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();
        abort_unless($user, 401);
        abort_unless(in_array($user->role, $roles, true), 403, 'User role is not allowed.');
        abort_if($user->is_active === false, 403, 'User account is inactive.');

        return $next($request);
    }
}
