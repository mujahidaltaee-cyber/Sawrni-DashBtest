<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureAdminPermission
{
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();
        abort_unless($user, 401);

        if ($user->role === 'super_admin') {
            return $next($request);
        }

        abort_unless($user->role === 'admin', 403, 'Only admins can use this permission.');

        $hasPermission = $user->adminPermissions()
            ->where('permission', $permission)
            ->where('is_enabled', true)
            ->exists();

        abort_unless($hasPermission, 403, 'Missing admin permission: '.$permission);

        return $next($request);
    }
}
