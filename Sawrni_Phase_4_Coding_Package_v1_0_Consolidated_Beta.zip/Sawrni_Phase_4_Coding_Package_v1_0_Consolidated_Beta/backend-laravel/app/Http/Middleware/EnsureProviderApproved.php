<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureProviderApproved
{
    public function handle(Request $request, Closure $next): Response
    {
        $profile = $request->user()?->providerProfile;

        abort_unless($profile, 403, 'Provider profile is required.');
        abort_unless($profile->approval_status === 'approved', 403, 'Provider account is not approved yet.');
        abort_if($profile->is_suspended, 403, 'Provider account is suspended.');

        return $next($request);
    }
}
