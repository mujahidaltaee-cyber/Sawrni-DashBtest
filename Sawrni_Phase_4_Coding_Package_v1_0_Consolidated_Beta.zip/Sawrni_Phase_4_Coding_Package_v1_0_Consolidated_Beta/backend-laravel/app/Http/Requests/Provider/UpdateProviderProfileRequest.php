<?php

namespace App\Http\Requests\Provider;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProviderProfileRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'display_name' => ['sometimes', 'string', 'max:255'],
            'bio_ar' => ['sometimes', 'nullable', 'string', 'max:3000'],
            'bio_en' => ['sometimes', 'nullable', 'string', 'max:3000'],
            'provider_type' => ['sometimes', 'string', 'in:photographer,editor,model'],
            'service_radius_km' => ['sometimes', 'nullable', 'integer', 'min:1', 'max:100'],
            'is_general_area' => ['sometimes', 'boolean'],
        ];
    }
}
