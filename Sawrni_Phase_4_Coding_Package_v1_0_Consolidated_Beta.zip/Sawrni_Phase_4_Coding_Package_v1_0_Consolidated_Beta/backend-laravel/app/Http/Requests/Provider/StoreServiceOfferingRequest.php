<?php

namespace App\Http\Requests\Provider;

use Illuminate\Foundation\Http\FormRequest;

class StoreServiceOfferingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'provider';
    }

    public function rules(): array
    {
        return [
            'service_category_id' => ['required', 'integer', 'exists:service_categories,id'],
            'title_ar' => ['required', 'string', 'max:120'],
            'title_en' => ['nullable', 'string', 'max:120'],
            'description_ar' => ['nullable', 'string', 'max:1000'],
            'description_en' => ['nullable', 'string', 'max:1000'],
            'price_iqd' => ['required', 'integer', 'min:1000'],
            'deposit_amount_iqd' => ['required', 'integer', 'min:1000', 'lte:price_iqd'],
            'duration_minutes' => ['required', 'integer', 'min:30', 'max:720'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
