<?php

namespace App\Http\Requests\Provider;

use App\Rules\SafeDeliveryFile;
use Illuminate\Foundation\Http\FormRequest;

class UploadDeliveryFileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'provider';
    }

    public function rules(): array
    {
        return [
            'file' => ['required', 'file', 'max:2097152', new SafeDeliveryFile()],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
