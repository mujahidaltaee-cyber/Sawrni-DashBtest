<?php

namespace App\Http\Requests\Customer;

use Illuminate\Foundation\Http\FormRequest;

class ConfirmDepositRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'customer';
    }

    public function rules(): array
    {
        return [
            'payment_reference' => ['required', 'string', 'max:191'],
            'method' => ['required', 'string', 'in:cash,electronic'],
            'amount_iqd' => ['required', 'integer', 'min:1000'],
            'gateway_payload' => ['nullable', 'array'],
        ];
    }
}
