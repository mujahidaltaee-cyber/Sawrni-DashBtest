<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateServiceCategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->role === 'super_admin' || $this->user()?->hasAdminPermission('manage_service_categories');
    }

    public function rules(): array
    {
        $categoryId = $this->route('serviceCategory')?->id;

        return [
            'name_ar' => ['sometimes', 'string', 'max:120'],
            'name_en' => ['sometimes', 'string', 'max:120'],
            'slug' => ['sometimes', 'string', 'max:140', Rule::unique('service_categories', 'slug')->ignore($categoryId)],
            'is_active' => ['sometimes', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
