<?php

namespace App\Http\Controllers\Api;

use App\Contracts\PaymentGatewayContract;
use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\PaymentEvent;
use App\Services\PaymentWorkflowService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentWebhookController extends Controller
{
    public function __construct(
        private readonly PaymentGatewayContract $gateway,
        private readonly PaymentWorkflowService $paymentWorkflow
    ) {}

    public function __invoke(Request $request, string $gateway): JsonResponse
    {
        $result = $this->gateway->parseWebhook($request->all());

        PaymentEvent::query()->create([
            'gateway' => $gateway,
            'gateway_reference' => $result->gatewayReference,
            'event_type' => $request->input('type', 'payment.updated'),
            'payload' => $request->all(),
            'received_at' => now(),
        ]);

        if (! $result->gatewayReference) {
            return response()->json(['message' => 'Webhook accepted without reference.']);
        }

        $payment = Payment::query()
            ->where('gateway_reference', $result->gatewayReference)
            ->orWhere('reference', $request->input('reference'))
            ->first();

        if (! $payment) {
            return response()->json(['message' => 'Payment not found; event stored.'], 202);
        }

        if (in_array($result->status, ['paid', 'success', 'completed'], true)) {
            $this->paymentWorkflow->markDepositPaid($payment);
        }

        return response()->json(['message' => 'Webhook processed.']);
    }
}
