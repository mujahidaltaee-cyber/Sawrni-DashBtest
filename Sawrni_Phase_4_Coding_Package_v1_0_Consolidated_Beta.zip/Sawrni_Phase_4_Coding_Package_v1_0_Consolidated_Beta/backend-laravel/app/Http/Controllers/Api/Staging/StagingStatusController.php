<?php

namespace App\Http\Controllers\Api\Staging;

use App\Http\Controllers\Controller;
use App\Services\Staging\StagingReadinessService;
use Illuminate\Http\JsonResponse;

class StagingStatusController extends Controller
{
    public function __invoke(StagingReadinessService $service): JsonResponse
    {
        return response()->json([
            'status' => 'ok',
            'package' => 'Sawrni Phase 4 v0.9',
            'purpose' => 'staging readiness verification',
            'checks' => $service->report(),
        ]);
    }
}
