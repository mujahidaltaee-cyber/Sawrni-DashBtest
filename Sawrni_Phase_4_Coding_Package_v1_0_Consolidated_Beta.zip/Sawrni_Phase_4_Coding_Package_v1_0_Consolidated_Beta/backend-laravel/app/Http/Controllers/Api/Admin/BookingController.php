<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $bookings = Booking::query()
            ->with(['customer', 'providerProfile.user', 'serviceOffering'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->when($request->filled('provider_profile_id'), fn ($q) => $q->where('provider_profile_id', $request->integer('provider_profile_id')))
            ->when($request->filled('customer_id'), fn ($q) => $q->where('customer_id', $request->integer('customer_id')))
            ->latest()
            ->paginate(30);

        return ApiResponse::success($bookings);
    }

    public function show(Booking $booking): JsonResponse
    {
        return ApiResponse::success($booking->load([
            'customer', 'providerProfile.user', 'serviceOffering.serviceCategory',
            'payments', 'walletTransactions', 'deliveryFiles', 'statusHistory'
        ]));
    }
}
