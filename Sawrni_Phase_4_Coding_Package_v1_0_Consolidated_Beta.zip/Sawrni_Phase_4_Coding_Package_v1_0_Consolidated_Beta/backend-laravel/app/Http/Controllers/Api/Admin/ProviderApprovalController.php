<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderProfile;
use App\Services\ProviderApprovalService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class ProviderApprovalController extends Controller
{
    public function pending()
    {
        return ApiResponse::success(
            ProviderProfile::with('user')->where('approval_status', 'pending')->latest()->paginate(20)
        );
    }

    public function approve(Request $request, ProviderProfile $provider, ProviderApprovalService $service)
    {
        return ApiResponse::success($service->approve($provider, $request->user()->id), 'Provider approved');
    }

    public function reject(Request $request, ProviderProfile $provider, ProviderApprovalService $service)
    {
        $data = $request->validate(['reason' => ['required', 'string']]);
        return ApiResponse::success($service->reject($provider, $data['reason']), 'Provider rejected');
    }
}
