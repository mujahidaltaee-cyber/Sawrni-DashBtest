<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderProfile;
use App\Models\ProviderSubscription;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SubscriptionAdminController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(ProviderSubscription::query()->with('providerProfile.user')->latest()->paginate(20));
    }

    public function assign(Request $request, ProviderProfile $providerProfile): JsonResponse
    {
        $data = $request->validate([
            'plan' => ['required', 'in:basic,standard,premium'],
            'starts_at' => ['required', 'date'],
            'ends_at' => ['required', 'date', 'after:starts_at'],
            'amount_iqd' => ['required', 'integer', 'min:0'],
        ]);

        $subscription = ProviderSubscription::query()->create([
            ...$data,
            'provider_profile_id' => $providerProfile->id,
            'status' => 'active',
            'created_by' => $request->user()->id,
        ]);

        return response()->json($subscription, 201);
    }

    public function cancel(ProviderSubscription $providerSubscription): JsonResponse
    {
        $providerSubscription->forceFill(['status' => 'cancelled', 'cancelled_at' => now()])->save();

        return response()->json(['message' => 'Subscription cancelled.']);
    }
}
