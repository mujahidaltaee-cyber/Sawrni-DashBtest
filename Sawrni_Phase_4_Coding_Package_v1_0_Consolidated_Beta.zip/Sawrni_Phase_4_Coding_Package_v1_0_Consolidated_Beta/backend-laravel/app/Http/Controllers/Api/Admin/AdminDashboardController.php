<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Models\User;
use App\Models\Payment;
use App\Support\ApiResponse;

class AdminDashboardController extends Controller
{
    public function summary()
    {
        return ApiResponse::success([
            'customers' => User::where('role', 'customer')->count(),
            'providers_pending' => ProviderProfile::where('approval_status', 'pending')->count(),
            'providers_approved' => ProviderProfile::where('approval_status', 'approved')->count(),
            'bookings_total' => Booking::count(),
            'bookings_today' => Booking::whereDate('created_at', today())->count(),
            'payments_paid_iqd' => Payment::where('status', 'paid')->sum('amount_iqd'),
        ]);
    }
}
