<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BookingActionAdminController extends Controller
{
    public function resolveDispute(Request $request, Booking $booking): JsonResponse
    {
        $data = $request->validate([
            'resolution' => ['required', 'string', 'max:2000'],
            'mark_status' => ['nullable', 'in:completed,cancelled,refunded,disputed'],
        ]);

        $booking->forceFill([
            'admin_resolution' => $data['resolution'],
            'resolved_by' => $request->user()->id,
            'resolved_at' => now(),
            'status' => $data['mark_status'] ?? $booking->status,
        ])->save();

        return response()->json(['message' => 'Booking dispute resolved.', 'booking' => $booking->refresh()]);
    }
}
