<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProviderAdminController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $providers = ProviderProfile::query()
            ->with('user')
            ->when($request->filled('status'), fn ($q) => $q->where('approval_status', $request->status))
            ->when($request->filled('type'), fn ($q) => $q->where('provider_type', $request->type))
            ->latest()
            ->paginate(20);

        return response()->json($providers);
    }

    public function show(ProviderProfile $providerProfile): JsonResponse
    {
        return response()->json($providerProfile->load(['user', 'serviceOfferings', 'portfolioItems', 'wallet']));
    }

    public function suspend(ProviderProfile $providerProfile): JsonResponse
    {
        $providerProfile->forceFill(['suspended_at' => now(), 'is_visible' => false])->save();

        return response()->json(['message' => 'Provider suspended.']);
    }

    public function reactivate(ProviderProfile $providerProfile): JsonResponse
    {
        $providerProfile->forceFill(['suspended_at' => null, 'is_visible' => true])->save();

        return response()->json(['message' => 'Provider reactivated.']);
    }
}
