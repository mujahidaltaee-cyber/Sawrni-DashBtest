<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SaveServiceCategoryRequest;
use App\Models\ServiceCategory;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class ServiceCategoryController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(ServiceCategory::query()->orderBy('sort_order')->paginate(50));
    }

    public function store(SaveServiceCategoryRequest $request): JsonResponse
    {
        $category = ServiceCategory::create($request->validated());
        return ApiResponse::success($category, 'Service category created.', 201);
    }

    public function update(SaveServiceCategoryRequest $request, ServiceCategory $serviceCategory): JsonResponse
    {
        $serviceCategory->update($request->validated());
        return ApiResponse::success($serviceCategory->refresh(), 'Service category updated.');
    }
}
