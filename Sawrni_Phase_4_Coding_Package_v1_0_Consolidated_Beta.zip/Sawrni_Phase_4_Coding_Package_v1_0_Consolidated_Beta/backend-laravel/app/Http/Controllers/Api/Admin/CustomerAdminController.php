<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CustomerAdminController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $customers = User::query()
            ->where('role', 'customer')
            ->when($request->filled('q'), fn ($q) => $q->where('full_name', 'like', '%' . $request->q . '%')->orWhere('phone', 'like', '%' . $request->q . '%'))
            ->latest()
            ->paginate(20);

        return response()->json($customers);
    }

    public function show(User $customer): JsonResponse
    {
        abort_unless($customer->role === 'customer', 404);

        return response()->json($customer->load(['customerProfile']));
    }

    public function suspend(User $customer): JsonResponse
    {
        abort_unless($customer->role === 'customer', 404);
        $customer->forceFill(['suspended_at' => now()])->save();

        return response()->json(['message' => 'Customer suspended.']);
    }

    public function reactivate(User $customer): JsonResponse
    {
        abort_unless($customer->role === 'customer', 404);
        $customer->forceFill(['suspended_at' => null])->save();

        return response()->json(['message' => 'Customer reactivated.']);
    }
}
