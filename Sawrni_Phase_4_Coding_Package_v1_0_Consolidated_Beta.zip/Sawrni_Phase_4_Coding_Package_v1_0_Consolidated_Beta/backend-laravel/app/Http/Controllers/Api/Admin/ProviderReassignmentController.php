<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Support\ApiResponse;
use Illuminate\Http\Request;
use RuntimeException;

class ProviderReassignmentController extends Controller
{
    public function requestCustomerApproval(Request $request, Booking $booking)
    {
        $data = $request->validate([
            'new_provider_profile_id' => ['required', 'integer', 'exists:provider_profiles,id'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $newProvider = ProviderProfile::query()->findOrFail($data['new_provider_profile_id']);
        if ($newProvider->approval_status !== 'approved') {
            throw new RuntimeException('New provider is not approved.');
        }

        $booking->reassignment_requested_provider_id = $newProvider->id;
        $booking->reassignment_reason = $data['reason'];
        $booking->reassignment_status = 'pending_customer_approval';
        $booking->save();

        return ApiResponse::success($booking, 'Provider reassignment was sent to customer for approval.');
    }
}
