<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BroadcastNotificationRequest;
use App\Services\NotificationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class NotificationBroadcastController extends Controller
{
    public function __construct(private NotificationService $notifications) {}

    public function store(BroadcastNotificationRequest $request): JsonResponse
    {
        $data = $request->validated();
        $count = $this->notifications->broadcast(
            $data['audience'],
            $data['title_ar'],
            $data['body_ar'],
            [
                'title_en' => $data['title_en'] ?? null,
                'body_en' => $data['body_en'] ?? null,
                'created_by' => auth()->id(),
            ]
        );

        return ApiResponse::success(['sent_to' => $count], 'Notification broadcast queued.');
    }
}
