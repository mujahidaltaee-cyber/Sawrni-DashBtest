<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryFile;
use App\Services\DeliveryApprovalService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class DeliveryApprovalController extends Controller
{
    public function pending()
    {
        return ApiResponse::success(
            DeliveryFile::where('status', 'pending_approval')->with(['booking', 'provider'])->latest()->paginate(20)
        );
    }

    public function approve(Request $request, DeliveryFile $file, DeliveryApprovalService $service)
    {
        return ApiResponse::success($service->approve($file, $request->user()->id), 'Delivery approved');
    }

    public function reject(Request $request, DeliveryFile $file, DeliveryApprovalService $service)
    {
        $data = $request->validate(['reason' => ['required', 'string']]);
        return ApiResponse::success($service->reject($file, $data['reason']), 'Delivery rejected');
    }
}
