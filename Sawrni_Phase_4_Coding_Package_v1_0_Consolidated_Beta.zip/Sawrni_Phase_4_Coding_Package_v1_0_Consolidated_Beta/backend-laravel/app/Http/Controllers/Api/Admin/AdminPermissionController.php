<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GrantAdminPermissionRequest;
use App\Models\AdminPermissionModel;
use App\Models\User;
use App\Services\AdminPermissionService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class AdminPermissionController extends Controller
{
    public function index()
    {
        return ApiResponse::success(AdminPermissionModel::orderBy('key')->get());
    }

    public function sync(GrantAdminPermissionRequest $request, AdminPermissionService $service)
    {
        $target = User::findOrFail($request->validated('user_id'));
        $service->syncPermissions($target, $request->validated('permissions'), $request->user());

        return ApiResponse::success(null, 'Admin permissions updated.');
    }
}
