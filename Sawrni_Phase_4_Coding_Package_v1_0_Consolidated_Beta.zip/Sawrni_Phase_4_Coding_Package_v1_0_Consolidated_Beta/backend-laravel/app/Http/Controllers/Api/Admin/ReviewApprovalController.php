<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Review;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class ReviewApprovalController extends Controller
{
    public function pending()
    {
        return ApiResponse::success(Review::query()->where('status', 'pending_approval')->latest()->paginate(25));
    }

    public function approve(Request $request, Review $review)
    {
        $review->status = 'approved';
        $review->approved_by = $request->user()->id;
        $review->approved_at = now();
        $review->save();

        return ApiResponse::success($review, 'Review approved.');
    }

    public function reject(Request $request, Review $review)
    {
        $review->status = 'rejected';
        $review->rejected_by = $request->user()->id;
        $review->rejected_at = now();
        $review->rejection_reason = $request->input('reason');
        $review->save();

        return ApiResponse::success($review, 'Review rejected.');
    }
}
