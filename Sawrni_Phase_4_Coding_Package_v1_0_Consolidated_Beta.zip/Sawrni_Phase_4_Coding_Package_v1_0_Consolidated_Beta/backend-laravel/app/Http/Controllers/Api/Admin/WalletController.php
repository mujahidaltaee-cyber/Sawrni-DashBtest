<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderProfile;
use App\Services\ProviderSuspensionService;
use App\Services\WalletService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    public function index()
    {
        return ApiResponse::success(
            ProviderProfile::with(['user', 'wallet'])->latest()->paginate(30)
        );
    }

    public function recordDebtPayment(Request $request, ProviderProfile $provider, WalletService $walletService, ProviderSuspensionService $suspensionService)
    {
        $data = $request->validate([
            'amount_iqd' => ['required', 'integer', 'min:1'],
            'note' => ['nullable', 'string', 'max:500'],
        ]);

        $transaction = $walletService->recordDebtPayment($provider, $data['amount_iqd'], $data['note'] ?? null);

        if (!$suspensionService->shouldSuspend($provider) && $provider->is_suspended) {
            $provider->update(['is_suspended' => false, 'suspension_reason' => null]);
        }

        return ApiResponse::success($transaction, 'Debt payment recorded.');
    }
}
