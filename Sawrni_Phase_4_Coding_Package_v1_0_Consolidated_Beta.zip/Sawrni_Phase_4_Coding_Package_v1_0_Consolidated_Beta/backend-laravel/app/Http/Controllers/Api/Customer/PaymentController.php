<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Http\Requests\Customer\ConfirmDepositRequest;
use App\Models\Booking;
use App\Services\PaymentService;
use App\Support\ApiResponse;

class PaymentController extends Controller
{
    public function __construct(private PaymentService $paymentService) {}

    public function confirmDeposit(ConfirmDepositRequest $request, Booking $booking)
    {
        abort_unless($booking->customer_id === $request->user()->id, 403);

        $result = $this->paymentService->confirmDeposit($booking, $request->validated(), $request->user()->id);

        return ApiResponse::success($result, 'Deposit confirmed.');
    }
}
