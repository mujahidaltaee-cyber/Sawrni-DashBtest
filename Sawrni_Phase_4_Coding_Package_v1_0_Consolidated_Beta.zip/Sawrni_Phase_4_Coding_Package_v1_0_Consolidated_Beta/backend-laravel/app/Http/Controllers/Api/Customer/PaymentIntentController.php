<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Payment;
use App\Services\Payments\PaymentGatewayManager;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class PaymentIntentController extends Controller
{
    public function __construct(private PaymentGatewayManager $gateways) {}

    public function createDepositIntent(Booking $booking): JsonResponse
    {
        abort_unless($booking->customer_id === auth()->id(), 403);
        abort_if($booking->deposit_paid_at !== null, 422, 'Deposit has already been paid.');

        $result = $this->gateways->gateway()->createDepositIntent($booking);

        $payment = Payment::create([
            'booking_id' => $booking->id,
            'payer_id' => auth()->id(),
            'amount_iqd' => $booking->deposit_iqd,
            'method' => 'electronic',
            'status' => $result->status,
            'external_reference' => $result->externalReference,
            'raw_payload' => $result->raw,
        ]);

        return ApiResponse::success([
            'payment' => $payment,
            'gateway' => $result->raw,
        ], 'Deposit payment intent created.', 201);
    }
}
