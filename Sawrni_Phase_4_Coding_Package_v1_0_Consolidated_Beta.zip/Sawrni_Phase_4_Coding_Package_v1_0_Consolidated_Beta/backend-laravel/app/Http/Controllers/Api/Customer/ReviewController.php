<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Http\Requests\Customer\StoreReviewRequest;
use App\Models\Booking;
use App\Services\ReviewWorkflowService;
use App\Support\ApiResponse;

class ReviewController extends Controller
{
    public function store(StoreReviewRequest $request, Booking $booking, ReviewWorkflowService $reviews)
    {
        $review = $reviews->createCustomerReview($request->user(), $booking, $request->validated());
        return ApiResponse::success($review, 'Review submitted and pending approval.');
    }
}
