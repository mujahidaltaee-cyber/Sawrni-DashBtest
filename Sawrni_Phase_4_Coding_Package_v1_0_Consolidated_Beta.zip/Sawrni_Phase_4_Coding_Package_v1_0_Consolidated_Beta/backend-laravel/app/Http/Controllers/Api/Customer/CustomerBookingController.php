<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Http\Requests\Customer\CancelBookingRequest;
use App\Http\Requests\Customer\CreateBookingRequest;
use App\Http\Requests\Customer\UpdateBookingRequest;
use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Models\ServiceOffering;
use App\Services\BookingService;
use App\Services\NotificationService;
use App\Services\ScheduleConflictService;
use App\Support\ApiResponse;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class CustomerBookingController extends Controller
{
    public function __construct(
        private BookingService $bookingRules,
        private ScheduleConflictService $conflicts,
        private NotificationService $notifications,
    ) {}

    public function index(): JsonResponse
    {
        $bookings = Booking::query()
            ->where('customer_id', auth()->id())
            ->with(['providerProfile.user', 'serviceOffering'])
            ->latest()
            ->paginate(20);

        return ApiResponse::success($bookings);
    }

    public function show(Booking $booking): JsonResponse
    {
        abort_unless($booking->customer_id === auth()->id(), 403);

        return ApiResponse::success($booking->load([
            'providerProfile.user', 'serviceOffering.serviceCategory', 'payments', 'deliveryFiles', 'statusHistory'
        ]));
    }

    public function store(CreateBookingRequest $request): JsonResponse
    {
        $data = $request->validated();
        $provider = ProviderProfile::findOrFail($data['provider_profile_id']);
        $offering = ServiceOffering::findOrFail($data['service_offering_id']);

        abort_unless($provider->approval_status === 'approved', 422, 'Provider is not approved.');
        abort_unless($offering->provider_profile_id === $provider->id && $offering->is_active, 422, 'Invalid service offering.');

        $scheduledAt = Carbon::parse($data['scheduled_at']);
        $duration = $data['duration_minutes'] ?? $offering->duration_minutes;
        $this->conflicts->assertNoConflict($provider, $scheduledAt, $duration);

        $booking = DB::transaction(function () use ($data, $provider, $offering, $scheduledAt, $duration) {
            $booking = Booking::create([
                'customer_id' => auth()->id(),
                'provider_profile_id' => $provider->id,
                'service_offering_id' => $offering->id,
                'status' => 'pending_provider',
                'scheduled_at' => $scheduledAt,
                'duration_minutes' => $duration,
                'location_address' => $data['location_address'] ?? null,
                'latitude' => $data['latitude'],
                'longitude' => $data['longitude'],
                'customer_notes' => $data['customer_notes'] ?? null,
                'total_price_iqd' => $offering->price_iqd,
                'deposit_iqd' => $offering->deposit_iqd,
            ]);

            $booking->statusHistory()->create([
                'old_status' => null,
                'new_status' => 'pending_provider',
                'changed_by' => auth()->id(),
                'note' => 'Customer created booking.',
            ]);

            $this->notifications->bookingCreated($booking);
            return $booking;
        });

        return ApiResponse::success($booking->load(['providerProfile.user', 'serviceOffering']), 'Booking created.', 201);
    }

    public function update(UpdateBookingRequest $request, Booking $booking): JsonResponse
    {
        abort_unless($booking->customer_id === auth()->id(), 403);
        abort_unless($this->bookingRules->canCustomerEdit($booking), 422, 'Booking edit window has expired.');

        $data = $request->validated();
        $scheduledAt = isset($data['scheduled_at']) ? Carbon::parse($data['scheduled_at']) : Carbon::parse($booking->scheduled_at);
        $duration = $data['duration_minutes'] ?? $booking->duration_minutes;

        $this->conflicts->assertNoConflict($booking->providerProfile, $scheduledAt, $duration, $booking->id);

        $booking->fill($data);
        if (isset($data['scheduled_at'])) $booking->scheduled_at = $scheduledAt;
        $booking->save();

        $booking->statusHistory()->create([
            'old_status' => $booking->status,
            'new_status' => $booking->status,
            'changed_by' => auth()->id(),
            'note' => 'Customer edited booking details.',
        ]);

        return ApiResponse::success($booking->refresh(), 'Booking updated.');
    }

    public function cancel(CancelBookingRequest $request, Booking $booking): JsonResponse
    {
        abort_unless($booking->customer_id === auth()->id(), 403);
        abort_if(in_array($booking->status, ['completed', 'cancelled'], true), 422, 'Booking cannot be cancelled.');

        $refundEligible = $this->bookingRules->isRefundEligibleOnCustomerCancel($booking);

        $booking->update([
            'status' => 'cancelled',
            'cancelled_at' => now(),
            'cancelled_by' => auth()->id(),
            'cancellation_reason' => $request->validated('reason'),
            'refund_eligible' => $refundEligible,
        ]);

        $booking->statusHistory()->create([
            'old_status' => null,
            'new_status' => 'cancelled',
            'changed_by' => auth()->id(),
            'note' => $refundEligible ? 'Cancelled inside refundable window.' : 'Cancelled after refundable window.',
        ]);

        $this->notifications->bookingStatusChanged($booking, null, 'cancelled');

        return ApiResponse::success([
            'booking' => $booking->refresh(),
            'refund_eligible' => $refundEligible,
        ], 'Booking cancelled.');
    }
}
