<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class BookingFlowStateController extends Controller
{
    public function show(Booking $booking): JsonResponse
    {
        $user = request()->user();

        if ($booking->customer_id !== $user->id) {
            abort(403, 'You are not allowed to view this booking flow.');
        }

        $depositPaid = (bool) ($booking->deposit_paid_at ?? false);
        $now = now();

        $editUntil = $booking->deposit_paid_at ? $booking->deposit_paid_at->copy()->addHours(3) : null;
        $refundCancelUntil = $booking->deposit_paid_at ? $booking->deposit_paid_at->copy()->addHour() : null;

        return ApiResponse::success([
            'booking_id' => $booking->id,
            'status' => $booking->status,
            'deposit_paid' => $depositPaid,
            'chat_unlocked' => $depositPaid,
            'can_edit' => $editUntil ? $now->lessThanOrEqualTo($editUntil) : false,
            'can_cancel_with_deposit_refund' => $refundCancelUntil ? $now->lessThanOrEqualTo($refundCancelUntil) : false,
            'edit_until' => optional($editUntil)->toISOString(),
            'refund_cancel_until' => optional($refundCancelUntil)->toISOString(),
            'delivery_visible' => in_array($booking->status, ['completed', 'delivered'], true),
            'next_required_action' => $this->nextAction($booking, $depositPaid),
        ]);
    }

    private function nextAction(Booking $booking, bool $depositPaid): string
    {
        if (! $depositPaid) {
            return 'pay_deposit';
        }

        return match ((string) $booking->status) {
            'pending_provider_acceptance' => 'wait_for_provider_acceptance',
            'accepted' => 'wait_for_session_date',
            'in_progress' => 'wait_for_provider_completion',
            'awaiting_delivery_approval' => 'wait_for_admin_delivery_approval',
            'completed', 'delivered' => 'download_files_and_review',
            'cancelled' => 'booking_cancelled',
            default => 'view_booking_details',
        };
    }
}
