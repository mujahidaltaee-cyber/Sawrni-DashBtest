<?php

namespace App\Http\Controllers\Api\Provider;

use App\Http\Controllers\Controller;
use App\Http\Requests\Provider\UpdateProviderProfileRequest;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class ProviderProfileController extends Controller
{
    public function show(): JsonResponse
    {
        return ApiResponse::success(auth()->user()->providerProfile->load(['services', 'portfolioItems', 'wallet', 'subscription']));
    }

    public function update(UpdateProviderProfileRequest $request): JsonResponse
    {
        $profile = auth()->user()->providerProfile;
        $profile->fill($request->validated())->save();

        return ApiResponse::success($profile->refresh(), 'Provider profile updated.');
    }
}
