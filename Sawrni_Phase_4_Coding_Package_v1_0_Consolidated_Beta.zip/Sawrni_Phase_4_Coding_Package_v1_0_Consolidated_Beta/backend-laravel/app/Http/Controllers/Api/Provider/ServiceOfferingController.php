<?php

namespace App\Http\Controllers\Api\Provider;

use App\Http\Controllers\Controller;
use App\Http\Requests\Provider\SaveServiceOfferingRequest;
use App\Models\ServiceOffering;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class ServiceOfferingController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(
            auth()->user()->providerProfile->services()->with('serviceCategory')->latest()->paginate(20)
        );
    }

    public function store(SaveServiceOfferingRequest $request): JsonResponse
    {
        $service = auth()->user()->providerProfile->services()->create($request->validated());
        return ApiResponse::success($service->load('serviceCategory'), 'Service offering created.', 201);
    }

    public function update(SaveServiceOfferingRequest $request, ServiceOffering $serviceOffering): JsonResponse
    {
        abort_unless($serviceOffering->provider_profile_id === auth()->user()->providerProfile->id, 403);
        $serviceOffering->update($request->validated());
        return ApiResponse::success($serviceOffering->refresh()->load('serviceCategory'), 'Service offering updated.');
    }

    public function destroy(ServiceOffering $serviceOffering): JsonResponse
    {
        abort_unless($serviceOffering->provider_profile_id === auth()->user()->providerProfile->id, 403);
        $serviceOffering->update(['is_active' => false]);
        return ApiResponse::success(null, 'Service offering disabled.');
    }
}
