<?php

namespace App\Http\Controllers\Api\Provider;

use App\Http\Controllers\Controller;
use App\Services\WalletService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    public function __construct(private WalletService $walletService) {}

    public function show(Request $request)
    {
        $provider = $request->user()->providerProfile;
        abort_unless($provider, 403);

        $wallet = $this->walletService->ensureWallet($provider);

        return ApiResponse::success([
            'wallet' => $wallet,
            'transactions' => $wallet->transactions()->latest()->paginate(30),
            'debt_threshold_iqd' => config('sawrni.debt_threshold_iqd'),
        ]);
    }
}
