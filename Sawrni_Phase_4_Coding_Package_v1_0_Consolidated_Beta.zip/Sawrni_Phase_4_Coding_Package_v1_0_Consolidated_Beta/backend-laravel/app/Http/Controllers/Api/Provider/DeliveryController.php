<?php

namespace App\Http\Controllers\Api\Provider;

use App\Http\Controllers\Controller;
use App\Http\Requests\Provider\UploadDeliveryFileRequest;
use App\Models\Booking;
use App\Services\NotificationService;
use App\Services\UploadService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class DeliveryController extends Controller
{
    public function __construct(private UploadService $uploads, private NotificationService $notifications) {}

    public function upload(UploadDeliveryFileRequest $request, Booking $booking): JsonResponse
    {
        abort_unless($booking->provider_profile_id === auth()->user()->providerProfile->id, 403);
        abort_unless(in_array($booking->status, ['finished', 'delivery_pending', 'delivery_rejected'], true), 422, 'Delivery can only be uploaded after session finish.');

        $fileData = $this->uploads->storeDeliveryFile($request->file('file'), $booking->id);

        $delivery = $booking->deliveryFiles()->create([
            'uploaded_by' => auth()->id(),
            'label' => $request->input('label'),
            'notes' => $request->input('notes'),
            'disk' => $fileData['disk'],
            'path' => $fileData['path'],
            'original_name' => $fileData['original_name'],
            'mime_type' => $fileData['mime_type'],
            'size_bytes' => $fileData['size_bytes'],
            'status' => 'pending_approval',
        ]);

        $booking->update(['status' => 'delivery_pending']);
        $this->notifications->bookingStatusChanged($booking, 'finished', 'delivery_pending');

        return ApiResponse::success($delivery, 'Delivery file uploaded for approval.', 201);
    }
}
