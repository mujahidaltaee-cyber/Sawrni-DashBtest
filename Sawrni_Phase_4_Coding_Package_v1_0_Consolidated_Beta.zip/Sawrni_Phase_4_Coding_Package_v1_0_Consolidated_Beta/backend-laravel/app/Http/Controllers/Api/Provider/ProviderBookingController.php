<?php

namespace App\Http\Controllers\Api\Provider;

use App\Enums\BookingAction;
use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Services\BookingWorkflowService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProviderBookingController extends Controller
{
    public function __construct(private BookingWorkflowService $workflow) {}

    public function index(): JsonResponse
    {
        $profileId = auth()->user()->providerProfile->id;
        $bookings = Booking::query()
            ->where('provider_profile_id', $profileId)
            ->with(['customer', 'serviceOffering'])
            ->latest()
            ->paginate(20);

        return ApiResponse::success($bookings);
    }

    public function show(Booking $booking): JsonResponse
    {
        abort_unless($booking->provider_profile_id === auth()->user()->providerProfile->id, 403);
        return ApiResponse::success($booking->load(['customer', 'serviceOffering', 'payments', 'deliveryFiles', 'statusHistory']));
    }

    public function action(Request $request, Booking $booking, string $action): JsonResponse
    {
        abort_unless($booking->provider_profile_id === auth()->user()->providerProfile->id, 403);

        $request->validate(['note' => ['nullable', 'string', 'max:1000']]);
        $enum = BookingAction::from($action);

        $booking = $this->workflow->providerAction($booking, $enum, auth()->user(), $request->input('note'));

        return ApiResponse::success($booking, 'Booking updated.');
    }
}
