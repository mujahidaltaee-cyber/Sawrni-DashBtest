<?php

namespace App\Http\Controllers\Api\Provider;

use App\Http\Controllers\Controller;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PortfolioController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(auth()->user()->providerProfile->portfolioItems()->latest()->paginate(30));
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'file_url' => ['required', 'string', 'max:2000'],
            'type' => ['required', 'string', 'in:image,video'],
            'sort_order' => ['sometimes', 'integer', 'min:0'],
        ]);

        $item = auth()->user()->providerProfile->portfolioItems()->create($data);

        return ApiResponse::success($item, 'Portfolio item created.', 201);
    }
}
