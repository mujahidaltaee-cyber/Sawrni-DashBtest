<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\ChatMessage;
use App\Models\ChatThread;
use App\Services\ChatGateService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function __construct(private ChatGateService $gate) {}

    public function messages(Request $request, Booking $booking)
    {
        abort_unless($this->gate->canAccessBookingChat($request->user(), $booking), 403);

        $thread = ChatThread::firstOrCreate(['booking_id' => $booking->id]);

        return ApiResponse::success([
            'thread' => $thread,
            'messages' => ChatMessage::where('chat_thread_id', $thread->id)->latest()->paginate(30),
        ]);
    }

    public function send(Request $request, Booking $booking)
    {
        abort_unless($this->gate->canAccessBookingChat($request->user(), $booking), 403);

        $data = $request->validate(['message' => ['required', 'string', 'max:2000']]);
        $thread = ChatThread::firstOrCreate(['booking_id' => $booking->id]);

        $message = ChatMessage::create([
            'chat_thread_id' => $thread->id,
            'sender_id' => $request->user()->id,
            'body' => $data['message'],
        ]);

        return ApiResponse::success($message, 'Message sent.');
    }
}
