<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterCustomerRequest;
use App\Http\Requests\Auth\RegisterProviderRequest;
use App\Services\AuthService;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function __construct(private AuthService $authService) {}

    public function registerCustomer(RegisterCustomerRequest $request)
    {
        return ApiResponse::success($this->authService->registerCustomer($request->validated()), 'Customer registered.');
    }

    public function registerProvider(RegisterProviderRequest $request)
    {
        return ApiResponse::success($this->authService->registerProvider($request->validated()), 'Provider registered and pending approval.');
    }

    public function login(LoginRequest $request)
    {
        return ApiResponse::success($this->authService->login($request->validated()), 'Logged in.');
    }

    public function me(Request $request)
    {
        return ApiResponse::success(['user' => $request->user()->load(['customerProfile', 'providerProfile', 'adminProfile'])]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();
        return ApiResponse::success(null, 'Logged out.');
    }
}
