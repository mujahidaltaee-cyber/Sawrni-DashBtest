<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Shared\RegisterDeviceTokenRequest;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;

class NotificationController extends Controller
{
    public function index(): JsonResponse
    {
        return ApiResponse::success(
            auth()->user()->notifications()->latest()->paginate(30)
        );
    }

    public function markRead(int $id): JsonResponse
    {
        $notification = auth()->user()->notifications()->findOrFail($id);
        $notification->update(['read_at' => now()]);
        return ApiResponse::success($notification, 'Notification marked as read.');
    }

    public function registerDevice(RegisterDeviceTokenRequest $request): JsonResponse
    {
        $token = auth()->user()->deviceTokens()->updateOrCreate(
            ['token' => $request->validated('token')],
            [
                'platform' => $request->validated('platform'),
                'device_name' => $request->validated('device_name'),
                'last_seen_at' => now(),
            ]
        );

        return ApiResponse::success($token, 'Device token registered.');
    }
}
