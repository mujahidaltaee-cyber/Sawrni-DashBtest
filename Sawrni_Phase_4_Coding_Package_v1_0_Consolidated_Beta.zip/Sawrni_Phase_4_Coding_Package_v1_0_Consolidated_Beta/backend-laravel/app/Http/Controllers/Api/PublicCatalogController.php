<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ServiceCategory;
use App\Models\ProviderProfile;
use App\Support\ApiResponse;

class PublicCatalogController extends Controller
{
    public function categories()
    {
        return ApiResponse::success(ServiceCategory::where('is_active', true)->orderBy('sort_order')->get());
    }

    public function modelsGrid()
    {
        $models = ProviderProfile::with('user')
            ->where('provider_type', 'model')
            ->where('approval_status', 'approved')
            ->where('is_public', true)
            ->latest()
            ->paginate(60);

        return ApiResponse::success($models);
    }

    public function providers()
    {
        $providers = ProviderProfile::with(['user', 'services.category'])
            ->where('approval_status', 'approved')
            ->where('is_public', true)
            ->where('is_suspended', false)
            ->paginate(20);

        return ApiResponse::success($providers);
    }

    public function providerProfile(ProviderProfile $provider)
    {
        abort_unless($provider->is_public && $provider->approval_status === 'approved', 404);

        return ApiResponse::success($provider->load(['user', 'services.category', 'subscriptions']));
    }
}
