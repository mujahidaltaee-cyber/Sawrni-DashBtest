<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class LocalBetaStatusController extends Controller
{
    public function __invoke(): JsonResponse
    {
        return response()->json([
            'phase' => 'Phase 4 v0.7',
            'status' => 'local-beta-wiring',
            'platform_commission_percent' => (int) config('sawrni.platform_commission_percent', 15),
            'debt_suspension_threshold_iqd' => (int) config('sawrni.debt_suspension_threshold_iqd', 75000),
            'booking_edit_hours_after_deposit' => (int) config('sawrni.booking_edit_hours_after_deposit', 3),
            'booking_cancel_refund_hours_after_deposit' => (int) config('sawrni.booking_cancel_refund_hours_after_deposit', 1),
            'delivery_approval_rule' => 'management_approves_final_delivery_package_only',
        ]);
    }
}
