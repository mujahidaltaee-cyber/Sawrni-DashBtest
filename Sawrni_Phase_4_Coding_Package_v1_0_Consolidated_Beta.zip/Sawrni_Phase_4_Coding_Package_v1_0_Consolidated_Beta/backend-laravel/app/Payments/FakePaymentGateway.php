<?php

namespace App\Payments;

use App\Contracts\PaymentGatewayContract;

class FakePaymentGateway implements PaymentGatewayContract
{
    public function createIntent(int $amountIqd, string $reference, array $metadata = []): PaymentGatewayResult
    {
        return PaymentGatewayResult::success(
            status: 'pending',
            gatewayReference: 'fake_' . $reference,
            paymentUrl: config('app.url') . '/fake-payments/' . $reference,
            raw: ['amount_iqd' => $amountIqd, 'metadata' => $metadata]
        );
    }

    public function verifyWebhook(array $payload, ?string $signature): bool
    {
        if (app()->environment('local', 'testing')) {
            return ($signature ?? 'local') !== 'invalid';
        }

        return hash_equals((string) config('payment_gateways.fake.webhook_secret'), (string) $signature);
    }

    public function parseWebhook(array $payload): PaymentGatewayResult
    {
        return PaymentGatewayResult::success(
            status: $payload['status'] ?? 'paid',
            gatewayReference: $payload['gateway_reference'] ?? $payload['reference'] ?? null,
            raw: $payload
        );
    }

    public function refund(string $gatewayReference, int $amountIqd, string $reason): PaymentGatewayResult
    {
        return PaymentGatewayResult::success('refunded', $gatewayReference, raw: [
            'amount_iqd' => $amountIqd,
            'reason' => $reason,
        ]);
    }
}
