<?php

namespace App\Payments;

use App\Contracts\PaymentGatewayContract;
use Illuminate\Support\Facades\Http;

class ZainCashPaymentGateway implements PaymentGatewayContract
{
    public function createIntent(int $amountIqd, string $reference, array $metadata = []): PaymentGatewayResult
    {
        // Production implementation must be completed after receiving merchant credentials.
        // Keep this adapter isolated so booking, wallet, and receipt logic do not change.
        $payload = [
            'amount' => $amountIqd,
            'currency' => 'IQD',
            'reference' => $reference,
            'metadata' => $metadata,
            'callback_url' => route('payments.webhook', ['gateway' => 'zaincash']),
        ];

        if (config('payment_gateways.zaincash.stub_mode')) {
            return PaymentGatewayResult::success('pending', 'zc_stub_' . $reference, null, $payload);
        }

        $response = Http::withToken((string) config('payment_gateways.zaincash.api_token'))
            ->post((string) config('payment_gateways.zaincash.intent_url'), $payload);

        if (! $response->successful()) {
            return PaymentGatewayResult::failure('failed', 'Payment provider rejected the intent.', $response->json() ?? []);
        }

        $data = $response->json();

        return PaymentGatewayResult::success(
            status: $data['status'] ?? 'pending',
            gatewayReference: $data['id'] ?? $data['reference'] ?? null,
            paymentUrl: $data['payment_url'] ?? null,
            raw: $data
        );
    }

    public function verifyWebhook(array $payload, ?string $signature): bool
    {
        $secret = (string) config('payment_gateways.zaincash.webhook_secret');
        $expected = hash_hmac('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE), $secret);

        return $signature !== null && hash_equals($expected, $signature);
    }

    public function parseWebhook(array $payload): PaymentGatewayResult
    {
        return PaymentGatewayResult::success(
            status: $payload['status'] ?? 'unknown',
            gatewayReference: $payload['id'] ?? $payload['reference'] ?? null,
            raw: $payload
        );
    }

    public function refund(string $gatewayReference, int $amountIqd, string $reason): PaymentGatewayResult
    {
        if (config('payment_gateways.zaincash.stub_mode')) {
            return PaymentGatewayResult::success('refund_requested', $gatewayReference, raw: compact('amountIqd', 'reason'));
        }

        $response = Http::withToken((string) config('payment_gateways.zaincash.api_token'))
            ->post((string) config('payment_gateways.zaincash.refund_url'), [
                'reference' => $gatewayReference,
                'amount' => $amountIqd,
                'reason' => $reason,
            ]);

        if (! $response->successful()) {
            return PaymentGatewayResult::failure('refund_failed', 'Refund request failed.', $response->json() ?? []);
        }

        return PaymentGatewayResult::success('refund_requested', $gatewayReference, raw: $response->json() ?? []);
    }
}
