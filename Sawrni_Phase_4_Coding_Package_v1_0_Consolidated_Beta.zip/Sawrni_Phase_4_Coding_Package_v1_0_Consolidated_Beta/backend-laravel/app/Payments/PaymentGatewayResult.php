<?php

namespace App\Payments;

final class PaymentGatewayResult
{
    public function __construct(
        public readonly bool $successful,
        public readonly string $status,
        public readonly ?string $gatewayReference = null,
        public readonly ?string $paymentUrl = null,
        public readonly ?string $message = null,
        public readonly array $raw = []
    ) {}

    public static function success(string $status, ?string $gatewayReference = null, ?string $paymentUrl = null, array $raw = []): self
    {
        return new self(true, $status, $gatewayReference, $paymentUrl, null, $raw);
    }

    public static function failure(string $status, string $message, array $raw = []): self
    {
        return new self(false, $status, null, null, $message, $raw);
    }
}
