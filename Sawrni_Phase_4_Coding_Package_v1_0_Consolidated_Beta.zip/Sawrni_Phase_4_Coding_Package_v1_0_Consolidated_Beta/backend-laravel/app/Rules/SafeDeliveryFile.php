<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Http\UploadedFile;

class SafeDeliveryFile implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (! $value instanceof UploadedFile) {
            $fail('The :attribute must be a valid file.');
            return;
        }

        $extension = strtolower((string) $value->getClientOriginalExtension());
        $allowed = ['jpg', 'jpeg', 'png', 'webp', 'zip', 'pdf', 'mp4', 'mov'];

        if (! in_array($extension, $allowed, true)) {
            $fail('The :attribute type is not allowed.');
        }
    }
}
