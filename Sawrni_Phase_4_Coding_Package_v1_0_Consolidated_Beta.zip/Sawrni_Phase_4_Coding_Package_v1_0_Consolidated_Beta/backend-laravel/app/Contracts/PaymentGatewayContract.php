<?php

namespace App\Contracts;

use App\Payments\PaymentGatewayResult;

interface PaymentGatewayContract
{
    public function createIntent(int $amountIqd, string $reference, array $metadata = []): PaymentGatewayResult;

    public function verifyWebhook(array $payload, ?string $signature): bool;

    public function parseWebhook(array $payload): PaymentGatewayResult;

    public function refund(string $gatewayReference, int $amountIqd, string $reason): PaymentGatewayResult;
}
