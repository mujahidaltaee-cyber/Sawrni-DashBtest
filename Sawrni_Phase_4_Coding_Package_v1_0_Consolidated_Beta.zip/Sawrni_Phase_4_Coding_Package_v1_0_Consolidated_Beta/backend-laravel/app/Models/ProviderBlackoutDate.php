<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProviderBlackoutDate extends Model
{
    protected $fillable = ['provider_profile_id', 'date', 'reason'];
    protected $casts = ['date' => 'date'];

    public function providerProfile(): BelongsTo
    {
        return $this->belongsTo(ProviderProfile::class);
    }
}
