<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ServiceCategory extends Model
{
    protected $fillable = ['name_ar', 'name_en', 'slug', 'type', 'is_active', 'sort_order'];

    protected $casts = ['is_active' => 'boolean'];

    public function offerings(): HasMany
    {
        return $this->hasMany(ServiceOffering::class);
    }
}
