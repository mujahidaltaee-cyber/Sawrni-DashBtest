<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProviderAvailabilityWindow extends Model
{
    protected $fillable = [
        'provider_profile_id', 'weekday', 'starts_at', 'ends_at', 'is_active',
    ];

    protected $casts = ['is_active' => 'boolean'];

    public function providerProfile(): BelongsTo
    {
        return $this->belongsTo(ProviderProfile::class);
    }
}
