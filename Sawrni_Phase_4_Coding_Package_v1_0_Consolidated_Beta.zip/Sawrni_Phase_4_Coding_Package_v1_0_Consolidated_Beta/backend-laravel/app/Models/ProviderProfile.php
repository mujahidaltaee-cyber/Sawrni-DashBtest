<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ProviderProfile extends Model
{
    protected $fillable = [
        'user_id', 'provider_type', 'display_name', 'bio', 'bio_ar', 'bio_en', 'approval_status',
        'approved_by', 'approved_at', 'city', 'service_radius_km', 'service_area_mode', 'is_general_area',
        'is_public', 'is_suspended', 'suspension_reason'
    ];

    protected $casts = [
        'approved_at' => 'datetime',
        'is_public' => 'boolean',
        'is_suspended' => 'boolean',
        'is_general_area' => 'boolean',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function services(): HasMany { return $this->hasMany(ServiceOffering::class); }
    public function portfolioItems(): HasMany { return $this->hasMany(PortfolioItem::class); }
    public function bookings(): HasMany { return $this->hasMany(Booking::class); }
    public function wallet(): HasOne { return $this->hasOne(Wallet::class); }
    public function subscriptions(): HasMany { return $this->hasMany(ProviderSubscription::class); }
    public function subscription(): HasOne { return $this->hasOne(ProviderSubscription::class)->latestOfMany(); }
    public function availabilityWindows(): HasMany { return $this->hasMany(ProviderAvailabilityWindow::class); }
    public function blackoutDates(): HasMany { return $this->hasMany(ProviderBlackoutDate::class); }
}
