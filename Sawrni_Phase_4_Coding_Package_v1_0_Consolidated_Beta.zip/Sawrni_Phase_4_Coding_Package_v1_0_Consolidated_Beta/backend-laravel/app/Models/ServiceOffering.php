<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServiceOffering extends Model
{
    protected $fillable = [
        'provider_profile_id', 'service_category_id', 'title_ar', 'title_en',
        'description_ar', 'description_en', 'price_iqd', 'deposit_iqd',
        'duration_minutes', 'delivery_days', 'is_active'
    ];

    protected $casts = ['is_active' => 'boolean'];

    public function provider(): BelongsTo
    {
        return $this->belongsTo(ProviderProfile::class, 'provider_profile_id');
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(ServiceCategory::class, 'service_category_id');
    }
}
