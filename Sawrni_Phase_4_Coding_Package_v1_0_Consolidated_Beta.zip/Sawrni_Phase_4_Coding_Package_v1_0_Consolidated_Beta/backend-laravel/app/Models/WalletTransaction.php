<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WalletTransaction extends Model
{
    protected $fillable = [
        'wallet_id', 'booking_id', 'payment_id', 'type', 'amount_iqd', 'direction', 'description'
    ];
}
