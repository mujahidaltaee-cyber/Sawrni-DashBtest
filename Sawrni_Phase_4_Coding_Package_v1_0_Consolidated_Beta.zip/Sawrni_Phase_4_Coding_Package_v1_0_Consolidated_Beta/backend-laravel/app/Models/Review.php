<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    protected $fillable = [
        'booking_id', 'customer_id', 'provider_profile_id', 'rating', 'comment', 'status', 'approved_by', 'approved_at'
    ];

    protected $casts = ['approved_at' => 'datetime'];
}
