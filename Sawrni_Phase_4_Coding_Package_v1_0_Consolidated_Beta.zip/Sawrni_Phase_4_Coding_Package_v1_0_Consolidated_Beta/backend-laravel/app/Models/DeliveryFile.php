<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryFile extends Model
{
    protected $fillable = [
        'booking_id', 'provider_profile_id', 'file_path', 'file_name', 'mime_type', 'size_bytes',
        'status', 'approved_by', 'approved_at', 'rejection_reason'
    ];

    protected $casts = ['approved_at' => 'datetime'];
}
