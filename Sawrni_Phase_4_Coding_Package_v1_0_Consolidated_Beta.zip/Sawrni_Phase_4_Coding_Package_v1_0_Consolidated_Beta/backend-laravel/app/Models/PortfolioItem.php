<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PortfolioItem extends Model
{
    protected $fillable = [
        'provider_profile_id', 'file_path', 'thumbnail_path', 'caption_ar', 'caption_en', 'is_public', 'sort_order'
    ];

    protected $casts = ['is_public' => 'boolean'];
}
