<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    protected $fillable = [
        'booking_id', 'payer_id', 'provider_profile_id', 'type', 'method', 'status',
        'amount_iqd', 'commission_iqd', 'provider_share_iqd', 'transaction_reference', 'paid_at'
    ];

    protected $casts = ['paid_at' => 'datetime'];

    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }
}
