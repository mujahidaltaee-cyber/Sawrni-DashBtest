<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Booking extends Model
{
    protected $fillable = [
        'customer_id', 'provider_profile_id', 'service_offering_id', 'status',
        'scheduled_at', 'duration_minutes', 'location_address', 'latitude', 'longitude',
        'customer_notes', 'total_price_iqd', 'deposit_iqd', 'deposit_paid_at',
        'provider_accepted_at', 'provider_rejected_at', 'started_at', 'finished_at', 'completed_at',
        'cancelled_at', 'cancelled_by', 'cancellation_reason', 'refund_eligible'
    ];

    protected $casts = [
        'scheduled_at' => 'datetime',
        'deposit_paid_at' => 'datetime',
        'provider_accepted_at' => 'datetime',
        'provider_rejected_at' => 'datetime',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'refund_eligible' => 'boolean',
    ];

    public function customer(): BelongsTo { return $this->belongsTo(User::class, 'customer_id'); }
    public function providerProfile(): BelongsTo { return $this->belongsTo(ProviderProfile::class); }
    public function provider(): BelongsTo { return $this->belongsTo(ProviderProfile::class, 'provider_profile_id'); }
    public function serviceOffering(): BelongsTo { return $this->belongsTo(ServiceOffering::class); }
    public function payments(): HasMany { return $this->hasMany(Payment::class); }
    public function walletTransactions(): HasMany { return $this->hasMany(WalletTransaction::class); }
    public function deliveryFiles(): HasMany { return $this->hasMany(DeliveryFile::class); }
    public function chatThread(): HasOne { return $this->hasOne(ChatThread::class); }
    public function statusHistory(): HasMany { return $this->hasMany(BookingStatusHistory::class); }
}
