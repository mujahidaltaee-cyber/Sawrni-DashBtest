<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationLog extends Model
{
    protected $fillable = ['user_id', 'title_ar', 'title_en', 'body_ar', 'body_en', 'type', 'payload', 'read_at'];

    protected $casts = ['payload' => 'array', 'read_at' => 'datetime'];
}
