<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ChatThread extends Model
{
    protected $fillable = ['booking_id', 'customer_id', 'provider_user_id', 'is_locked'];

    protected $casts = ['is_locked' => 'boolean'];

    public function messages(): HasMany
    {
        return $this->hasMany(ChatMessage::class);
    }
}
