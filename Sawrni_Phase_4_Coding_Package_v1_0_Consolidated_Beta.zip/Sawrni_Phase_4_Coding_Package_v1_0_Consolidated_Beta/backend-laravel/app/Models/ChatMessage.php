<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    protected $fillable = ['chat_thread_id', 'sender_id', 'body', 'attachment_path', 'read_at'];

    protected $casts = ['read_at' => 'datetime'];
}
