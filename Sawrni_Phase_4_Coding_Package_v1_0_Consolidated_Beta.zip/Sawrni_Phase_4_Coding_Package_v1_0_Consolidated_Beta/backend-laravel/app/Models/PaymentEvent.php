<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentEvent extends Model
{
    protected $fillable = [
        'payment_id',
        'event_type',
        'payload',
        'created_by',
    ];

    protected $casts = ['payload' => 'array'];
}
