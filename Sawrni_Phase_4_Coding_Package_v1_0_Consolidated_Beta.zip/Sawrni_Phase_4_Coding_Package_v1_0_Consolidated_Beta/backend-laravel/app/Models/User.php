<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = [
        'name', 'phone', 'email', 'password', 'role', 'is_active', 'preferred_language'
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'is_active' => 'boolean',
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function customerProfile(): HasOne { return $this->hasOne(CustomerProfile::class); }
    public function providerProfile(): HasOne { return $this->hasOne(ProviderProfile::class); }
    public function adminProfile(): HasOne { return $this->hasOne(AdminProfile::class); }
    public function notifications(): HasMany { return $this->hasMany(NotificationLog::class); }
    public function deviceTokens(): HasMany { return $this->hasMany(DeviceToken::class); }
    public function adminPermissions(): HasMany { return $this->hasMany(AdminPermissionModel::class, 'admin_user_id'); }
}
