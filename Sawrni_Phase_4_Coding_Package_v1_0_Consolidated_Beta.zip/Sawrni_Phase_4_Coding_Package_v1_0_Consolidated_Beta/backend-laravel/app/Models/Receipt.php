<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Receipt extends Model
{
    protected $fillable = [
        'receipt_number',
        'booking_id',
        'payment_id',
        'customer_id',
        'provider_profile_id',
        'total_price_iqd',
        'deposit_iqd',
        'platform_commission_iqd',
        'provider_share_iqd',
        'payment_method',
        'issued_at',
        'metadata',
    ];

    protected $casts = [
        'issued_at' => 'datetime',
        'metadata' => 'array',
    ];
}
