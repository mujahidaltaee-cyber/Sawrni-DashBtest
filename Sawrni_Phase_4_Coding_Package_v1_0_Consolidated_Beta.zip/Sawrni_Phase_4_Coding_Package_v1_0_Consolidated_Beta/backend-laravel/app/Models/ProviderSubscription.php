<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderSubscription extends Model
{
    protected $fillable = [
        'provider_profile_id', 'plan', 'price_iqd', 'starts_at', 'ends_at', 'status', 'paid_at'
    ];

    protected $casts = ['starts_at' => 'datetime', 'ends_at' => 'datetime', 'paid_at' => 'datetime'];
}
