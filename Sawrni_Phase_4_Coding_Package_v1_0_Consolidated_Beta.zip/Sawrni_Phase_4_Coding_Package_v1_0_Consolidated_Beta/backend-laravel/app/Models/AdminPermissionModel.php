<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminPermissionModel extends Model
{
    protected $table = 'admin_permissions';

    protected $fillable = [
        'key',
        'name_en',
        'name_ar',
        'description',
    ];
}
