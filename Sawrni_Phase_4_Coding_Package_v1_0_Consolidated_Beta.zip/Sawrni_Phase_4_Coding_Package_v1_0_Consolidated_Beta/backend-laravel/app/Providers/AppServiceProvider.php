<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Application bindings should remain here unless they belong to a specific module provider.
    }

    public function boot(): void
    {
        // Production hardening such as URL forcing can be added during deployment.
    }
}
