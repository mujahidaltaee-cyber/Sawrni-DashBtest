<?php

namespace App\Providers;

use App\Contracts\PaymentGatewayContract;
use App\Payments\FakePaymentGateway;
use App\Payments\ZainCashPaymentGateway;
use Illuminate\Support\ServiceProvider;

class PaymentGatewayServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(PaymentGatewayContract::class, function () {
            return match (config('payment_gateways.default')) {
                'zaincash' => new ZainCashPaymentGateway(),
                default => new FakePaymentGateway(),
            };
        });
    }
}
