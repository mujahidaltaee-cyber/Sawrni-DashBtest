<?php

namespace App\Services;

class CommissionService
{
    public function calculate(int $totalAmountIqd): array
    {
        $rate = (float) config('sawrni.commission_rate', 15);
        $commission = (int) round($totalAmountIqd * ($rate / 100));
        $providerShare = $totalAmountIqd - $commission;

        return [
            'total_iqd' => $totalAmountIqd,
            'commission_rate' => $rate,
            'commission_iqd' => $commission,
            'provider_share_iqd' => $providerShare,
        ];
    }
}
