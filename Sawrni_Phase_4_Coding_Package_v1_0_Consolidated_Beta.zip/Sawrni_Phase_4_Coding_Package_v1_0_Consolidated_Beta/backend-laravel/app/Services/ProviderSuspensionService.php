<?php

namespace App\Services;

use App\Models\ProviderProfile;

class ProviderSuspensionService
{
    public function shouldSuspend(ProviderProfile $provider): bool
    {
        $wallet = $provider->wallet;
        if (!$wallet) {
            return false;
        }

        return abs(min(0, (int) $wallet->balance_iqd)) >= (int) config('sawrni.debt_threshold_iqd');
    }

    public function suspendIfDebtExceeded(ProviderProfile $provider): bool
    {
        if (!$this->shouldSuspend($provider)) {
            return false;
        }

        $provider->update([
            'is_suspended' => true,
            'is_public' => false,
            'suspension_reason' => 'Debt threshold exceeded.',
        ]);

        return true;
    }
}
