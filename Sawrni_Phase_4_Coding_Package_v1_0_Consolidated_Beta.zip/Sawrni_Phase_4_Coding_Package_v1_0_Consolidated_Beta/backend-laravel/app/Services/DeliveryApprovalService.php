<?php

namespace App\Services;

use App\Models\DeliveryFile;
use App\Enums\DeliveryStatus;
use Illuminate\Support\Carbon;

class DeliveryApprovalService
{
    public function approve(DeliveryFile $file, int $adminUserId): DeliveryFile
    {
        $file->status = DeliveryStatus::Approved->value;
        $file->approved_by = $adminUserId;
        $file->approved_at = Carbon::now();
        $file->save();

        return $file;
    }

    public function reject(DeliveryFile $file, string $reason): DeliveryFile
    {
        $file->status = DeliveryStatus::Rejected->value;
        $file->rejection_reason = $reason;
        $file->save();

        return $file;
    }
}
