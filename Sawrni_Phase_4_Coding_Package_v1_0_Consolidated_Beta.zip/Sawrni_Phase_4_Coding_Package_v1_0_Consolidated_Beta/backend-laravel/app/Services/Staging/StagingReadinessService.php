<?php

namespace App\Services\Staging;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

class StagingReadinessService
{
    public function report(): array
    {
        return [
            'environment' => app()->environment(),
            'app_url' => config('app.url'),
            'database' => $this->checkDatabase(),
            'cache' => $this->checkCache(),
            'storage' => $this->checkStorage(),
            'commission_rate' => config('sawrni.commission_rate', 15),
            'provider_debt_suspend_threshold' => config('sawrni.provider_debt_suspend_threshold', 75000),
            'booking_edit_hours' => config('sawrni.booking_edit_hours', 3),
            'booking_cancel_refund_hours' => config('sawrni.booking_cancel_refund_hours', 1),
        ];
    }

    private function checkDatabase(): array
    {
        try {
            DB::select('select 1');
            return ['ok' => true];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    private function checkCache(): array
    {
        try {
            Cache::put('sawrni_staging_check', 'ok', 30);
            return ['ok' => Cache::get('sawrni_staging_check') === 'ok'];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    private function checkStorage(): array
    {
        try {
            $path = 'staging-check/'.now()->format('YmdHis').'.txt';
            Storage::put($path, 'ok');
            $exists = Storage::exists($path);
            Storage::delete($path);
            return ['ok' => $exists];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }
}
