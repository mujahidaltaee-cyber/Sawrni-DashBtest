<?php

namespace App\Services;

use App\Models\DeliveryFile;
use Illuminate\Support\Facades\Storage;

class DeliveryWorkflowService
{
    public function approve(DeliveryFile $deliveryFile, int $adminUserId): DeliveryFile
    {
        $deliveryFile->status = 'approved';
        $deliveryFile->approved_by = $adminUserId;
        $deliveryFile->approved_at = now();
        $deliveryFile->save();

        return $deliveryFile;
    }

    public function reject(DeliveryFile $deliveryFile, int $adminUserId, ?string $reason = null): DeliveryFile
    {
        $deliveryFile->status = 'rejected';
        $deliveryFile->rejected_by = $adminUserId;
        $deliveryFile->rejected_at = now();
        $deliveryFile->rejection_reason = $reason;
        $deliveryFile->save();

        return $deliveryFile;
    }

    public function signedDownloadUrl(DeliveryFile $deliveryFile): string
    {
        return Storage::disk($deliveryFile->disk ?? config('filesystems.default'))
            ->temporaryUrl($deliveryFile->path, now()->addMinutes(30));
    }
}
