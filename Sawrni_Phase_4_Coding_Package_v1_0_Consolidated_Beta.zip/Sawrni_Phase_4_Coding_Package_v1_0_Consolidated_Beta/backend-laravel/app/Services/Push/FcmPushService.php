<?php

namespace App\Services\Push;

use App\Models\DeviceToken;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class FcmPushService
{
    public function send(DeviceToken $deviceToken, string $title, string $body, array $data = []): bool
    {
        // Production implementation should use Firebase service account OAuth token.
        // v0.4 keeps this safe: it logs when credentials are missing instead of failing the request.
        if (! config('sawrni.fcm.project_id') || ! config('sawrni.fcm.credentials_path')) {
            Log::info('FCM skipped: credentials not configured.', [
                'device_token_id' => $deviceToken->id,
                'title' => $title,
                'data' => $data,
            ]);
            return false;
        }

        // Placeholder for actual FCM v1 HTTP call after service-account token generation.
        return true;
    }
}
