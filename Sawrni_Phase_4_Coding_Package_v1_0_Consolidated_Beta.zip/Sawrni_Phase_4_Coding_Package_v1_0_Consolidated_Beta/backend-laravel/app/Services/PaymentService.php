<?php

namespace App\Services;

use App\Enums\BookingStatus;
use App\Enums\PaymentStatus;
use App\Models\Booking;
use App\Models\Payment;
use App\Models\PaymentEvent;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentService
{
    public function __construct(
        private CommissionService $commissionService,
        private WalletService $walletService,
        private ReceiptService $receiptService,
        private NotificationService $notificationService,
    ) {}

    public function confirmDeposit(Booking $booking, array $data, int $confirmedByUserId): array
    {
        if ($booking->deposit_paid_at) {
            throw ValidationException::withMessages(['booking' => ['Deposit is already paid.']]);
        }

        return DB::transaction(function () use ($booking, $data, $confirmedByUserId) {
            $payment = Payment::create([
                'booking_id' => $booking->id,
                'customer_id' => $booking->customer_id,
                'amount_iqd' => $booking->deposit_iqd,
                'method' => $data['payment_method'],
                'status' => PaymentStatus::Paid->value,
                'provider_reference' => $data['provider_reference'] ?? null,
                'paid_at' => now(),
            ]);

            PaymentEvent::create([
                'payment_id' => $payment->id,
                'event_type' => 'deposit_confirmed',
                'payload' => $data['gateway_payload'] ?? ['method' => $data['payment_method']],
                'created_by' => $confirmedByUserId,
            ]);

            $booking->update([
                'deposit_paid_at' => now(),
                'status' => BookingStatus::DepositPaid->value,
            ]);

            $commission = $this->commissionService->calculate($booking->total_price_iqd);
            $providerShare = max(0, $booking->total_price_iqd - $commission);

            $this->walletService->recordBookingFinancials($booking, $commission, $providerShare);
            $receipt = $this->receiptService->issueForDeposit($booking, $payment, $commission, $providerShare);

            $this->notificationService->send($booking->customer_id, 'deposit_paid', [
                'booking_id' => $booking->id,
                'receipt_number' => $receipt->receipt_number,
            ]);

            return [
                'payment' => $payment,
                'receipt' => $receipt,
                'commission_iqd' => $commission,
                'provider_share_iqd' => $providerShare,
            ];
        });
    }
}
