<?php

namespace App\Services;

use App\Enums\ProviderApprovalStatus;
use App\Enums\UserRole;
use App\Models\CustomerProfile;
use App\Models\ProviderProfile;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthService
{
    public function registerCustomer(array $data): array
    {
        return DB::transaction(function () use ($data) {
            $user = User::create([
                'full_name' => $data['full_name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? null,
                'password' => Hash::make($data['password']),
                'role' => UserRole::Customer->value,
                'language' => $data['language'] ?? 'ar',
            ]);

            CustomerProfile::create([
                'user_id' => $user->id,
                'city' => config('sawrni.default_city'),
            ]);

            return $this->tokenResponse($user, 'customer-mobile');
        });
    }

    public function registerProvider(array $data): array
    {
        return DB::transaction(function () use ($data) {
            $user = User::create([
                'full_name' => $data['full_name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? null,
                'password' => Hash::make($data['password']),
                'role' => UserRole::Provider->value,
                'language' => $data['language'] ?? 'ar',
            ]);

            ProviderProfile::create([
                'user_id' => $user->id,
                'provider_type' => $data['provider_type'],
                'display_name' => $data['display_name'],
                'bio' => $data['bio'] ?? null,
                'city' => $data['city'] ?? config('sawrni.default_city'),
                'service_area_mode' => $data['service_area_mode'] ?? 'general',
                'service_radius_km' => $data['service_radius_km'] ?? null,
                'approval_status' => ProviderApprovalStatus::Pending->value,
                'is_public' => false,
                'is_suspended' => false,
            ]);

            return $this->tokenResponse($user, 'provider-mobile');
        });
    }

    public function login(array $data): array
    {
        $user = User::where('phone', $data['phone'])->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages(['phone' => ['Invalid phone or password.']]);
        }

        return $this->tokenResponse($user, $data['device_name'] ?? 'sawrni-device');
    }

    public function tokenResponse(User $user, string $deviceName): array
    {
        return [
            'user' => $user,
            'token' => $user->createToken($deviceName)->plainTextToken,
        ];
    }
}
