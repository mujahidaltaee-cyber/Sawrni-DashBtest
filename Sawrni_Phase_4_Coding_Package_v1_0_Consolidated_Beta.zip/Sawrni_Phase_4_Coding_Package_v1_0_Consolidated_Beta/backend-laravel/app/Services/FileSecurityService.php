<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Validation\ValidationException;

class FileSecurityService
{
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'zip', 'pdf', 'mp4', 'mov'];

    private const ALLOWED_MIME_PREFIXES = ['image/', 'video/', 'application/pdf', 'application/zip', 'application/x-zip-compressed'];

    public function validateDeliveryFile(UploadedFile $file, int $maxMegabytes = 2048): void
    {
        $extension = strtolower((string) $file->getClientOriginalExtension());
        $mime = (string) $file->getMimeType();
        $sizeMb = $file->getSize() / 1024 / 1024;

        if (! in_array($extension, self::ALLOWED_EXTENSIONS, true)) {
            throw ValidationException::withMessages(['file' => 'Unsupported delivery file extension.']);
        }

        $allowedMime = collect(self::ALLOWED_MIME_PREFIXES)->contains(fn ($prefix) => str_starts_with($mime, $prefix));
        if (! $allowedMime) {
            throw ValidationException::withMessages(['file' => 'Unsupported delivery file type.']);
        }

        if ($sizeMb > $maxMegabytes) {
            throw ValidationException::withMessages(['file' => 'Delivery file exceeds the allowed size limit.']);
        }
    }

    public function safeStorageName(UploadedFile $file, string $prefix): string
    {
        return trim($prefix, '/') . '/' . now()->format('Y/m/d') . '/' . bin2hex(random_bytes(16)) . '.' . strtolower($file->getClientOriginalExtension());
    }
}
