<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\Payment;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class PaymentWorkflowService
{
    public function __construct(private WalletLedgerService $walletLedger) {}

    public function confirmDeposit(Booking $booking, array $data): Payment
    {
        if ((int) $data['amount_iqd'] < (int) $booking->deposit_amount_iqd) {
            throw new RuntimeException('Deposit amount is less than required.');
        }

        return DB::transaction(function () use ($booking, $data) {
            $payment = Payment::query()->create([
                'booking_id' => $booking->id,
                'customer_id' => $booking->customer_id,
                'provider_profile_id' => $booking->provider_profile_id,
                'method' => $data['method'],
                'status' => 'paid',
                'amount_iqd' => $data['amount_iqd'],
                'reference' => $data['payment_reference'],
                'gateway_payload' => $data['gateway_payload'] ?? [],
                'paid_at' => now(),
            ]);

            $booking->payment_status = 'deposit_paid';
            $booking->deposit_paid_at = now();
            $booking->status = 'confirmed';
            $booking->chat_unlocked_at = now();
            $booking->phone_visibility_unlocked_at = now();
            $booking->save();

            $this->walletLedger->postDeposit($booking, $payment);

            return $payment;
        });
    }
}
