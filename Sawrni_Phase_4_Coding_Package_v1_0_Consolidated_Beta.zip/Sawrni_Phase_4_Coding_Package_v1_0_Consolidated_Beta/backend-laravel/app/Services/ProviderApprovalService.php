<?php

namespace App\Services;

use App\Models\ProviderProfile;
use App\Models\Wallet;
use App\Enums\ProviderApprovalStatus;
use Illuminate\Support\Carbon;

class ProviderApprovalService
{
    public function approve(ProviderProfile $provider, int $adminUserId): ProviderProfile
    {
        $provider->approval_status = ProviderApprovalStatus::Approved->value;
        $provider->approved_by = $adminUserId;
        $provider->approved_at = Carbon::now();
        $provider->is_public = true;
        $provider->save();

        Wallet::firstOrCreate(['provider_profile_id' => $provider->id]);

        return $provider;
    }

    public function reject(ProviderProfile $provider, string $reason): ProviderProfile
    {
        $provider->approval_status = ProviderApprovalStatus::Rejected->value;
        $provider->is_public = false;
        $provider->suspension_reason = $reason;
        $provider->save();

        return $provider;
    }
}
