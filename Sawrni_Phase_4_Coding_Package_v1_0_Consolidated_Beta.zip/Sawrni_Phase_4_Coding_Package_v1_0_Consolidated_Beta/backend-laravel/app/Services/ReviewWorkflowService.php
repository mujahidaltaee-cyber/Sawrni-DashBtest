<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\Review;
use App\Models\User;
use RuntimeException;

class ReviewWorkflowService
{
    public function createCustomerReview(User $customer, Booking $booking, array $data): Review
    {
        if ((int) $booking->customer_id !== (int) $customer->id) {
            throw new RuntimeException('This booking does not belong to the customer.');
        }
        if ($booking->status !== 'completed') {
            throw new RuntimeException('Only completed bookings can be reviewed.');
        }

        return Review::query()->create([
            'booking_id' => $booking->id,
            'customer_id' => $customer->id,
            'provider_profile_id' => $booking->provider_profile_id,
            'rating' => $data['rating'],
            'comment' => $data['comment'] ?? null,
            'status' => 'pending_approval',
        ]);
    }
}
