<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\Payment;
use App\Models\Wallet;
use App\Models\WalletTransaction;

class WalletLedgerService
{
    public function postDeposit(Booking $booking, Payment $payment): void
    {
        $wallet = Wallet::query()->firstOrCreate(
            ['provider_profile_id' => $booking->provider_profile_id],
            ['balance_iqd' => 0, 'debt_iqd' => 0]
        );

        WalletTransaction::query()->create([
            'wallet_id' => $wallet->id,
            'booking_id' => $booking->id,
            'payment_id' => $payment->id,
            'type' => 'deposit_received',
            'amount_iqd' => $payment->amount_iqd,
            'description' => 'Deposit received for booking #' . $booking->id,
        ]);
    }

    public function postCompletedBooking(Booking $booking): void
    {
        $wallet = Wallet::query()->firstOrCreate(
            ['provider_profile_id' => $booking->provider_profile_id],
            ['balance_iqd' => 0, 'debt_iqd' => 0]
        );

        $commission = (int) round($booking->total_price_iqd * 0.15);
        $providerEarning = (int) $booking->total_price_iqd - $commission;

        $wallet->balance_iqd += $providerEarning;
        $wallet->debt_iqd += $commission;
        $wallet->save();

        WalletTransaction::query()->create([
            'wallet_id' => $wallet->id,
            'booking_id' => $booking->id,
            'type' => 'provider_earning',
            'amount_iqd' => $providerEarning,
            'description' => 'Provider earning for completed booking #' . $booking->id,
        ]);

        WalletTransaction::query()->create([
            'wallet_id' => $wallet->id,
            'booking_id' => $booking->id,
            'type' => 'platform_commission_debt',
            'amount_iqd' => $commission,
            'description' => '15% platform commission for booking #' . $booking->id,
        ]);
    }

    public function recordProviderPayment(Wallet $wallet, int $amountIqd, ?string $note = null): void
    {
        $wallet->debt_iqd = max(0, (int) $wallet->debt_iqd - $amountIqd);
        $wallet->save();

        WalletTransaction::query()->create([
            'wallet_id' => $wallet->id,
            'type' => 'provider_debt_payment',
            'amount_iqd' => $amountIqd,
            'description' => $note ?: 'Provider payment against outstanding platform debt.',
        ]);
    }
}
