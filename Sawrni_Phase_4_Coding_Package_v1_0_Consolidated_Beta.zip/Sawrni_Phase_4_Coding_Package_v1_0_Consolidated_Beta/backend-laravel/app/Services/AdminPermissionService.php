<?php

namespace App\Services;

use App\Enums\UserRole;
use App\Models\AdminPermissionModel;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class AdminPermissionService
{
    public function userHas(User $user, string $permission): bool
    {
        if ($user->role === UserRole::SuperAdmin->value) {
            return true;
        }

        if (!in_array($user->role, [UserRole::Admin->value, UserRole::SuperAdmin->value], true)) {
            return false;
        }

        return DB::table('admin_permission_user')
            ->join('admin_permissions', 'admin_permissions.id', '=', 'admin_permission_user.admin_permission_id')
            ->where('admin_permission_user.user_id', $user->id)
            ->where('admin_permissions.key', $permission)
            ->exists();
    }

    public function syncPermissions(User $targetAdmin, array $permissionKeys, User $grantedBy): void
    {
        $permissionIds = AdminPermissionModel::whereIn('key', $permissionKeys)->pluck('id')->all();

        DB::transaction(function () use ($targetAdmin, $permissionIds, $grantedBy) {
            DB::table('admin_permission_user')->where('user_id', $targetAdmin->id)->delete();

            foreach ($permissionIds as $permissionId) {
                DB::table('admin_permission_user')->insert([
                    'user_id' => $targetAdmin->id,
                    'admin_permission_id' => $permissionId,
                    'granted_by' => $grantedBy->id,
                    'granted_at' => now(),
                ]);
            }
        });
    }
}
