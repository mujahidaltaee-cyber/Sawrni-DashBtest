<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\DeliveryFile;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DeliveryPackageService
{
    public function approve(DeliveryFile $deliveryFile, User $admin): DeliveryFile
    {
        return DB::transaction(function () use ($deliveryFile, $admin) {
            $deliveryFile->forceFill([
                'status' => 'approved',
                'approved_by' => $admin->id,
                'approved_at' => now(),
            ])->save();

            return $deliveryFile->refresh();
        });
    }

    public function reject(DeliveryFile $deliveryFile, User $admin, string $reason): DeliveryFile
    {
        return DB::transaction(function () use ($deliveryFile, $admin, $reason) {
            $deliveryFile->forceFill([
                'status' => 'rejected',
                'rejected_by' => $admin->id,
                'rejected_at' => now(),
                'rejection_reason' => $reason,
            ])->save();

            return $deliveryFile->refresh();
        });
    }

    public function assertBookingAllowsDeliveryUpload(Booking $booking, int $providerProfileId): void
    {
        abort_unless((int) $booking->provider_profile_id === $providerProfileId, 403, 'Provider does not own this booking.');
        abort_unless(in_array($booking->status, ['finished', 'completed', 'delivery_pending'], true), 422, 'Booking is not ready for delivery upload.');
        abort_unless($booking->deposit_paid_at !== null, 422, 'Deposit payment is required before delivery upload.');
    }
}
