<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Models\ServiceOffering;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class BookingWorkflowService
{
    public function __construct(private AvailabilityService $availability) {}

    public function createCustomerBooking(User $customer, array $data): Booking
    {
        $provider = ProviderProfile::query()->findOrFail($data['provider_profile_id']);
        if ($provider->approval_status !== 'approved' || !$provider->is_public) {
            throw new RuntimeException('Provider is not available for booking.');
        }

        $service = ServiceOffering::query()->findOrFail($data['service_offering_id']);
        if ((int) $service->provider_profile_id !== (int) $provider->id) {
            throw new RuntimeException('Service does not belong to selected provider.');
        }

        $scheduledAt = Carbon::parse($data['scheduled_at']);
        if ($this->availability->providerHasConflict($provider->id, $scheduledAt, (int) $data['duration_minutes'])) {
            throw new RuntimeException('Provider already has a booking at this time.');
        }

        return DB::transaction(function () use ($customer, $provider, $service, $data, $scheduledAt) {
            return Booking::query()->create([
                'customer_id' => $customer->id,
                'provider_profile_id' => $provider->id,
                'service_offering_id' => $service->id,
                'status' => 'pending_provider_acceptance',
                'scheduled_at' => $scheduledAt,
                'duration_minutes' => $data['duration_minutes'],
                'location_lat' => $data['location_lat'],
                'location_lng' => $data['location_lng'],
                'location_address' => $data['location_address'],
                'notes' => $data['notes'] ?? null,
                'total_price_iqd' => $data['total_price_iqd'],
                'deposit_amount_iqd' => $data['deposit_amount_iqd'],
                'platform_commission_iqd' => round($data['total_price_iqd'] * 0.15),
                'provider_earning_iqd' => $data['total_price_iqd'] - round($data['total_price_iqd'] * 0.15),
                'payment_status' => 'deposit_pending',
            ]);
        });
    }

    public function updateCustomerBooking(Booking $booking, array $data): Booking
    {
        if (!$booking->deposit_paid_at) {
            throw new RuntimeException('Booking cannot be edited before deposit payment.');
        }
        if ($booking->deposit_paid_at->copy()->addHours(3)->isPast()) {
            throw new RuntimeException('Booking edit window has expired.');
        }

        $scheduledAt = isset($data['scheduled_at']) ? Carbon::parse($data['scheduled_at']) : $booking->scheduled_at;
        $duration = (int) ($data['duration_minutes'] ?? $booking->duration_minutes);

        if ($this->availability->providerHasConflict($booking->provider_profile_id, $scheduledAt, $duration, $booking->id)) {
            throw new RuntimeException('Provider already has a booking at this time.');
        }

        $booking->fill($data);
        $booking->scheduled_at = $scheduledAt;
        $booking->save();

        return $booking;
    }

    public function cancelByCustomer(Booking $booking): Booking
    {
        if (!$booking->deposit_paid_at) {
            $booking->status = 'cancelled';
            $booking->save();
            return $booking;
        }

        $booking->status = 'cancelled';
        $booking->deposit_refundable = $booking->deposit_paid_at->copy()->addHour()->isFuture();
        $booking->cancelled_at = now();
        $booking->save();

        return $booking;
    }
}
