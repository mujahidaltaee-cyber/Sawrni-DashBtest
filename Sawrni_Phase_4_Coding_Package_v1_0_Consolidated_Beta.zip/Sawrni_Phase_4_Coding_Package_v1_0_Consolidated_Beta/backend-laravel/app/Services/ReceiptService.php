<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\Payment;
use App\Models\Receipt;

class ReceiptService
{
    public function issueForDeposit(Booking $booking, Payment $payment, int $commissionIqd, int $providerShareIqd): Receipt
    {
        return Receipt::create([
            'receipt_number' => $this->nextReceiptNumber(),
            'booking_id' => $booking->id,
            'payment_id' => $payment->id,
            'customer_id' => $booking->customer_id,
            'provider_profile_id' => $booking->provider_profile_id,
            'total_price_iqd' => $booking->total_price_iqd,
            'deposit_iqd' => $booking->deposit_iqd,
            'platform_commission_iqd' => $commissionIqd,
            'provider_share_iqd' => $providerShareIqd,
            'payment_method' => $payment->method ?? null,
            'issued_at' => now(),
            'metadata' => ['type' => 'deposit_receipt'],
        ]);
    }

    private function nextReceiptNumber(): string
    {
        $prefix = config('sawrni.receipt_prefix');
        return $prefix . '-' . now()->format('Ymd') . '-' . str_pad((string) (Receipt::count() + 1), 6, '0', STR_PAD_LEFT);
    }
}
