<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class UploadService
{
    public function storeDeliveryFile(UploadedFile $file, int $bookingId): array
    {
        $disk = config('filesystems.default', 'local');
        $directory = 'deliveries/' . $bookingId;
        $safeName = Str::uuid()->toString() . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs($directory, $safeName, $disk);

        return [
            'disk' => $disk,
            'path' => $path,
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'size_bytes' => $file->getSize(),
        ];
    }

    public function temporaryUrl(string $disk, string $path, int $minutes = 30): ?string
    {
        $storage = Storage::disk($disk);

        if (method_exists($storage, 'temporaryUrl')) {
            return $storage->temporaryUrl($path, now()->addMinutes($minutes));
        }

        return $storage->url($path);
    }
}
