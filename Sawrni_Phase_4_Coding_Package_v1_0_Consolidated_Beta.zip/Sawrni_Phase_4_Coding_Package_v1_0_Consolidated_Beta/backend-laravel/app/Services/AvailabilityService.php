<?php

namespace App\Services;

use App\Models\Booking;
use Carbon\CarbonInterface;

class AvailabilityService
{
    public function providerHasConflict(int $providerProfileId, CarbonInterface $start, int $durationMinutes, ?int $ignoreBookingId = null): bool
    {
        $end = $start->copy()->addMinutes($durationMinutes);

        return Booking::query()
            ->where('provider_profile_id', $providerProfileId)
            ->when($ignoreBookingId, fn ($q) => $q->where('id', '!=', $ignoreBookingId))
            ->whereNotIn('status', ['cancelled', 'rejected'])
            ->where(function ($q) use ($start, $end) {
                $q->whereBetween('scheduled_at', [$start, $end])
                    ->orWhere(function ($q2) use ($start, $end) {
                        $q2->where('scheduled_at', '<=', $start)
                           ->whereRaw("scheduled_at + (duration_minutes || ' minutes')::interval >= ?", [$end]);
                    });
            })
            ->exists();
    }
}
