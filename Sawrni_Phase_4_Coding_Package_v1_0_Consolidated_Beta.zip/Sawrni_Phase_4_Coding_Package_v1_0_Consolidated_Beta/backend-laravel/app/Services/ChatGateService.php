<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\User;

class ChatGateService
{
    public function canAccessBookingChat(User $user, Booking $booking): bool
    {
        if (!$booking->deposit_paid_at) {
            return false;
        }

        if ($booking->customer_id === $user->id) {
            return true;
        }

        $providerUserId = $booking->providerProfile?->user_id;
        return $providerUserId === $user->id;
    }
}
