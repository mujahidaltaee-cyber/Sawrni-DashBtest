<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\NotificationLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class NotificationService
{
    public function create(User $user, string $type, string $title, string $body, array $payload = []): NotificationLog
    {
        return NotificationLog::create([
            'user_id' => $user->id,
            'type' => $type,
            'title' => $title,
            'body' => $body,
            'payload' => $payload,
            'read_at' => null,
        ]);
    }

    public function bookingStatusChanged(Booking $booking, ?string $oldStatus, string $newStatus): void
    {
        $booking->loadMissing('customer', 'providerProfile.user');

        $title = 'Booking update';
        $body = "Booking #{$booking->id} changed from {$oldStatus} to {$newStatus}.";
        $payload = ['booking_id' => $booking->id, 'old_status' => $oldStatus, 'new_status' => $newStatus];

        if ($booking->customer) {
            $this->create($booking->customer, 'booking_status_changed', $title, $body, $payload);
        }
        if ($booking->providerProfile?->user) {
            $this->create($booking->providerProfile->user, 'booking_status_changed', $title, $body, $payload);
        }
    }

    public function bookingCreated(Booking $booking): void
    {
        $booking->loadMissing('providerProfile.user');
        if ($booking->providerProfile?->user) {
            $this->create(
                $booking->providerProfile->user,
                'booking_created',
                'New booking request',
                "A new booking request #{$booking->id} has been created.",
                ['booking_id' => $booking->id]
            );
        }
    }

    public function audience(string $audience): Builder
    {
        return User::query()->when($audience !== 'all', function ($query) use ($audience) {
            $role = match ($audience) {
                'customers' => 'customer',
                'providers' => 'provider',
                'admins' => 'admin',
                default => null,
            };
            if ($role) {
                $query->where('role', $role);
            }
        });
    }

    public function broadcast(string $audience, string $title, string $body, array $payload = []): int
    {
        $count = 0;
        $this->audience($audience)->select('id')->chunkById(200, function (Collection $users) use (&$count, $title, $body, $payload) {
            foreach ($users as $user) {
                $this->create($user, 'admin_broadcast', $title, $body, $payload);
                $count++;
            }
        });
        return $count;
    }
}
