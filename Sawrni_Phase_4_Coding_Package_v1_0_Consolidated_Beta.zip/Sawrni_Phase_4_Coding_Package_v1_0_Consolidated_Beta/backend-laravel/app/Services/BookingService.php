<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\ChatThread;
use Carbon\Carbon;
use RuntimeException;

class BookingService
{
    public function canCustomerEdit(Booking $booking): bool
    {
        if (!$booking->deposit_paid_at) {
            return false;
        }

        return Carbon::parse($booking->deposit_paid_at)
            ->addHours((int) config('sawrni.booking_edit_window_hours', 3))
            ->isFuture();
    }

    public function isCancellationRefundable(Booking $booking): bool
    {
        if (!$booking->deposit_paid_at) {
            return false;
        }

        return Carbon::parse($booking->deposit_paid_at)
            ->addHours((int) config('sawrni.booking_cancel_refund_window_hours', 1))
            ->isFuture();
    }

    public function unlockChatAfterDeposit(Booking $booking): void
    {
        if (!$booking->deposit_paid_at) {
            throw new RuntimeException('Deposit must be paid before unlocking chat.');
        }

        ChatThread::updateOrCreate(
            ['booking_id' => $booking->id],
            [
                'customer_id' => $booking->customer_id,
                'provider_user_id' => $booking->provider->user_id,
                'is_locked' => false,
            ]
        );
    }
}
