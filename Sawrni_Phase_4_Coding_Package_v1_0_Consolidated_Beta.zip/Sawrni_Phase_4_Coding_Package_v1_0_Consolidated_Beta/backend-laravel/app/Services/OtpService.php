<?php

namespace App\Services;

use App\Models\PhoneOtp;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class OtpService
{
    public function issue(string $phone, string $purpose = 'login'): string
    {
        $code = config('sawrni.otp.use_demo_code')
            ? config('sawrni.otp.demo_code')
            : str_pad((string) random_int(0, 999999), config('sawrni.otp.length'), '0', STR_PAD_LEFT);

        PhoneOtp::create([
            'phone' => $phone,
            'purpose' => $purpose,
            'code_hash' => Hash::make($code),
            'expires_at' => now()->addMinutes(config('sawrni.otp.ttl_minutes')),
        ]);

        // Integrate SMS provider here. For development, return the code.
        return $code;
    }

    public function verify(string $phone, string $code, string $purpose = 'login'): bool
    {
        $otp = PhoneOtp::where('phone', $phone)
            ->where('purpose', $purpose)
            ->whereNull('verified_at')
            ->latest()
            ->first();

        if (!$otp || $otp->expires_at->isPast()) {
            throw ValidationException::withMessages(['otp' => ['OTP expired or not found.']]);
        }

        $otp->increment('attempts');

        if (!Hash::check($code, $otp->code_hash)) {
            throw ValidationException::withMessages(['otp' => ['Invalid OTP code.']]);
        }

        $otp->update(['verified_at' => now()]);
        return true;
    }
}
