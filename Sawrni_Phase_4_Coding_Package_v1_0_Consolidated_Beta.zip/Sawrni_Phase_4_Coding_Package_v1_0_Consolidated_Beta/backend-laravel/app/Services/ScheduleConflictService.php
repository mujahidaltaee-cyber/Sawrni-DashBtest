<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\ProviderProfile;
use Carbon\CarbonInterface;

class ScheduleConflictService
{
    private const BLOCKING_STATUSES = [
        'pending_provider', 'accepted', 'deposit_paid', 'confirmed', 'in_progress', 'finished',
    ];

    public function hasConflict(ProviderProfile $provider, CarbonInterface $startsAt, int $durationMinutes, ?int $ignoreBookingId = null): bool
    {
        $endsAt = $startsAt->copy()->addMinutes($durationMinutes);

        return Booking::query()
            ->where('provider_profile_id', $provider->id)
            ->whereIn('status', self::BLOCKING_STATUSES)
            ->when($ignoreBookingId, fn ($query) => $query->where('id', '!=', $ignoreBookingId))
            ->where(function ($query) use ($startsAt, $endsAt) {
                $query->where(function ($q) use ($startsAt, $endsAt) {
                    $q->where('scheduled_at', '<', $endsAt)
                      ->whereRaw("DATE_ADD(scheduled_at, INTERVAL duration_minutes MINUTE) > ?", [$startsAt]);
                });
            })
            ->exists();
    }

    public function assertNoConflict(ProviderProfile $provider, CarbonInterface $startsAt, int $durationMinutes, ?int $ignoreBookingId = null): void
    {
        if ($this->hasConflict($provider, $startsAt, $durationMinutes, $ignoreBookingId)) {
            abort(422, 'Provider has a conflicting booking at the selected time.');
        }
    }
}
