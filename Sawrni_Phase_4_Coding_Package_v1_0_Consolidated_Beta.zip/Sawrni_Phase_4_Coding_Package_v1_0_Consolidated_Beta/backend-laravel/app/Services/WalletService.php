<?php

namespace App\Services;

use App\Enums\WalletTransactionType;
use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;

class WalletService
{
    public function ensureWallet(ProviderProfile $provider): Wallet
    {
        return Wallet::firstOrCreate(
            ['provider_profile_id' => $provider->id],
            ['balance_iqd' => 0, 'total_earned_iqd' => 0, 'total_debt_iqd' => 0]
        );
    }

    public function recordBookingFinancials(Booking $booking, int $commissionIqd, int $providerShareIqd): void
    {
        DB::transaction(function () use ($booking, $commissionIqd, $providerShareIqd) {
            $provider = $booking->providerProfile;
            $wallet = $this->ensureWallet($provider);

            WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'booking_id' => $booking->id,
                'type' => WalletTransactionType::BookingCredit->value,
                'amount_iqd' => $providerShareIqd,
                'description' => 'Provider share from completed booking value.',
            ]);

            WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'booking_id' => $booking->id,
                'type' => WalletTransactionType::PlatformCommission->value,
                'amount_iqd' => -1 * $commissionIqd,
                'description' => 'Sawrni platform commission: 15% of full transaction.',
            ]);

            $wallet->increment('total_earned_iqd', $providerShareIqd);
            $wallet->increment('total_debt_iqd', $commissionIqd);
            $wallet->decrement('balance_iqd', $commissionIqd);
        });
    }

    public function recordDebtPayment(ProviderProfile $provider, int $amountIqd, ?string $note = null): WalletTransaction
    {
        $wallet = $this->ensureWallet($provider);

        return DB::transaction(function () use ($wallet, $amountIqd, $note) {
            $transaction = WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'type' => WalletTransactionType::DebtPayment->value,
                'amount_iqd' => $amountIqd,
                'description' => $note ?? 'Provider debt payment.',
            ]);

            $wallet->increment('balance_iqd', $amountIqd);
            $wallet->decrement('total_debt_iqd', min($wallet->total_debt_iqd, $amountIqd));

            return $transaction;
        });
    }
}
