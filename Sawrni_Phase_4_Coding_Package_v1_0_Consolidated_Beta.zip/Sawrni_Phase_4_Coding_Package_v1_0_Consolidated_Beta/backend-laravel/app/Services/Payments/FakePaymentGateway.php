<?php

namespace App\Services\Payments;

use App\Models\Booking;
use App\Models\Payment;
use Illuminate\Support\Str;

class FakePaymentGateway implements PaymentGateway
{
    public function createDepositIntent(Booking $booking): PaymentResult
    {
        return new PaymentResult(
            success: true,
            status: 'requires_confirmation',
            externalReference: 'fake_pi_' . Str::uuid()->toString(),
            raw: [
                'gateway' => 'fake',
                'amount_iqd' => $booking->deposit_iqd,
                'currency' => 'IQD',
            ],
        );
    }

    public function verify(Payment $payment, array $payload = []): PaymentResult
    {
        $forceFail = (bool) ($payload['force_fail'] ?? false);

        return new PaymentResult(
            success: ! $forceFail,
            status: $forceFail ? 'failed' : 'paid',
            externalReference: $payment->external_reference,
            raw: ['verified_by' => 'fake_gateway', 'payload' => $payload],
        );
    }
}
