<?php

namespace App\Services\Payments;

use App\Models\Booking;
use App\Models\Payment;

interface PaymentGateway
{
    public function createDepositIntent(Booking $booking): PaymentResult;
    public function verify(Payment $payment, array $payload = []): PaymentResult;
}
