<?php

namespace App\Services\Payments;

class PaymentGatewayManager
{
    public function gateway(): PaymentGateway
    {
        return match (config('sawrni.payment_gateway', 'fake')) {
            'fake' => new FakePaymentGateway(),
            default => new FakePaymentGateway(),
        };
    }
}
