<?php

namespace App\Policies;

use App\Models\Booking;
use App\Models\User;

class BookingPolicy
{
    public function view(User $user, Booking $booking): bool
    {
        if ($booking->customer_id === $user->id) {
            return true;
        }

        return $booking->providerProfile?->user_id === $user->id;
    }

    public function editAfterDeposit(User $user, Booking $booking): bool
    {
        if ($booking->customer_id !== $user->id || !$booking->deposit_paid_at) {
            return false;
        }

        return $booking->deposit_paid_at->diffInHours(now()) < config('sawrni.booking_edit_window_hours');
    }

    public function cancelWithRefund(User $user, Booking $booking): bool
    {
        if ($booking->customer_id !== $user->id || !$booking->deposit_paid_at) {
            return false;
        }

        return $booking->deposit_paid_at->diffInHours(now()) < config('sawrni.booking_cancel_refund_window_hours');
    }
}
