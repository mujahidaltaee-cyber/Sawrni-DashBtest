<?php

namespace Tests\Feature;

use Tests\TestCase;

class NotificationCenterTest extends TestCase
{
    public function test_user_can_list_own_notifications(): void
    {
        $this->markTestIncomplete('Create notification logs and assert only current user notifications are returned.');
    }

    public function test_device_token_registration_updates_existing_token(): void
    {
        $this->markTestIncomplete('Register token twice and assert one record with updated metadata.');
    }
}
