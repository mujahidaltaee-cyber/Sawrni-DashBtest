<?php

namespace Tests\Feature;

use Tests\TestCase;

class PaymentIntentTest extends TestCase
{
    public function test_customer_can_create_deposit_payment_intent_for_own_booking(): void
    {
        $this->markTestIncomplete('Create customer booking then call deposit-intent and assert payment row created.');
    }

    public function test_customer_cannot_create_payment_intent_for_other_customer_booking(): void
    {
        $this->markTestIncomplete('Assert 403 for cross-customer payment intent.');
    }
}
