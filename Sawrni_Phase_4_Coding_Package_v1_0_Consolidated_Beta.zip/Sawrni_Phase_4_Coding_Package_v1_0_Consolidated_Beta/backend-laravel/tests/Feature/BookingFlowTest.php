<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\ProviderProfile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BookingFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_customer_cannot_book_unapproved_provider(): void
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $provider = ProviderProfile::factory()->create(['approval_status' => 'pending', 'is_visible' => false]);

        $this->actingAs($customer)
            ->postJson('/api/v1/customer/bookings', [
                'provider_profile_id' => $provider->id,
                'service_offering_id' => 1,
                'scheduled_at' => now()->addDays(3)->toISOString(),
                'location_lat' => 33.3152,
                'location_lng' => 44.3661,
                'location_address' => 'Baghdad',
            ])
            ->assertStatus(422);
    }

    public function test_booking_edit_window_is_three_hours_after_deposit_payment(): void
    {
        $booking = Booking::factory()->create([
            'deposit_paid_at' => now()->subHours(4),
            'status' => 'confirmed',
        ]);

        $this->assertFalse($booking->canBeEditedByCustomer());
    }
}
