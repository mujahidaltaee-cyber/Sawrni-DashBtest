<?php

namespace Tests\Feature;

use App\Services\FileSecurityService;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;

class DeliveryUploadTest extends TestCase
{
    public function test_delivery_file_security_allows_supported_file(): void
    {
        $file = UploadedFile::fake()->image('delivery.jpg');
        (new FileSecurityService())->validateDeliveryFile($file, 10);

        $this->assertTrue(true);
    }
}
