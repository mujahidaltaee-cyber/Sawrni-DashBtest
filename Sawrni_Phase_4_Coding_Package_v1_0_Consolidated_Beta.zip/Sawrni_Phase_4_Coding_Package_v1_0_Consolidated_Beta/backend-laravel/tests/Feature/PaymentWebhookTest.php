<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PaymentWebhookTest extends TestCase
{
    use RefreshDatabase;

    public function test_payment_webhook_rejects_invalid_signature(): void
    {
        $this->postJson('/api/v1/payments/fake/webhook', [
            'reference' => 'test-reference',
            'status' => 'paid',
        ], ['X-Sawrni-Signature' => 'invalid'])->assertStatus(401);
    }

    public function test_payment_webhook_accepts_valid_local_signature(): void
    {
        $this->postJson('/api/v1/payments/fake/webhook', [
            'reference' => 'test-reference',
            'status' => 'paid',
        ], ['X-Sawrni-Signature' => 'local'])->assertStatus(202);
    }
}
