<?php

namespace Tests\Feature;

use Tests\TestCase;

class BookingFlowStateTest extends TestCase
{
    public function test_booking_flow_state_endpoint_contract(): void
    {
        $this->markTestIncomplete('v0.8 endpoint contract test. Complete after Booking factory relationships are runtime verified.');
    }
}
