<?php

namespace Tests\Feature;

use Tests\TestCase;

class ProviderScheduleConflictTest extends TestCase
{
    public function test_customer_cannot_create_booking_when_provider_time_conflicts(): void
    {
        $this->markTestIncomplete('Create customer, approved provider, service offering, existing booking, then assert 422 on overlapping slot.');
    }

    public function test_customer_can_create_booking_when_time_does_not_overlap(): void
    {
        $this->markTestIncomplete('Assert non-overlapping slot creates booking successfully.');
    }
}
