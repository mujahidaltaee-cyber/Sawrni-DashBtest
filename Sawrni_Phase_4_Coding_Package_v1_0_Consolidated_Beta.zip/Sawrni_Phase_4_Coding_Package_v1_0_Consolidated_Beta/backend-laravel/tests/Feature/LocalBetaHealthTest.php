<?php

namespace Tests\Feature;

use Tests\TestCase;

class LocalBetaHealthTest extends TestCase
{
    public function test_health_endpoint_returns_ok(): void
    {
        $this->getJson('/api/v1/health')
            ->assertOk()
            ->assertJsonPath('app', 'Sawrni');
    }

    public function test_local_beta_status_exposes_core_business_rules(): void
    {
        $this->getJson('/api/v1/local-beta/status')
            ->assertOk()
            ->assertJsonPath('platform_commission_percent', 15)
            ->assertJsonPath('debt_suspension_threshold_iqd', 75000);
    }
}
