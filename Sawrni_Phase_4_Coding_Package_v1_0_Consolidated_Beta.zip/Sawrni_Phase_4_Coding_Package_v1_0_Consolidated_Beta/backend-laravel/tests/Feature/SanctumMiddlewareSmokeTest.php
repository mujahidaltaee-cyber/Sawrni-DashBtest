<?php

namespace Tests\Feature;

use Tests\TestCase;

class SanctumMiddlewareSmokeTest extends TestCase
{
    public function test_protected_routes_require_authentication(): void
    {
        $this->markTestIncomplete('Call /api/v1/customer/bookings and assert 401 without Sanctum token.');
    }

    public function test_role_middleware_rejects_wrong_role(): void
    {
        $this->markTestIncomplete('Authenticate provider and assert customer route returns 403.');
    }
}
