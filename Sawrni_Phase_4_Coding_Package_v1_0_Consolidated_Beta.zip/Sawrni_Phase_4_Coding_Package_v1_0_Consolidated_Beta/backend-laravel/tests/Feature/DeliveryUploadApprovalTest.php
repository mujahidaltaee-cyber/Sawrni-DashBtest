<?php

namespace Tests\Feature;

use Tests\TestCase;

class DeliveryUploadApprovalTest extends TestCase
{
    public function test_provider_can_upload_final_delivery_after_session_finished(): void
    {
        $this->markTestIncomplete('Use UploadedFile fake and assert delivery file status pending_approval.');
    }

    public function test_customer_cannot_access_delivery_before_admin_approval(): void
    {
        $this->markTestIncomplete('Assert approved status is required before customer download response.');
    }
}
