<?php

namespace Tests\Feature;

use Tests\TestCase;

class ProviderDebtSuspensionCommandTest extends TestCase
{
    public function test_provider_is_suspended_when_wallet_debt_reaches_threshold(): void
    {
        $this->markTestIncomplete('Seed wallet debt >= 75000, run command, assert provider is_suspended true.');
    }
}
