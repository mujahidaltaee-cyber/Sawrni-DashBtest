<?php

namespace Tests\Feature;

use Tests\TestCase;

class ProviderServiceManagementTest extends TestCase
{
    public function test_provider_can_create_own_service_offering(): void
    {
        $this->markTestIncomplete('Assert provider can create service offering with price, deposit, and duration.');
    }

    public function test_provider_cannot_update_another_provider_service(): void
    {
        $this->markTestIncomplete('Assert 403 when editing service owned by another provider profile.');
    }
}
