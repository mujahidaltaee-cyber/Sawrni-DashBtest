<?php

namespace Tests\Feature;

use App\Services\CommissionService;
use Tests\TestCase;

class WalletLedgerTest extends TestCase
{
    public function test_platform_commission_is_fifteen_percent_of_total_booking_value(): void
    {
        $service = new CommissionService();

        $this->assertEquals(15000, $service->platformCommission(100000));
        $this->assertEquals(85000, $service->providerShare(100000));
    }
}
