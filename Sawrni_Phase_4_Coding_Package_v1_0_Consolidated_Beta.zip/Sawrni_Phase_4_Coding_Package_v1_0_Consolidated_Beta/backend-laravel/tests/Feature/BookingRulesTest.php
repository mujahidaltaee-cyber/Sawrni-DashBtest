<?php

namespace Tests\Feature;

use Tests\TestCase;

class BookingRulesTest extends TestCase
{
    public function test_customer_cannot_edit_booking_without_deposit_payment(): void
    {
        $this->markTestIncomplete('Create booking factory then assert edit is blocked before deposit payment.');
    }

    public function test_customer_can_edit_within_three_hours_after_deposit_payment(): void
    {
        $this->markTestIncomplete('Create booking factory with deposit_paid_at and assert edit window.');
    }

    public function test_deposit_is_non_refundable_after_one_hour(): void
    {
        $this->markTestIncomplete('Assert cancellation state becomes cancelled_non_refundable after refund window.');
    }
}
