<?php

namespace Tests\Feature;

use Tests\TestCase;

class AuthProviderApprovalTest extends TestCase
{
    public function test_provider_registers_as_pending_and_hidden(): void
    {
        $this->markTestIncomplete('Create User and ProviderProfile factories, then assert approval_status=pending and is_public=false.');
    }

    public function test_approved_provider_becomes_public(): void
    {
        $this->markTestIncomplete('Use ProviderApprovalService and assert approved_at is set and is_public=true.');
    }
}
