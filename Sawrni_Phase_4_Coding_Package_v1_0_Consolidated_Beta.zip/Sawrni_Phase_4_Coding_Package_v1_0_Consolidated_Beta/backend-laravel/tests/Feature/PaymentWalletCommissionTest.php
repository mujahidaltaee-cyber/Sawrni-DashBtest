<?php

namespace Tests\Feature;

use Tests\TestCase;

class PaymentWalletCommissionTest extends TestCase
{
    public function test_commission_is_15_percent_of_total_booking_value(): void
    {
        $this->assertSame(15000, (int) round(100000 * 0.15));
    }

    public function test_deposit_confirmation_creates_receipt_and_wallet_transactions(): void
    {
        $this->markTestIncomplete('Create Booking, PaymentService dependencies, then assert receipt and wallet transactions exist.');
    }
}
