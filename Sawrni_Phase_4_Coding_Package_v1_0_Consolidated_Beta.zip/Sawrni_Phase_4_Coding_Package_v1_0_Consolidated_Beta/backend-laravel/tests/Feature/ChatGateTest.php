<?php

namespace Tests\Feature;

use Tests\TestCase;

class ChatGateTest extends TestCase
{
    public function test_chat_is_blocked_before_deposit_payment(): void
    {
        $this->markTestIncomplete('Create booking without deposit_paid_at and assert ChatGateService returns false.');
    }

    public function test_chat_opens_after_deposit_payment(): void
    {
        $this->markTestIncomplete('Create booking with deposit_paid_at and assert customer/provider can access chat.');
    }
}
