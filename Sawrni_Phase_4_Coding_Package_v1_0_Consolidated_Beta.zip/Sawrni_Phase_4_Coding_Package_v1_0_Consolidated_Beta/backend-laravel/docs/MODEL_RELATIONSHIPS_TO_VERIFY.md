# Model Relationships to Verify in Host Laravel Project

Some v0.3 controllers rely on these relationships. Add them if missing when merging into the runnable Laravel app.

## User

```php
public function providerProfile(): HasOne { return $this->hasOne(ProviderProfile::class); }
public function notifications(): HasMany { return $this->hasMany(NotificationLog::class); }
public function deviceTokens(): HasMany { return $this->hasMany(DeviceToken::class); }
```

## ProviderProfile

```php
public function user(): BelongsTo { return $this->belongsTo(User::class); }
public function services(): HasMany { return $this->hasMany(ServiceOffering::class); }
public function portfolioItems(): HasMany { return $this->hasMany(PortfolioItem::class); }
public function bookings(): HasMany { return $this->hasMany(Booking::class); }
public function wallet(): HasOne { return $this->hasOne(Wallet::class); }
public function subscription(): HasOne { return $this->hasOne(ProviderSubscription::class)->latestOfMany(); }
```

## Booking

```php
public function customer(): BelongsTo { return $this->belongsTo(User::class, 'customer_id'); }
public function providerProfile(): BelongsTo { return $this->belongsTo(ProviderProfile::class); }
public function serviceOffering(): BelongsTo { return $this->belongsTo(ServiceOffering::class); }
public function statusHistory(): HasMany { return $this->hasMany(BookingStatusHistory::class); }
public function payments(): HasMany { return $this->hasMany(Payment::class); }
public function deliveryFiles(): HasMany { return $this->hasMany(DeliveryFile::class); }
```
