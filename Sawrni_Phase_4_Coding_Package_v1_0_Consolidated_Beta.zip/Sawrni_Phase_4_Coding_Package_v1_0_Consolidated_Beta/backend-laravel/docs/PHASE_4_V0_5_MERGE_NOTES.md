# Phase 4 v0.5 Merge Notes

Because this package is delivered as framework code snippets and folders, merge carefully:

1. Copy `app/Services` files into Laravel.
2. Copy `app/Http/Requests` files into Laravel.
3. Copy new controllers into Laravel.
4. Merge the route additions manually into `routes/api.php` inside the authenticated v1 group.
5. Confirm enum string values match database migrations.
6. Run static analysis or Laravel tests before connecting Flutter.

Known implementation checkpoints:

- `Booking` model must cast `deposit_paid_at`, `scheduled_at`, `cancelled_at` to datetime.
- `provider_profiles.approval_status` should use the same string values as the enum.
- `wallet_transactions` must allow nullable booking_id and payment_id.
- Review table should include status, approved_by, approved_at, rejected_by, rejected_at, rejection_reason.
