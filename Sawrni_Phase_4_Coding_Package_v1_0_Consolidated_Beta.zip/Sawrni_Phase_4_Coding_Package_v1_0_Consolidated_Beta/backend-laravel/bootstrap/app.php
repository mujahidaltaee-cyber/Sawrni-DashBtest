<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'role' => \App\Http\Middleware\EnsureUserRole::class,
            'admin.permission' => \App\Http\Middleware\EnsureAdminPermission::class,
            'provider.approved' => \App\Http\Middleware\EnsureProviderApproved::class,
            'payment.webhook.signature' => \App\Http\Middleware\VerifyPaymentWebhookSignature::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Centralized API exception rendering can be added in the hardening phase.
    })->create();
