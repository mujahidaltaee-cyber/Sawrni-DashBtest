<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\HealthController;
use App\Http\Controllers\Api\LocalBetaStatusController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PublicCatalogController;
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\PaymentWebhookController;
use App\Http\Controllers\Api\Customer\CustomerBookingController;
use App\Http\Controllers\Api\Customer\PaymentController as CustomerPaymentController;
use App\Http\Controllers\Api\Customer\PaymentIntentController;
use App\Http\Controllers\Api\Customer\ReviewController as CustomerReviewController;
use App\Http\Controllers\Api\Customer\BookingFlowStateController;
use App\Http\Controllers\Api\Provider\ProviderBookingController;
use App\Http\Controllers\Api\Provider\ProviderProfileController;
use App\Http\Controllers\Api\Provider\ServiceOfferingController;
use App\Http\Controllers\Api\Provider\PortfolioController;
use App\Http\Controllers\Api\Provider\DeliveryController as ProviderDeliveryController;
use App\Http\Controllers\Api\Provider\WalletController as ProviderWalletController;
use App\Http\Controllers\Api\Admin\ProviderApprovalController;
use App\Http\Controllers\Api\Admin\DeliveryApprovalController;
use App\Http\Controllers\Api\Admin\AdminDashboardController;
use App\Http\Controllers\Api\Admin\AdminPermissionController;
use App\Http\Controllers\Api\Admin\WalletController as AdminWalletController;
use App\Http\Controllers\Api\Admin\BookingController as AdminBookingController;
use App\Http\Controllers\Api\Admin\ServiceCategoryController as AdminServiceCategoryController;
use App\Http\Controllers\Api\Admin\NotificationBroadcastController;
use App\Http\Controllers\Api\Admin\ReviewApprovalController;
use App\Http\Controllers\Api\Admin\ProviderReassignmentController;
use App\Http\Controllers\Api\Admin\CustomerAdminController;
use App\Http\Controllers\Api\Admin\ProviderAdminController;
use App\Http\Controllers\Api\Admin\SubscriptionAdminController;
use App\Http\Controllers\Api\Admin\BookingActionAdminController;

Route::prefix('v1')->group(function () {
    Route::get('/health', HealthController::class);
    Route::get('/local-beta/status', LocalBetaStatusController::class);

    Route::post('/auth/register/customer', [AuthController::class, 'registerCustomer']);
    Route::post('/auth/register/provider', [AuthController::class, 'registerProvider']);
    Route::post('/auth/login', [AuthController::class, 'login']);
    Route::post('/auth/request-otp', [AuthController::class, 'requestOtp']);
    Route::post('/auth/verify-otp', [AuthController::class, 'verifyOtp']);

    Route::get('/categories', [PublicCatalogController::class, 'categories']);
    Route::get('/providers', [PublicCatalogController::class, 'providers']);
    Route::get('/providers/{providerProfile}', [PublicCatalogController::class, 'providerShow']);
    Route::get('/models-grid', [PublicCatalogController::class, 'modelsGrid']);

    Route::post('/payments/{gateway}/webhook', PaymentWebhookController::class)
        ->name('payments.webhook')
        ->middleware('payment.webhook.signature');

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/auth/logout', [AuthController::class, 'logout']);

        Route::get('/notifications', [NotificationController::class, 'index']);
        Route::post('/notifications/{id}/read', [NotificationController::class, 'markRead']);
        Route::post('/device-tokens', [NotificationController::class, 'registerDevice']);

        Route::prefix('customer')->middleware('role:customer')->group(function () {
            Route::get('/bookings', [CustomerBookingController::class, 'index']);
            Route::post('/bookings', [CustomerBookingController::class, 'store']);
            Route::get('/bookings/{booking}', [CustomerBookingController::class, 'show']);
            Route::patch('/bookings/{booking}', [CustomerBookingController::class, 'update']);
            Route::post('/bookings/{booking}/cancel', [CustomerBookingController::class, 'cancel']);
            Route::post('/bookings/{booking}/deposit-intent', [PaymentIntentController::class, 'createDepositIntent']);
            Route::post('/bookings/{booking}/confirm-deposit', [CustomerPaymentController::class, 'confirmDeposit']);
            Route::post('/bookings/{booking}/reviews', [CustomerReviewController::class, 'store']);
            Route::get('/bookings/{booking}/flow-state', [BookingFlowStateController::class, 'show']);
        });

        Route::prefix('provider')->middleware(['role:provider', 'provider.approved'])->group(function () {
            Route::get('/profile', [ProviderProfileController::class, 'show']);
            Route::patch('/profile', [ProviderProfileController::class, 'update']);

            Route::get('/services', [ServiceOfferingController::class, 'index']);
            Route::post('/services', [ServiceOfferingController::class, 'store']);
            Route::put('/services/{serviceOffering}', [ServiceOfferingController::class, 'update']);
            Route::delete('/services/{serviceOffering}', [ServiceOfferingController::class, 'destroy']);

            Route::get('/portfolio', [PortfolioController::class, 'index']);
            Route::post('/portfolio', [PortfolioController::class, 'store']);

            Route::get('/bookings', [ProviderBookingController::class, 'index']);
            Route::get('/bookings/{booking}', [ProviderBookingController::class, 'show']);
            Route::post('/bookings/{booking}/{action}', [ProviderBookingController::class, 'action'])
                ->whereIn('action', ['accept', 'reject', 'start', 'finish', 'complete']);

            Route::post('/bookings/{booking}/delivery-files', [ProviderDeliveryController::class, 'upload']);
            Route::get('/wallet', [ProviderWalletController::class, 'show']);
        });

        Route::get('/bookings/{booking}/chat', [ChatController::class, 'show']);
        Route::post('/bookings/{booking}/chat/messages', [ChatController::class, 'send']);

        Route::prefix('admin')->middleware('role:admin,super_admin')->group(function () {
            Route::get('/dashboard', [AdminDashboardController::class, 'index']);

            Route::get('/customers', [CustomerAdminController::class, 'index']);
            Route::get('/customers/{customer}', [CustomerAdminController::class, 'show']);
            Route::post('/customers/{customer}/suspend', [CustomerAdminController::class, 'suspend']);
            Route::post('/customers/{customer}/reactivate', [CustomerAdminController::class, 'reactivate']);

            Route::get('/providers', [ProviderAdminController::class, 'index']);
            Route::get('/providers/pending', [ProviderApprovalController::class, 'pending']);
            Route::get('/providers/{providerProfile}', [ProviderAdminController::class, 'show']);
            Route::post('/providers/{providerProfile}/approve', [ProviderApprovalController::class, 'approve']);
            Route::post('/providers/{providerProfile}/reject', [ProviderApprovalController::class, 'reject']);
            Route::post('/providers/{providerProfile}/suspend', [ProviderAdminController::class, 'suspend']);
            Route::post('/providers/{providerProfile}/reactivate', [ProviderAdminController::class, 'reactivate']);

            Route::get('/bookings', [AdminBookingController::class, 'index']);
            Route::get('/bookings/{booking}', [AdminBookingController::class, 'show']);
            Route::post('/bookings/{booking}/request-provider-reassignment', [ProviderReassignmentController::class, 'requestCustomerApproval']);
            Route::post('/bookings/{booking}/resolve-dispute', [BookingActionAdminController::class, 'resolveDispute']);

            Route::get('/deliveries/pending', [DeliveryApprovalController::class, 'pending']);
            Route::post('/deliveries/{deliveryFile}/approve', [DeliveryApprovalController::class, 'approve']);
            Route::post('/deliveries/{deliveryFile}/reject', [DeliveryApprovalController::class, 'reject']);

            Route::get('/reviews/pending', [ReviewApprovalController::class, 'pending']);
            Route::post('/reviews/{review}/approve', [ReviewApprovalController::class, 'approve']);
            Route::post('/reviews/{review}/reject', [ReviewApprovalController::class, 'reject']);

            Route::get('/wallets', [AdminWalletController::class, 'index']);
            Route::post('/wallets/{wallet}/record-payment', [AdminWalletController::class, 'recordPayment']);

            Route::get('/service-categories', [AdminServiceCategoryController::class, 'index']);
            Route::post('/service-categories', [AdminServiceCategoryController::class, 'store']);
            Route::put('/service-categories/{serviceCategory}', [AdminServiceCategoryController::class, 'update']);

            Route::get('/subscriptions', [SubscriptionAdminController::class, 'index']);
            Route::post('/providers/{providerProfile}/subscriptions', [SubscriptionAdminController::class, 'assign']);
            Route::post('/subscriptions/{providerSubscription}/cancel', [SubscriptionAdminController::class, 'cancel']);

            Route::post('/notifications/broadcast', [NotificationBroadcastController::class, 'store']);

            Route::get('/admins/{admin}/permissions', [AdminPermissionController::class, 'show']);
            Route::post('/admins/{admin}/permissions', [AdminPermissionController::class, 'grant']);
            Route::delete('/admins/{admin}/permissions/{permission}', [AdminPermissionController::class, 'revoke']);
        });
    });
});

// Phase 4 v0.9 staging verification route.
// Keep this endpoint protected in production or disable it outside staging.
Route::get('/v1/staging/status', \App\Http\Controllers\Api\Staging\StagingStatusController::class);
