<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('sawrni:suspend-provider-debts')->hourly();
