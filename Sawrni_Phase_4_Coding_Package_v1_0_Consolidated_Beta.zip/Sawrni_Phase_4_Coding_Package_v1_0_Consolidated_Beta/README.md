# Sawrni Phase 4 Coding Package v0.7

This package upgrades the Sawrni coding package from integration scaffolding to **local beta wiring**. It keeps the Laravel backend, Flutter mobile app, and Admin Web app aligned around the finalized Sawrni business rules.

## What v0.7 Adds

- Active API route merge for customer, provider, admin, payment, reviews, deliveries, and wallet flows.
- Local development stack using Docker Compose.
- Backend health/status endpoints.
- Laravel middleware aliases for role, provider approval, admin permissions, and payment webhooks.
- Local `.env` templates.
- Run scripts and smoke-test script.
- Postman collection for first API checks.
- Flutter app shell connected to the API layer.
- Admin web local login and protected dashboard shell.
- QA checklist for end-to-end local testing.

## Important Status

This package is a **developer-run beta foundation**, not a guaranteed production-ready application. It should be installed into clean Laravel, Flutter, and Next.js projects or used as the base structure for them.

## Core Business Rules Preserved

- Platform commission: 15% of the full booking value.
- Provider debt suspension threshold: 75,000 IQD.
- Booking edit window: 3 hours after deposit payment.
- Booking cancellation refund window: 1 hour after deposit payment.
- Chat and phone visibility unlock only after deposit payment.
- Provider accounts are hidden until approved by COO permission under super admin.
- Delivery files are shown to customers only after final management approval.


## Phase 4 v0.8

This package adds developer-verification wiring, booking flow state endpoint scaffold, Flutter booking flow model/repository, admin beta verification page, and environment verification scripts. It is still intended for developer/local beta use before staging.

## Phase 4 v0.9 — Staging Deployment Readiness

v0.9 adds staging deployment files and verification tools. This package is ready for a developer to attempt first staging deployment, but it has not been executed in the target environment yet.

Key files:

- `docs/STAGING_DEPLOYMENT_RUNBOOK_V0_9.md`
- `docs/STAGING_SMOKE_TEST_CHECKLIST_V0_9.md`
- `backend-laravel/.env.staging.example`
- `admin-web/.env.staging.example`
- `infrastructure/staging/docker-compose.staging.yml`
- `scripts/staging-smoke-test.sh`

Recommended command after staging deployment:

```bash
API_BASE_URL=https://api-staging.sawrni.com/api/v1 ./scripts/staging-smoke-test.sh
```

## Phase 4 v1.0 — Consolidated Beta

This package consolidates all Phase 4 incremental packages into one beta handoff package.

Start here:

- `START_HERE_EN.md`
- `START_HERE_AR.md`
- `docs/DEVELOPER_HANDOFF_GUIDE_V1_0.md`
- `docs/BETA_ACCEPTANCE_CHECKLIST_V1_0.md`
- `docs/PHASE_5_PLAN_RUNTIME_FIXES_AND_STAGING.md`

Current status: ready for developer-run verification, not production launch.
