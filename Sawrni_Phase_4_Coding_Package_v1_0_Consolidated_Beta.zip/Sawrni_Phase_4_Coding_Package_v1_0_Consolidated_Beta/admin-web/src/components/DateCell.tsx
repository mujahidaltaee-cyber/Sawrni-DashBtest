export function DateCell({ value }: { value?: string | null }) {
  if (!value) return <span>-</span>;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return <span>{value}</span>;
  return <span>{date.toLocaleString()}</span>;
}
