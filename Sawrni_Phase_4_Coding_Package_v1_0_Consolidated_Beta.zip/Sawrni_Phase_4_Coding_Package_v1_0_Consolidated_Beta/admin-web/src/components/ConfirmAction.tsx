'use client';

export function ConfirmAction({ label, message, onConfirm }: { label: string; message: string; onConfirm: () => void }) {
  return (
    <button
      className="rounded-lg bg-slate-900 px-3 py-2 text-sm text-white"
      onClick={() => {
        if (window.confirm(message)) onConfirm();
      }}
    >
      {label}
    </button>
  );
}
