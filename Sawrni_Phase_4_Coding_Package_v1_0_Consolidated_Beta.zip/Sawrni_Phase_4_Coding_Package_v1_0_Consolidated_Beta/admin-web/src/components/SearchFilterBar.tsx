'use client';

import React from 'react';

export function SearchFilterBar({
  search,
  onSearchChange,
  placeholder = 'Search',
  children,
}: {
  search: string;
  onSearchChange: (value: string) => void;
  placeholder?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-col gap-3 rounded-xl border bg-white p-4 md:flex-row md:items-center md:justify-between">
      <input
        value={search}
        onChange={(event) => onSearchChange(event.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg border px-3 py-2 text-sm md:max-w-md"
      />
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}
