import React from 'react';

export type Column<T> = {
  key: string;
  label: string;
  render?: (row: T) => React.ReactNode;
};

export function PaginatedDataTable<T extends Record<string, unknown>>({
  rows,
  columns,
  emptyMessage = 'No records found',
}: {
  rows: T[];
  columns: Column<T>[];
  emptyMessage?: string;
}) {
  if (!rows.length) {
    return <div className="rounded-xl border p-6 text-sm opacity-70">{emptyMessage}</div>;
  }

  return (
    <div className="overflow-hidden rounded-xl border bg-white">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-50 text-slate-700">
          <tr>
            {columns.map((column) => (
              <th key={column.key} className="px-4 py-3 text-left font-semibold">
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={String(row.id ?? index)} className="border-t">
              {columns.map((column) => (
                <td key={column.key} className="px-4 py-3">
                  {column.render ? column.render(row) : String(row[column.key] ?? '-')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
