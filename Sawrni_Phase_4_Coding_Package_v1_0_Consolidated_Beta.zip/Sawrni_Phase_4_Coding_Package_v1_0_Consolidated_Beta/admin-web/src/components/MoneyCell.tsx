export function MoneyCell({ amount, currency = 'IQD' }: { amount: number | string; currency?: string }) {
  const numeric = typeof amount === 'string' ? Number(amount) : amount;
  const value = Number.isFinite(numeric) ? numeric.toLocaleString('en-US') : String(amount);
  return <span className="font-medium">{value} {currency}</span>;
}
