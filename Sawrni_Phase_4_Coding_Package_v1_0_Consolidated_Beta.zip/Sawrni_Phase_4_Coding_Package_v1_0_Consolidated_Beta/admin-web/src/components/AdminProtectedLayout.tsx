'use client';

import { useEffect, useState } from 'react';
import { adminAuth } from '../lib/adminAuth';

const nav = [
  ['/', 'Dashboard'],
  ['/customers', 'Customers'],
  ['/providers', 'Providers'],
  ['/bookings', 'Bookings'],
  ['/subscriptions', 'Subscriptions'],
  ['/deliveries/1', 'Deliveries'],
];

export function AdminProtectedLayout({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!adminAuth.isLoggedIn()) {
      window.location.href = '/login';
      return;
    }
    setReady(true);
  }, []);

  if (!ready) return <main className="p-8">Loading...</main>;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <aside className="fixed left-0 top-0 h-full w-64 border-r bg-white p-5">
        <div className="text-xl font-bold">Sawrni Admin</div>
        <nav className="mt-8 space-y-2">
          {nav.map(([href, label]) => <a key={href} className="block rounded-lg px-3 py-2 hover:bg-slate-100" href={href}>{label}</a>)}
        </nav>
      </aside>
      <main className="ml-64 p-8">{children}</main>
    </div>
  );
}
