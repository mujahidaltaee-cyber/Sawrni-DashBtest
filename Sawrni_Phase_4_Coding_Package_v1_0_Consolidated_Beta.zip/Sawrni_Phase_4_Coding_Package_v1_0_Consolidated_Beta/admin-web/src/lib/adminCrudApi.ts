import { adminApi } from './adminApi';

export const adminCrudApi = {
  customers: () => adminApi.get('/admin/customers'),
  customer: (id: string) => adminApi.get(`/admin/customers/${id}`),
  suspendCustomer: (id: string) => adminApi.post(`/admin/customers/${id}/suspend`, {}),
  reactivateCustomer: (id: string) => adminApi.post(`/admin/customers/${id}/reactivate`, {}),

  providers: (status?: string) => adminApi.get(`/admin/providers${status ? `?status=${status}` : ''}`),
  provider: (id: string) => adminApi.get(`/admin/providers/${id}`),
  suspendProvider: (id: string) => adminApi.post(`/admin/providers/${id}/suspend`, {}),
  reactivateProvider: (id: string) => adminApi.post(`/admin/providers/${id}/reactivate`, {}),

  subscriptions: () => adminApi.get('/admin/subscriptions'),
  assignSubscription: (providerId: string, payload: unknown) => adminApi.post(`/admin/providers/${providerId}/subscriptions`, payload),
  cancelSubscription: (id: string) => adminApi.post(`/admin/subscriptions/${id}/cancel`, {}),
};
