import { adminApi } from './adminApi';

export async function approveProvider(id: number) {
  return adminApi(`/api/v1/admin/providers/${id}/approve`, { method: 'POST' });
}

export async function rejectProvider(id: number, reason?: string) {
  return adminApi(`/api/v1/admin/providers/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
}

export async function approveDelivery(id: number) {
  return adminApi(`/api/v1/admin/deliveries/${id}/approve`, { method: 'POST' });
}

export async function rejectDelivery(id: number, reason?: string) {
  return adminApi(`/api/v1/admin/deliveries/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
}

export async function approveReview(id: number) {
  return adminApi(`/api/v1/admin/reviews/${id}/approve`, { method: 'POST' });
}

export async function rejectReview(id: number, reason?: string) {
  return adminApi(`/api/v1/admin/reviews/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
}

export async function requestProviderReassignment(bookingId: number, newProviderProfileId: number, reason: string) {
  return adminApi(`/api/v1/admin/bookings/${bookingId}/request-provider-reassignment`, {
    method: 'POST',
    body: JSON.stringify({ new_provider_profile_id: newProviderProfileId, reason }),
  });
}
