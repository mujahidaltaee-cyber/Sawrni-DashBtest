import { adminApi } from './adminApi';

export type BetaDashboardSummary = {
  pendingProviders: number;
  pendingDeliveries: number;
  pendingReviews: number;
  openBookings: number;
  providerDebtWarnings: number;
};

export async function fetchBetaDashboardSummary(): Promise<BetaDashboardSummary> {
  const dashboard = await adminApi('/admin/dashboard');
  return {
    pendingProviders: dashboard?.pending_providers ?? 0,
    pendingDeliveries: dashboard?.pending_deliveries ?? 0,
    pendingReviews: dashboard?.pending_reviews ?? 0,
    openBookings: dashboard?.open_bookings ?? 0,
    providerDebtWarnings: dashboard?.provider_debt_warnings ?? 0,
  };
}

export async function fetchAdminTable(path: string) {
  return adminApi(path);
}
