import { apiGet } from './api';

export type StagingStatus = {
  status: string;
  package: string;
  purpose: string;
  checks: Record<string, unknown>;
};

export async function getStagingStatus(): Promise<StagingStatus> {
  return apiGet<StagingStatus>('/staging/status');
}
