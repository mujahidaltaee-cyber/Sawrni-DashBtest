export type AdminSession = {
  token: string;
  user?: {
    id: number;
    name: string;
    role: string;
  };
};

const KEY = 'sawrni_admin_session';

export function saveSession(session: AdminSession) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(KEY, JSON.stringify(session));
}

export function readSession(): AdminSession | null {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try { return JSON.parse(raw) as AdminSession; } catch { return null; }
}

export function readToken(): string | undefined {
  return readSession()?.token;
}

export function clearSession() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(KEY);
}
