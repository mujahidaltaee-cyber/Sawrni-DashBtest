import { readToken } from './auth';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8000/api/v1';

type Method = 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';

async function request(path: string, method: Method, body?: unknown, token?: string) {
  const resolvedToken = token ?? readToken();
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      Accept: 'application/json',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(resolvedToken ? { Authorization: `Bearer ${resolvedToken}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    cache: 'no-store',
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.message ?? `API error ${res.status}`);
  return json;
}

export const apiGet = (path: string, token?: string) => request(path, 'GET', undefined, token);
export const apiPost = (path: string, body: unknown, token?: string) => request(path, 'POST', body, token);
export const apiPatch = (path: string, body: unknown, token?: string) => request(path, 'PATCH', body, token);
export const apiPut = (path: string, body: unknown, token?: string) => request(path, 'PUT', body, token);
export const apiDelete = (path: string, token?: string) => request(path, 'DELETE', undefined, token);
