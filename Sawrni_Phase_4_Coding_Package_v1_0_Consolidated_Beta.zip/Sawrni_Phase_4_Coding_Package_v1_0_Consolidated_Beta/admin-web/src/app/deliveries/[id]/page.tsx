import { AdminProtectedLayout } from '../../../components/AdminProtectedLayout';

export default function DeliveryDetailsPage({ params }: { params: { id: string } }) {
  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Delivery #{params.id}</h1>
      <p className="mt-2 text-slate-600">Approve or reject the final delivery package.</p>
    </AdminProtectedLayout>
  );
}
