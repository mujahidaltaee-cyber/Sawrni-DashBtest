export default function PendingDeliveriesPage() {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Pending Deliveries</h1>
      <p className="text-sm text-slate-600">Review final delivery packages only. Individual photo-by-photo approval is not required.</p>
      <div className="rounded-xl border p-4 text-slate-500">Connect to GET /admin/deliveries/pending.</div>
    </main>
  );
}
