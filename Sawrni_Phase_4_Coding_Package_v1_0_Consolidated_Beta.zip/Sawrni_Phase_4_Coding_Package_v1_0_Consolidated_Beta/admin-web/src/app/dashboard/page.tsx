import AdminProtectedLayout from '../../components/AdminProtectedLayout';

export default function DashboardPage() {
  return (
    <AdminProtectedLayout>
      <main className="p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <p className="text-sm text-slate-600">Sawrni operational overview: bookings, providers, wallets, deliveries, and alerts.</p>
        <div className="grid grid-cols-4 gap-4">
          {['Bookings', 'Pending Providers', 'Pending Deliveries', 'Provider Debt'].map(item => (
            <div key={item} className="rounded-xl border bg-white p-4">
              <div className="text-sm text-slate-500">{item}</div>
              <div className="text-2xl font-semibold">--</div>
            </div>
          ))}
        </div>
      </main>
    </AdminProtectedLayout>
  );
}
