'use client';

import { useEffect, useState } from 'react';
import { getStagingStatus, type StagingStatus } from '@/lib/stagingApi';

export default function StagingVerificationPage() {
  const [status, setStatus] = useState<StagingStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getStagingStatus()
      .then(setStatus)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load staging status'));
  }, []);

  return (
    <main className="p-6">
      <h1 className="text-2xl font-semibold">Staging Verification</h1>
      <p className="mt-2 text-sm opacity-70">Use this page during staging setup only.</p>

      {error && <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">{error}</div>}
      {!status && !error && <div className="mt-4 rounded-lg border p-4">Loading staging checks...</div>}
      {status && (
        <section className="mt-4 rounded-xl border bg-white p-4">
          <div className="font-medium">{status.package}</div>
          <div className="text-sm opacity-70">{status.purpose}</div>
          <pre className="mt-4 overflow-auto rounded-lg bg-slate-950 p-4 text-xs text-white">
            {JSON.stringify(status.checks, null, 2)}
          </pre>
        </section>
      )}
    </main>
  );
}
