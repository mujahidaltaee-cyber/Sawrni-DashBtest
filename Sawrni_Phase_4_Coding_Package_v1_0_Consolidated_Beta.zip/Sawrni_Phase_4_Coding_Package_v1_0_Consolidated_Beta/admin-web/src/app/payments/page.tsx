export default function PaymentsPage() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Payments Review</h1>
      <p className="mt-2 text-sm text-slate-600">
        This page will list deposit confirmations, electronic payment references, cash confirmations, and receipts.
      </p>
      <section className="mt-6 rounded-xl border p-4">
        API target: <code>/api/v1/admin/payments</code>
      </section>
    </main>
  );
}
