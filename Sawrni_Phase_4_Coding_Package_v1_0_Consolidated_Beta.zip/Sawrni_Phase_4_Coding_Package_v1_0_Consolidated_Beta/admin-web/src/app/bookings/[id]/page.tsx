export default function BookingDetailsPage({ params }: { params: { id: string } }) {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Booking #{params.id}</h1>
      <section className="rounded-xl border p-4 space-y-2">
        <h2 className="font-semibold">Operational details</h2>
        <p className="text-sm text-slate-600">Customer, provider, service, payment, wallet, delivery, and status history.</p>
      </section>
    </main>
  );
}
