import { AdminProtectedLayout } from '../../components/AdminProtectedLayout';

export default function BookingsPage() {
  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Bookings</h1>
      <p className="mt-2 text-slate-600">Review bookings, disputes, reassignment requests, and operational status.</p>
    </AdminProtectedLayout>
  );
}
