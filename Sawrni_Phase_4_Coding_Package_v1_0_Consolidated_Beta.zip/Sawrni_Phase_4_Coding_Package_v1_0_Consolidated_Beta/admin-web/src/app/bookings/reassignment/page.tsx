import AdminProtectedLayout from '@/components/AdminProtectedLayout';

export default function BookingReassignmentPage() {
  return (
    <AdminProtectedLayout>
      <main className="p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Provider Reassignment</h1>
        <p className="text-sm text-slate-600">
          Used only when the selected provider cancels. Customer approval is required before reassignment becomes active.
        </p>
      </main>
    </AdminProtectedLayout>
  );
}
