'use client';

import { useEffect, useState } from 'react';
import { AdminProtectedLayout } from '../components/AdminProtectedLayout';
import { adminApi } from '../lib/adminApi';

export default function DashboardPage() {
  const [status, setStatus] = useState<any>(null);

  useEffect(() => {
    adminApi.get('/local-beta/status').then(setStatus).catch(() => setStatus({ status: 'api-not-connected' }));
  }, []);

  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-xl bg-white p-5 shadow-sm"><div className="text-sm text-slate-500">Beta Status</div><div className="mt-2 font-semibold">{status?.status || 'Loading'}</div></div>
        <div className="rounded-xl bg-white p-5 shadow-sm"><div className="text-sm text-slate-500">Commission</div><div className="mt-2 font-semibold">15%</div></div>
        <div className="rounded-xl bg-white p-5 shadow-sm"><div className="text-sm text-slate-500">Debt Limit</div><div className="mt-2 font-semibold">75,000 IQD</div></div>
      </div>
    </AdminProtectedLayout>
  );
}
