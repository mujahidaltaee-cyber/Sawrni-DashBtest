import { AdminProtectedLayout } from '../../components/AdminProtectedLayout';

export default function SubscriptionsPage() {
  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Provider Subscriptions</h1>
      <p className="mt-2 text-slate-600">Manage Basic, Standard, and Premium provider subscriptions.</p>
    </AdminProtectedLayout>
  );
}
