'use client';

import { useState } from 'react';
import { adminApi } from '../../lib/adminApi';
import { adminAuth } from '../../lib/adminAuth';

export default function LoginPage() {
  const [phone, setPhone] = useState('07700000000');
  const [otp, setOtp] = useState('123456');
  const [error, setError] = useState<string | null>(null);

  async function login() {
    try {
      setError(null);
      const data = await adminApi.login(phone, otp);
      adminAuth.setToken(data.token || data.access_token || '');
      window.location.href = '/';
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Login failed');
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-950 p-6">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-xl">
        <h1 className="text-2xl font-bold">Sawrni Admin Login</h1>
        <p className="mt-2 text-sm text-slate-600">Local beta login. Replace OTP flow with production provider later.</p>
        <label className="mt-6 block text-sm font-medium">Phone</label>
        <input className="mt-1 w-full rounded-lg border p-3" value={phone} onChange={e => setPhone(e.target.value)} />
        <label className="mt-4 block text-sm font-medium">OTP</label>
        <input className="mt-1 w-full rounded-lg border p-3" value={otp} onChange={e => setOtp(e.target.value)} />
        {error && <p className="mt-4 text-sm text-red-600">{error}</p>}
        <button onClick={login} className="mt-6 w-full rounded-lg bg-slate-900 p-3 font-semibold text-white">Login</button>
      </div>
    </main>
  );
}
