export default function ServiceCategoriesPage() {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Service Categories</h1>
      <p className="text-sm text-slate-600">Manage photography categories, editing categories, sports, models, and business services.</p>
      <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Add category</button>
      <div className="rounded-xl border p-4 text-slate-500">Connect to GET /admin/service-categories.</div>
    </main>
  );
}
