export default function NotificationsPage() {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Notifications</h1>
      <p className="text-sm text-slate-600">Send in-app notification broadcasts to customers, providers, admins, or all users.</p>
      <div className="grid gap-3 max-w-xl">
        <select className="rounded-lg border p-2"><option>all</option><option>customers</option><option>providers</option><option>admins</option></select>
        <input className="rounded-lg border p-2" placeholder="Arabic title" />
        <textarea className="rounded-lg border p-2" placeholder="Arabic body" />
        <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Send broadcast</button>
      </div>
    </main>
  );
}
