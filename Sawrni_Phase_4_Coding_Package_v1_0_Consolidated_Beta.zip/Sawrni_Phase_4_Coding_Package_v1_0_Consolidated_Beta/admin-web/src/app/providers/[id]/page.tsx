export default function ProviderDetailsPage({ params }: { params: { id: string } }) {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Provider #{params.id}</h1>
      <section className="rounded-xl border p-4">
        <h2 className="font-semibold">Profile review</h2>
        <p className="text-sm text-slate-600">Services, subscription, wallet, debt, portfolio, approval status, and bookings.</p>
      </section>
    </main>
  );
}
