import { AdminProtectedLayout } from '../../components/AdminProtectedLayout';

export default function ProvidersPage() {
  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Providers</h1>
      <p className="mt-2 text-slate-600">Manage photographers, editors, and models after approval.</p>
    </AdminProtectedLayout>
  );
}
