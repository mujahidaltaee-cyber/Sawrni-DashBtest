export default function PendingProvidersPage() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Pending Providers</h1>
      <p className="mt-2 text-sm text-slate-600">
        Providers remain hidden from the public catalog until approved by a super admin/COO permission.
      </p>
      <section className="mt-6 rounded-xl border p-4">
        API target: <code>/api/v1/admin/providers/pending</code>
      </section>
    </main>
  );
}
