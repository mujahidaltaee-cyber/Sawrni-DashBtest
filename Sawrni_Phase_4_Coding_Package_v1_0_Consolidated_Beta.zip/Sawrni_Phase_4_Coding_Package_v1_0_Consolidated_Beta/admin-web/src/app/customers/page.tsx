import { AdminProtectedLayout } from '../../components/AdminProtectedLayout';

export default function CustomersPage() {
  return (
    <AdminProtectedLayout>
      <h1 className="text-2xl font-bold">Customers</h1>
      <p className="mt-2 text-slate-600">List customers, review profile details, suspend or reactivate accounts.</p>
    </AdminProtectedLayout>
  );
}
