export default function BetaVerificationPage() {
  const items = [
    'Backend health endpoint',
    'Admin login token',
    'Pending providers table',
    'Customer booking creation',
    'Fake payment deposit confirmation',
    'Chat unlock after deposit',
    'Delivery approval queue',
    'Wallet commission ledger',
  ];

  return (
    <main className="page-shell">
      <h1>v0.8 Beta Verification</h1>
      <p>Use this page as a visual checklist during local developer verification.</p>
      <div className="card-grid">
        {items.map((item) => (
          <section className="card" key={item}>
            <strong>{item}</strong>
            <p>Status: pending developer run</p>
          </section>
        ))}
      </div>
    </main>
  );
}
