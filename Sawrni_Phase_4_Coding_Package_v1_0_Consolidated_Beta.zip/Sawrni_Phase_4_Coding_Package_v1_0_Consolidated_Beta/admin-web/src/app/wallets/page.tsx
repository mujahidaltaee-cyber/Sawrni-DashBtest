export default function WalletsPage() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Provider Wallets & Debts</h1>
      <p className="mt-2 text-sm text-slate-600">
        Monitor provider balances, commission debt, and the 75,000 IQD suspension threshold.
      </p>
      <section className="mt-6 rounded-xl border p-4">
        API target: <code>/api/v1/admin/wallets</code>
      </section>
    </main>
  );
}
