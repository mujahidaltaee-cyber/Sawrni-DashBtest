export default function AdminPermissionsPage() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Admin Permissions</h1>
      <p className="mt-2 text-sm text-slate-600">
        Super admins can grant and remove operational permissions for each admin account.
      </p>
      <section className="mt-6 rounded-xl border p-4">
        API targets: <code>/api/v1/admin/permissions</code> and <code>/api/v1/admin/permissions/sync</code>
      </section>
    </main>
  );
}
