import AdminProtectedLayout from '@/components/AdminProtectedLayout';

export default function PendingReviewsPage() {
  return (
    <AdminProtectedLayout>
      <main className="p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Pending Reviews</h1>
        <p className="text-sm text-slate-600">
          Internal beta page. Connect to /api/v1/admin/reviews/pending and approve/reject using betaActionsApi.
        </p>
      </main>
    </AdminProtectedLayout>
  );
}
