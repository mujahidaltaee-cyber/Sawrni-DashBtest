<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

if (!function_exists('sawrni_security_rate_limit')) {
    function sawrni_security_rate_limit(string $bucket, string $identifier, int $maxAttempts, int $windowSeconds)
    {
        $key = substr(hash('sha256', $bucket . '|' . $identifier), 0, 96);
        $now = now();
        $record = DB::table('sawrni_api_rate_limits')->where('rate_key', $key)->first();

        if ($record && $record->locked_until && now()->lessThan($record->locked_until)) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'تم تجاوز عدد المحاولات. حاول لاحقاً.',
                'message_en' => 'Too many attempts. Try again later.',
                'retry_after_seconds' => max(1, now()->diffInSeconds($record->locked_until, false)),
                'phase' => '6.7',
            ], 429);
        }

        if (!$record || !$record->window_started_at || now()->diffInSeconds($record->window_started_at) > $windowSeconds) {
            DB::table('sawrni_api_rate_limits')->updateOrInsert(
                ['rate_key' => $key],
                [
                    'bucket' => $bucket,
                    'attempts' => 1,
                    'window_started_at' => $now,
                    'locked_until' => null,
                    'created_at' => $record->created_at ?? $now,
                    'updated_at' => $now,
                ]
            );
            return true;
        }

        $attempts = ((int) $record->attempts) + 1;
        $lockedUntil = $attempts > $maxAttempts ? now()->addSeconds($windowSeconds) : null;

        DB::table('sawrni_api_rate_limits')->where('rate_key', $key)->update([
            'attempts' => $attempts,
            'locked_until' => $lockedUntil,
            'updated_at' => $now,
        ]);

        if ($lockedUntil) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'تم تجاوز عدد المحاولات. حاول لاحقاً.',
                'message_en' => 'Too many attempts. Try again later.',
                'retry_after_seconds' => $windowSeconds,
                'phase' => '6.7',
            ], 429);
        }

        return true;
    }
}

if (!function_exists('sawrni_security_audit')) {
    function sawrni_security_audit(Request $request, string $eventType, ?string $module = null, ?int $itemId = null, string $severity = 'info', array $metadata = []): void
    {
        $token = $request->bearerToken();
        $adminId = null;
        $phone = null;

        if ($token) {
            $session = DB::table('admin_auth_sessions')
                ->where(function ($query) use ($token) {
                    $query->where('token', $token)->orWhere('token_hash', hash('sha256', $token));
                })
                ->whereNull('revoked_at')
                ->first();

            if ($session) {
                $adminId = $session->admin_id;
                $phone = $session->phone;
            }
        }

        DB::table('sawrni_audit_events')->insert([
            'actor_admin_id' => $adminId,
            'actor_phone' => $phone,
            'event_type' => $eventType,
            'module' => $module,
            'item_id' => $itemId,
            'severity' => $severity,
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 2000),
            'metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

if (!function_exists('sawrni_security_admin')) {
    function sawrni_security_admin(Request $request): ?object
    {
        $token = $request->bearerToken();
        if (!$token) {
            return null;
        }

        $session = DB::table('admin_auth_sessions')
            ->where(function ($query) use ($token) {
                $query->where('token', $token)->orWhere('token_hash', hash('sha256', $token));
            })
            ->whereNull('revoked_at')
            ->where(function ($query) {
                $query->whereNull('expires_at')->orWhere('expires_at', '>', now());
            })
            ->first();

        if (!$session) {
            return null;
        }

        $admin = DB::table('sawrni_admin_accounts')
            ->where('phone', $session->phone)
            ->where('status', 'active')
            ->first();

        if (!$admin) {
            return null;
        }

        $permissions = DB::table('sawrni_admin_account_roles as ar')
            ->join('sawrni_admin_role_permissions as rp', 'rp.role_id', '=', 'ar.role_id')
            ->join('sawrni_admin_permissions as p', 'p.id', '=', 'rp.permission_id')
            ->where('ar.admin_account_id', $admin->id)
            ->pluck('p.code')
            ->all();

        $admin->permissions = $permissions;
        $admin->session_id = $session->id;
        $admin->session_token = $token;

        return $admin;
    }
}

if (!function_exists('sawrni_security_has_permission')) {
    function sawrni_security_has_permission(?object $admin, string $permission): bool
    {
        if (!$admin) {
            return false;
        }

        if (!empty($admin->is_owner)) {
            return true;
        }

        return in_array($permission, $admin->permissions ?? [], true);
    }
}

if (!function_exists('sawrni_security_unauthorized')) {
    function sawrni_security_unauthorized(string $messageAr = 'غير مصرح.', string $messageEn = 'Unauthorized.')
    {
        return response()->json([
            'status' => 'error',
            'message_ar' => $messageAr,
            'message_en' => $messageEn,
            'phase' => '6.7',
        ], 401);
    }
}

Route::prefix('/v1/admin-auth/v10')->group(function () {
    Route::get('/config', function () {
        return response()->json([
            'status' => 'ok',
            'phase' => '6.7',
            'backend' => 'laravel-12-runtime',
            'auth_mode' => 'security_baseline',
            'otp_preview_enabled' => true,
            'beta_login_enabled' => true,
            'rate_limits' => [
                'beta_login' => '5 attempts / 10 minutes',
                'request_otp' => '3 attempts / 10 minutes',
                'verify_otp' => '5 attempts / 10 minutes',
            ],
            'security_notice' => 'Preview OTP and beta password must be disabled before production.',
        ]);
    });

    Route::post('/beta-login', function (Request $request) {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $password = (string) $request->input('password', '');
        $identifier = $request->ip() . '|' . $phone;

        $limit = sawrni_security_rate_limit('admin_beta_login', $identifier, 5, 600);
        if ($limit !== true) {
            return $limit;
        }

        if ($phone !== '07000000000' || $password !== 'password') {
            sawrni_security_audit($request, 'admin_beta_login_failed', 'auth', null, 'warning', ['phone' => $phone]);

            return response()->json([
                'status' => 'error',
                'message_ar' => 'بيانات الدخول غير صحيحة.',
                'message_en' => 'Invalid login credentials.',
                'phase' => '6.7',
            ], 422);
        }

        $adminId = DB::table('sawrni_admin_accounts')->where('phone', $phone)->value('id') ?: 1;
        $token = 'phase6-sec-' . Str::random(64);

        DB::table('admin_auth_sessions')->insert([
            'admin_id' => $adminId,
            'phone' => $phone,
            'token' => $token,
            'token_hash' => hash('sha256', $token),
            'mode' => 'security_beta_login',
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 2000),
            'expires_at' => now()->addDays(7),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('sawrni_admin_accounts')->where('id', $adminId)->update([
            'last_login_at' => now(),
            'updated_at' => now(),
        ]);

        sawrni_security_audit($request, 'admin_beta_login_success', 'auth', null, 'info', ['phone' => $phone]);

        return response()->json([
            'status' => 'ok',
            'token' => $token,
            'name' => 'Super Admin',
            'phone' => $phone,
            'role' => 'super_admin',
            'phase' => '6.7',
        ]);
    });

    Route::post('/request-otp', function (Request $request) {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $identifier = $request->ip() . '|' . $phone;

        $limit = sawrni_security_rate_limit('admin_request_otp', $identifier, 3, 600);
        if ($limit !== true) {
            return $limit;
        }

        if (strlen($phone) < 10) {
            sawrni_security_audit($request, 'admin_request_otp_invalid_phone', 'auth', null, 'warning', ['phone' => $phone]);

            return response()->json([
                'status' => 'error',
                'message_ar' => 'رقم الهاتف غير صحيح.',
                'message_en' => 'Invalid phone number.',
                'phase' => '6.7',
            ], 422);
        }

        $otp = '123456';

        DB::table('admin_auth_otps')->insert([
            'phone' => $phone,
            'otp_hash' => Hash::make($otp),
            'purpose' => 'admin_login',
            'channel' => 'preview',
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 2000),
            'status' => 'pending',
            'attempts' => 0,
            'expires_at' => now()->addMinutes(5),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        sawrni_security_audit($request, 'admin_otp_requested', 'auth', null, 'info', ['phone' => $phone, 'channel' => 'preview']);

        return response()->json([
            'status' => 'ok',
            'message_ar' => 'تم إنشاء رمز الدخول التجريبي.',
            'message_en' => 'Preview OTP generated.',
            'otp_preview' => $otp,
            'expires_in_seconds' => 300,
            'phase' => '6.7',
        ]);
    });

    Route::post('/verify-otp', function (Request $request) {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $otp = (string) $request->input('otp', '');
        $identifier = $request->ip() . '|' . $phone;

        $limit = sawrni_security_rate_limit('admin_verify_otp', $identifier, 5, 600);
        if ($limit !== true) {
            return $limit;
        }

        $record = DB::table('admin_auth_otps')
            ->where('phone', $phone)
            ->where('status', 'pending')
            ->whereNull('consumed_at')
            ->where('expires_at', '>', now())
            ->latest('id')
            ->first();

        if (!$record) {
            sawrni_security_audit($request, 'admin_otp_missing_or_expired', 'auth', null, 'warning', ['phone' => $phone]);

            return response()->json([
                'status' => 'error',
                'message_ar' => 'رمز الدخول غير موجود أو منتهي.',
                'message_en' => 'OTP not found or expired.',
                'phase' => '6.7',
            ], 422);
        }

        DB::table('admin_auth_otps')->where('id', $record->id)->update([
            'attempts' => $record->attempts + 1,
            'updated_at' => now(),
        ]);

        if ($record->attempts >= 5 || !Hash::check($otp, $record->otp_hash)) {
            sawrni_security_audit($request, 'admin_otp_invalid', 'auth', null, 'warning', ['phone' => $phone, 'otp_id' => $record->id]);

            return response()->json([
                'status' => 'error',
                'message_ar' => 'رمز الدخول غير صحيح.',
                'message_en' => 'Invalid OTP.',
                'phase' => '6.7',
            ], 422);
        }

        DB::table('admin_auth_otps')->where('id', $record->id)->update([
            'status' => 'consumed',
            'consumed_at' => now(),
            'updated_at' => now(),
        ]);

        $adminId = DB::table('sawrni_admin_accounts')->where('phone', '07000000000')->value('id') ?: 1;
        $token = 'phase6-sec-otp-' . Str::random(64);

        DB::table('admin_auth_sessions')->insert([
            'admin_id' => $adminId,
            'phone' => $phone,
            'token' => $token,
            'token_hash' => hash('sha256', $token),
            'mode' => 'security_otp_preview',
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 2000),
            'expires_at' => now()->addDays(7),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        sawrni_security_audit($request, 'admin_otp_verified', 'auth', null, 'info', ['phone' => $phone]);

        return response()->json([
            'status' => 'ok',
            'token' => $token,
            'name' => 'Super Admin',
            'phone' => $phone,
            'role' => 'super_admin',
            'phase' => '6.7',
        ]);
    });

    Route::post('/logout', function (Request $request) {
        $token = $request->bearerToken() ?: (string) $request->input('token', '');

        if ($token) {
            DB::table('admin_auth_sessions')
                ->where(function ($query) use ($token) {
                    $query->where('token', $token)->orWhere('token_hash', hash('sha256', $token));
                })
                ->update(['revoked_at' => now(), 'updated_at' => now()]);
        }

        sawrni_security_audit($request, 'admin_logout', 'auth', null, 'info');

        return response()->json([
            'status' => 'ok',
            'message_ar' => 'تم تسجيل الخروج.',
            'message_en' => 'Logged out.',
            'phase' => '6.7',
        ]);
    });
});

Route::prefix('/v1/admin-v10')->group(function () {
    Route::post('/{module}/{id}/{action}', function (Request $request, string $module, int $id, string $action) {
        $admin = sawrni_security_admin($request);

        if (!$admin) {
            sawrni_security_audit($request, 'admin_action_unauthorized', $module, $id, 'warning', ['action' => $action]);
            return sawrni_security_unauthorized();
        }

        if (!in_array($action, ['approve', 'reject'], true)) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'الإجراء غير مدعوم.',
                'message_en' => 'Unsupported action.',
                'phase' => '6.7',
            ], 422);
        }

        if ($module === 'bookings' && !sawrni_security_has_permission($admin, 'booking.manage')) {
            return sawrni_security_unauthorized('ليست لديك صلاحية إدارة الحجوزات.', 'Missing booking management permission.');
        }

        if ($module === 'providers') {
            $needed = $action === 'approve' ? 'provider.approve' : 'provider.reject';
            if (!sawrni_security_has_permission($admin, $needed)) {
                return sawrni_security_unauthorized('ليست لديك صلاحية موافقات مزودي الخدمة.', 'Missing provider approval permission.');
            }
        }

        if (!in_array($module, ['bookings', 'providers'], true)) {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'الإجراء غير متاح لهذا القسم حالياً.',
                'message_en' => 'Action is not available for this module yet.',
                'phase' => '6.7',
            ], 422);
        }

        $reason = trim((string) $request->input('reason', ''));
        if ($action === 'reject' && $reason === '') {
            return response()->json([
                'status' => 'error',
                'message_ar' => 'سبب الرفض مطلوب.',
                'message_en' => 'Rejection reason is required.',
                'phase' => '6.7',
            ], 422);
        }

        $newStatus = $action === 'approve' ? 'approved' : 'rejected';

        if ($module === 'bookings') {
            $item = DB::table('sawrni_bookings')->where('id', $id)->first();
            if (!$item) {
                return response()->json(['status' => 'error', 'message_ar' => 'الحجز غير موجود.', 'message_en' => 'Booking not found.', 'phase' => '6.7'], 404);
            }

            DB::table('sawrni_bookings')->where('id', $id)->update(['status' => $newStatus, 'updated_at' => now()]);
            $titleAr = $item->title_ar ?: 'الحجز';
            $titleEn = $item->title_en ?: 'booking';
        } else {
            $item = DB::table('sawrni_provider_profiles')->where('id', $id)->first();
            if (!$item) {
                return response()->json(['status' => 'error', 'message_ar' => 'مزود الخدمة غير موجود.', 'message_en' => 'Provider not found.', 'phase' => '6.7'], 404);
            }

            DB::table('sawrni_provider_profiles')->where('id', $id)->update([
                'approval_status' => $newStatus,
                'approved_at' => $action === 'approve' ? now() : null,
                'approved_by' => $action === 'approve' ? $admin->id : null,
                'updated_at' => now(),
            ]);
            $titleAr = $item->display_name;
            $titleEn = $item->display_name;
        }

        $messageAr = $action === 'approve' ? "تمت الموافقة على {$titleAr}." : "تم رفض {$titleAr}.";
        $messageEn = $action === 'approve' ? "Approved {$titleEn}." : "Rejected {$titleEn}.";

        DB::table('sawrni_admin_action_logs')->insert([
            'module' => $module,
            'item_id' => $id,
            'action' => $action,
            'reason' => $reason ?: null,
            'message_ar' => $messageAr,
            'message_en' => $messageEn,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        sawrni_security_audit($request, "admin_{$action}_{$module}", $module, $id, 'info', [
            'reason' => $reason ?: null,
            'new_status' => $newStatus,
        ]);

        return response()->json([
            'status' => 'ok',
            'item_status' => $newStatus,
            'message_ar' => $messageAr,
            'message_en' => $messageEn,
            'phase' => '6.7',
        ]);
    });
});

Route::prefix('/v1/security')->group(function () {
    Route::get('/baseline', function (Request $request) {
        $admin = sawrni_security_admin($request);
        if (!$admin || !sawrni_security_has_permission($admin, 'security.view')) {
            return sawrni_security_unauthorized();
        }

        return response()->json([
            'status' => 'ok',
            'phase' => '6.7',
            'security_baseline' => [
                'rbac' => 'enabled',
                'audit_events' => DB::table('sawrni_audit_events')->count(),
                'rate_limit_records' => DB::table('sawrni_api_rate_limits')->count(),
                'admin_roles' => DB::table('sawrni_admin_roles')->count(),
                'admin_permissions' => DB::table('sawrni_admin_permissions')->count(),
                'token_hash_column' => true,
                'otp_expiry' => '5 minutes',
                'session_expiry' => '7 days',
                'production_warning' => 'Disable beta password and preview OTP before launch.',
            ],
        ]);
    });

    Route::get('/session-check', function (Request $request) {
        $admin = sawrni_security_admin($request);
        if (!$admin) {
            return sawrni_security_unauthorized();
        }

        return response()->json([
            'status' => 'ok',
            'phase' => '6.7',
            'admin' => [
                'id' => $admin->id,
                'name' => $admin->name,
                'phone' => $admin->phone,
                'is_owner' => (bool) $admin->is_owner,
                'permissions' => $admin->permissions,
            ],
        ]);
    });

    Route::get('/audit-logs', function (Request $request) {
        $admin = sawrni_security_admin($request);
        if (!$admin || !sawrni_security_has_permission($admin, 'audit.view')) {
            return sawrni_security_unauthorized();
        }

        $logs = DB::table('sawrni_audit_events')->orderByDesc('id')->limit(30)->get();

        return response()->json([
            'status' => 'ok',
            'phase' => '6.7',
            'rows' => $logs,
        ]);
    });
});
