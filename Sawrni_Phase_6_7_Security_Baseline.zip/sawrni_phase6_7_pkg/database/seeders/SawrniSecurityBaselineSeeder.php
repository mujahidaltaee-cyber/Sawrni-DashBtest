<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SawrniSecurityBaselineSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        $permissions = [
            ['admin.login', 'تسجيل دخول الإدارة', 'Admin login'],
            ['dashboard.view', 'عرض لوحة التحكم', 'View dashboard'],
            ['provider.approve', 'الموافقة على مزودي الخدمة', 'Approve providers'],
            ['provider.reject', 'رفض مزودي الخدمة', 'Reject providers'],
            ['booking.manage', 'إدارة الحجوزات', 'Manage bookings'],
            ['payment.view', 'عرض المدفوعات', 'View payments'],
            ['wallet.view', 'عرض المحافظ', 'View wallets'],
            ['audit.view', 'عرض سجلات التدقيق', 'View audit logs'],
            ['security.view', 'عرض حالة الأمان', 'View security status'],
        ];

        foreach ($permissions as [$code, $ar, $en]) {
            DB::table('sawrni_admin_permissions')->updateOrInsert(
                ['code' => $code],
                ['name_ar' => $ar, 'name_en' => $en, 'updated_at' => $now, 'created_at' => $now]
            );
        }

        DB::table('sawrni_admin_roles')->updateOrInsert(
            ['code' => 'owner_super_admin'],
            ['name_ar' => 'مالك / مدير أعلى', 'name_en' => 'Owner Super Admin', 'is_system' => true, 'updated_at' => $now, 'created_at' => $now]
        );

        DB::table('sawrni_admin_roles')->updateOrInsert(
            ['code' => 'coo_approval_admin'],
            ['name_ar' => 'صلاحية موافقات COO', 'name_en' => 'COO Approval Admin', 'is_system' => true, 'updated_at' => $now, 'created_at' => $now]
        );

        $ownerRoleId = DB::table('sawrni_admin_roles')->where('code', 'owner_super_admin')->value('id');
        $cooRoleId = DB::table('sawrni_admin_roles')->where('code', 'coo_approval_admin')->value('id');

        $allPermissionIds = DB::table('sawrni_admin_permissions')->pluck('id');
        foreach ($allPermissionIds as $permissionId) {
            DB::table('sawrni_admin_role_permissions')->updateOrInsert(
                ['role_id' => $ownerRoleId, 'permission_id' => $permissionId],
                ['updated_at' => $now, 'created_at' => $now]
            );
        }

        $cooPermissions = ['dashboard.view', 'provider.approve', 'provider.reject', 'booking.manage', 'audit.view'];
        foreach ($cooPermissions as $code) {
            $permissionId = DB::table('sawrni_admin_permissions')->where('code', $code)->value('id');
            DB::table('sawrni_admin_role_permissions')->updateOrInsert(
                ['role_id' => $cooRoleId, 'permission_id' => $permissionId],
                ['updated_at' => $now, 'created_at' => $now]
            );
        }

        DB::table('sawrni_admin_accounts')->updateOrInsert(
            ['phone' => '07000000000'],
            [
                'name' => 'Super Admin',
                'email' => null,
                'status' => 'active',
                'is_owner' => true,
                'updated_at' => $now,
                'created_at' => $now,
            ]
        );

        $adminId = DB::table('sawrni_admin_accounts')->where('phone', '07000000000')->value('id');
        DB::table('sawrni_admin_account_roles')->updateOrInsert(
            ['admin_account_id' => $adminId, 'role_id' => $ownerRoleId],
            ['updated_at' => $now, 'created_at' => $now]
        );

        DB::table('sawrni_audit_events')->insert([
            'actor_admin_id' => $adminId,
            'actor_phone' => '07000000000',
            'event_type' => 'security_baseline_seeded',
            'module' => 'security',
            'item_id' => null,
            'severity' => 'info',
            'ip_address' => null,
            'user_agent' => null,
            'metadata' => json_encode([
                'phase' => '6.7',
                'message' => 'Security baseline roles, permissions, audit, and rate-limit tables seeded.',
            ]),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }
}
