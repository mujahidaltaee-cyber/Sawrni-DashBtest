<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('sawrni_admin_accounts')) {
            Schema::create('sawrni_admin_accounts', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('phone', 32)->unique();
                $table->string('email')->nullable();
                $table->string('status', 40)->default('active')->index();
                $table->boolean('is_owner')->default(false);
                $table->timestamp('last_login_at')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_admin_roles')) {
            Schema::create('sawrni_admin_roles', function (Blueprint $table) {
                $table->id();
                $table->string('code', 80)->unique();
                $table->string('name_ar')->nullable();
                $table->string('name_en')->nullable();
                $table->boolean('is_system')->default(false);
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_admin_permissions')) {
            Schema::create('sawrni_admin_permissions', function (Blueprint $table) {
                $table->id();
                $table->string('code', 120)->unique();
                $table->string('name_ar')->nullable();
                $table->string('name_en')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_admin_role_permissions')) {
            Schema::create('sawrni_admin_role_permissions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('role_id')->index();
                $table->unsignedBigInteger('permission_id')->index();
                $table->unique(['role_id', 'permission_id']);
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_admin_account_roles')) {
            Schema::create('sawrni_admin_account_roles', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('admin_account_id')->index();
                $table->unsignedBigInteger('role_id')->index();
                $table->unique(['admin_account_id', 'role_id']);
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_audit_events')) {
            Schema::create('sawrni_audit_events', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('actor_admin_id')->nullable()->index();
                $table->string('actor_phone', 32)->nullable()->index();
                $table->string('event_type', 120)->index();
                $table->string('module', 80)->nullable()->index();
                $table->unsignedBigInteger('item_id')->nullable()->index();
                $table->string('severity', 40)->default('info')->index();
                $table->string('ip_address', 80)->nullable();
                $table->text('user_agent')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('sawrni_api_rate_limits')) {
            Schema::create('sawrni_api_rate_limits', function (Blueprint $table) {
                $table->id();
                $table->string('rate_key', 160)->unique();
                $table->string('bucket', 80)->index();
                $table->unsignedInteger('attempts')->default(0);
                $table->timestamp('window_started_at')->nullable();
                $table->timestamp('locked_until')->nullable();
                $table->timestamps();
            });
        }

        if (Schema::hasTable('admin_auth_sessions') && !Schema::hasColumn('admin_auth_sessions', 'token_hash')) {
            Schema::table('admin_auth_sessions', function (Blueprint $table) {
                $table->string('token_hash', 128)->nullable()->index()->after('token');
                $table->string('ip_address', 80)->nullable()->after('mode');
                $table->text('user_agent')->nullable()->after('ip_address');
            });
        }

        if (Schema::hasTable('admin_auth_otps') && !Schema::hasColumn('admin_auth_otps', 'ip_address')) {
            Schema::table('admin_auth_otps', function (Blueprint $table) {
                $table->string('ip_address', 80)->nullable()->after('channel');
                $table->text('user_agent')->nullable()->after('ip_address');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('sawrni_api_rate_limits');
        Schema::dropIfExists('sawrni_audit_events');
        Schema::dropIfExists('sawrni_admin_account_roles');
        Schema::dropIfExists('sawrni_admin_role_permissions');
        Schema::dropIfExists('sawrni_admin_permissions');
        Schema::dropIfExists('sawrni_admin_roles');
        Schema::dropIfExists('sawrni_admin_accounts');
    }
};
