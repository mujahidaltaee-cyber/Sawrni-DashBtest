# Sawrni Phase 6.7 Security Baseline Checklist

Status target: development security gate, not full production hardening.

## Implemented in this phase

- Admin RBAC foundation: roles, permissions, admin account roles.
- Owner/super-admin seed account for testing.
- COO-style approval role foundation.
- Audit events table for sensitive actions.
- Rate-limit table for login and OTP flows.
- Token hash column added to admin sessions while keeping development compatibility.
- OTP metadata: IP address and user-agent tracking.
- Secured auth endpoints with rate limiting and audit logging.
- Secured admin action endpoint for bookings/providers with permission checks.
- Rejection reason enforced for reject actions.
- Security status endpoint.
- Session check endpoint.
- Audit log endpoint.
- Production environment example without real secrets.

## Must remain private

- Provider ranking and internal scoring.
- Provider approval logic.
- Subscription/commission/debt policy details beyond what is needed for UI display.
- Fraud and suspicious-behavior detection rules.
- Operational analytics, expansion strategy, and internal admin workflows.

## Production blockers before launch

- Disable beta password login.
- Disable OTP preview.
- Replace preview OTP with real SMS/WhatsApp OTP provider.
- Store production session tokens as hashes only.
- Restrict CORS to official Sawrni domains only.
- Enable HTTPS only.
- Move files to private storage with signed URLs.
- Add rate limits at web server/proxy level.
- Add backup and restore test.
- Add payment webhook signature verification.
- Add security monitoring and alerting.
- Register trademarks and complete legal documents.

## Marketplace anti-bypass requirements

- Hide customer/provider contact details before paid or confirmed booking.
- Enforce anti-circumvention in Terms and provider agreement.
- Detect suspicious repeated cancellations, phone sharing, and abnormal access patterns.
- Rate limit public provider/model browsing APIs.
- Block scraping of provider lists, portfolios, phone numbers, and model grids.

## Current known development exceptions

- Beta login remains enabled for testing only.
- OTP preview remains enabled for testing only.
- Some routes are closure-based for speed during Phase 6 and should later be moved to controllers/middleware.
