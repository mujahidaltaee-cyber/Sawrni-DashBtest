#!/usr/bin/env bash
set -euo pipefail

if [ ! -f artisan ]; then
  echo "ERROR: Run this inside backend-runtime-laravel where artisan exists."
  exit 1
fi

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT_ROOT="$(cd ../.. && pwd)"

mkdir -p database/migrations database/seeders routes docs env
mkdir -p "$PROJECT_ROOT/_verified_builds"

cp "$PKG_DIR/database/migrations/2026_06_25_000004_create_sawrni_security_baseline_tables.php" database/migrations/
cp "$PKG_DIR/database/seeders/SawrniSecurityBaselineSeeder.php" database/seeders/
cp "$PKG_DIR/routes/sawrni_phase6_security.php" routes/
cp "$PKG_DIR/docs/SAWRNI_PHASE_6_7_SECURITY_CHECKLIST.md" docs/
cp "$PKG_DIR/env/.env.production.example" .env.production.example

cat > routes/sawrni_phase6_api.php <<'PHP'
<?php

require __DIR__ . '/sawrni_phase6_health.php';
require __DIR__ . '/sawrni_phase6_admin_core.php';
require __DIR__ . '/sawrni_phase6_security.php';
PHP

python3 - <<'PY'
from pathlib import Path
p = Path('bootstrap/app.php')
text = p.read_text()
old = "api: __DIR__.'/../routes/sawrni_phase6_health.php',"
new = "api: __DIR__.'/../routes/sawrni_phase6_api.php',"
if old in text:
    text = text.replace(old, new)
elif "api: __DIR__.'/../routes/sawrni_phase6_api.php'," not in text:
    text = text.replace(
        "web: __DIR__.'/../routes/web.php',",
        "web: __DIR__.'/../routes/web.php',\n        api: __DIR__.'/../routes/sawrni_phase6_api.php',"
    )
p.write_text(text)
print('Phase 6.7 API wrapper registered')
PY

php artisan optimize:clear
php artisan route:clear
php artisan config:clear
php artisan migrate --force
php artisan db:seed --class=SawrniSecurityBaselineSeeder --force
php artisan optimize:clear

cat > "$PROJECT_ROOT/_verified_builds/smoke_test_phase6_7_security.sh" <<'EOF_SMOKE'
#!/usr/bin/env bash
set -euo pipefail

BACKEND="http://127.0.0.1:8010/api/v1"

echo "Testing health..."
curl -fsS "$BACKEND/health" >/dev/null

echo "Testing Phase 6.7 auth config..."
curl -fsS "$BACKEND/admin-auth/v10/config" | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; print('auth config ok')"

echo "Testing beta login..."
TOKEN=$(curl -fsS -X POST "$BACKEND/admin-auth/v10/beta-login" \
  -H "Content-Type: application/json" \
  -d '{"phone":"07000000000","password":"password"}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; print(d['token'])")

echo "Testing session check..."
curl -fsS "$BACKEND/security/session-check" \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; assert d['admin']['is_owner'] is True; print('session ok')"

echo "Testing security baseline..."
curl -fsS "$BACKEND/security/baseline" \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; print('baseline ok')"

echo "Testing unauthorized overview should fail..."
HTTP_CODE=$(curl -s -o /tmp/sawrni_unauth.json -w "%{http_code}" "$BACKEND/admin-v10/overview")
if [ "$HTTP_CODE" != "401" ]; then
  echo "Expected 401 for unauthorized overview, got $HTTP_CODE"
  cat /tmp/sawrni_unauth.json
  exit 1
fi

echo "Testing provider reject requires reason..."
HTTP_CODE=$(curl -s -o /tmp/sawrni_reject_no_reason.json -w "%{http_code}" \
  -X POST "$BACKEND/admin-v10/providers/1/reject" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{}')
if [ "$HTTP_CODE" != "422" ]; then
  echo "Expected 422 for rejection without reason, got $HTTP_CODE"
  cat /tmp/sawrni_reject_no_reason.json
  exit 1
fi

echo "Testing secured provider reject..."
curl -fsS -X POST "$BACKEND/admin-v10/providers/1/reject" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"reason":"Phase 6.7 security smoke test"}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; assert d['item_status']=='rejected'; print('provider reject ok')"

echo "Testing audit logs..."
curl -fsS "$BACKEND/security/audit-logs" \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['phase']=='6.7'; assert len(d['rows']) > 0; print('audit ok')"

echo "PASS: Phase 6.7 security baseline verified."
EOF_SMOKE

chmod +x "$PROJECT_ROOT/_verified_builds/smoke_test_phase6_7_security.sh"

echo "Phase 6.7 security baseline applied."
echo "Restart Laravel on port 8010, then run:"
echo "bash $PROJECT_ROOT/_verified_builds/smoke_test_phase6_7_security.sh"
