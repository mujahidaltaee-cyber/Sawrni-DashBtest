# صورني Phase 6.7 — أساس الأمان وحماية الملكية

هذه الحزمة تضيف بوابة أمان قبل الاستمرار في تطوير المميزات.

تضيف:
- جداول صلاحيات وأدوار الإدارة
- حسابات الإدارة وربطها بالأدوار
- سجل تدقيق Audit Events
- Rate limiting لتسجيل الدخول و OTP
- تحسين endpoints تسجيل دخول الإدارة
- حماية إجراءات الموافقة والرفض للحجوزات والمزودين
- endpoints لفحص حالة الأمان والجلسة وسجلات التدقيق
- ملف env للإنتاج بدون أسرار حقيقية
- قائمة فحص أمنية
- smoke test

طبّقها من داخل Laravel runtime:

```bash
cd /workspaces/Sawrni-DashBtest/_sawrni_phase6/backend-runtime-laravel
bash /workspaces/Sawrni-DashBtest/_phase6_7/sawrni_phase6_7_pkg/scripts/apply_phase6_7_security.sh
```

ثم أعد تشغيل Laravel على port 8010 وشغّل:

```bash
bash /workspaces/Sawrni-DashBtest/_verified_builds/smoke_test_phase6_7_security.sh
```
