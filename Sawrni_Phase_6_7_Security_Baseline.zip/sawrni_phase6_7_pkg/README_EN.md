# Sawrni Phase 6.7 — Security Baseline + IP Protection Gate

This package applies the Phase 6.7 security baseline to the Laravel 12 runtime.

It adds:
- RBAC tables
- admin accounts, roles, permissions
- audit events
- rate-limit records
- stronger admin auth endpoints
- permission-checked booking/provider actions
- security status endpoints
- production env example
- security checklist
- smoke test

Apply from the Laravel runtime path:

```bash
cd /workspaces/Sawrni-DashBtest/_sawrni_phase6/backend-runtime-laravel
bash /workspaces/Sawrni-DashBtest/_phase6_7/sawrni_phase6_7_pkg/scripts/apply_phase6_7_security.sh
```

Then restart Laravel on port 8010 and run:

```bash
bash /workspaces/Sawrni-DashBtest/_verified_builds/smoke_test_phase6_7_security.sh
```
