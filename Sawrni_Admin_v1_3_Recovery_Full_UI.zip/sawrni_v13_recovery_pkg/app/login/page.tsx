'use client';

import { useEffect, useState } from 'react';

export default function LoginPage() {
  const [mode, setMode] = useState<'beta' | 'otp'>('beta');
  const [phone, setPhone] = useState('07000000000');
  const [password, setPassword] = useState('password');
  const [otp, setOtp] = useState('123456');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    document.documentElement.lang = 'ar';
    document.documentElement.dir = 'rtl';
  }, []);

  async function api(path: string, body: any) {
    const res = await fetch(`/api/backend/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
      cache: 'no-store',
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message_ar || data.message_en || data.message || 'Request failed');
    }

    return data;
  }

  async function betaLogin() {
    try {
      setLoading(true);
      setMessage('');
      const data = await api('admin-auth/v10/beta-login', { phone, password });
      localStorage.setItem('sawrni_admin_token', data.token);
      localStorage.setItem('sawrni_admin_user', JSON.stringify(data.user || { phone }));
      window.location.href = '/dashboard';
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  async function requestOtp() {
    try {
      setLoading(true);
      setMessage('');
      const data = await api('admin-auth/v10/request-otp', { phone });
      setMessage(data.message_ar || data.message_en || 'تم إرسال الرمز التجريبي.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'OTP request failed');
    } finally {
      setLoading(false);
    }
  }

  async function verifyOtp() {
    try {
      setLoading(true);
      setMessage('');
      const data = await api('admin-auth/v10/verify-otp', { phone, otp });
      localStorage.setItem('sawrni_admin_token', data.token);
      localStorage.setItem('sawrni_admin_user', JSON.stringify(data.user || { phone }));
      window.location.href = '/dashboard';
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'OTP failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="screen">
      <section className="card">
        <div className="brand">
          <div>
            <span>SAWRNI ADMIN</span>
            <h1>دخول إدارة صورني</h1>
            <p>واجهة v1.3 Recovery متصلة بباكند الاختبار.</p>
          </div>
          <div className="logo">ص</div>
        </div>

        <div className="tabs">
          <button disabled={loading} onClick={() => setMode('beta')} className={mode === 'beta' ? 'active' : ''}>دخول تجريبي</button>
          <button disabled={loading} onClick={() => setMode('otp')} className={mode === 'otp' ? 'active' : ''}>OTP</button>
        </div>

        <label>رقم الهاتف</label>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} />

        {mode === 'beta' ? (
          <>
            <label>كلمة المرور</label>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" />
            <button disabled={loading} className="main" onClick={betaLogin}>{loading ? '...' : 'تسجيل الدخول'}</button>
          </>
        ) : (
          <>
            <button disabled={loading} className="outline" onClick={requestOtp}>{loading ? '...' : 'طلب الرمز'}</button>
            <label>OTP</label>
            <input value={otp} onChange={(e) => setOtp(e.target.value)} />
            <button disabled={loading} className="main" onClick={verifyOtp}>{loading ? '...' : 'تأكيد الرمز'}</button>
          </>
        )}

        {message ? <div className="msg">{message}</div> : null}
      </section>

      <style jsx>{`
        .screen { min-height: 100vh; display: grid; place-items: center; background: radial-gradient(circle at top right, #1b2b52, #050b18 60%); padding: 22px; box-sizing: border-box; }
        .card { width: min(540px, 94vw); background: rgba(255,255,255,.98); padding: 34px; border-radius: 30px; box-shadow: 0 30px 90px rgba(0,0,0,.35); }
        .brand { display: flex; justify-content: space-between; align-items: center; gap: 18px; }
        span { color: #522e91; font-weight: 900; letter-spacing: .12em; font-size: 12px; }
        h1 { margin: 8px 0 0; font-size: 32px; color: #071326; }
        p { margin: 10px 0 0; color: #64748b; line-height: 1.7; }
        .logo { width: 62px; height: 62px; border-radius: 20px; background: linear-gradient(135deg, #522e91, #d9a441); color: white; display: grid; place-items: center; font-weight: 900; font-size: 22px; flex: 0 0 auto; }
        .tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 28px 0 18px; }
        button { border: 0; border-radius: 15px; padding: 15px; font-weight: 900; font-family: inherit; cursor: pointer; }
        button:disabled { opacity: .65; cursor: not-allowed; }
        .tabs button { background: #f1f5f9; color: #071326; }
        .tabs .active { background: #071326; color: white; }
        label { display: block; margin: 15px 0 8px; font-weight: 900; color: #071326; }
        input { width: 100%; box-sizing: border-box; border: 1px solid #cbd5e1; border-radius: 15px; padding: 15px; font-size: 17px; }
        .main { width: 100%; margin-top: 20px; background: #071326; color: white; }
        .outline { width: 100%; margin-top: 16px; background: #f5f3ff; color: #522e91; border: 1px solid #522e91; }
        .msg { margin-top: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 15px; padding: 14px; color: #334155; line-height: 1.7; }
      `}</style>
    </main>
  );
}
