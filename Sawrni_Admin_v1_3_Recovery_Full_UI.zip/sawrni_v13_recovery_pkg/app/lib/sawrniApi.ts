export async function sawrniApi(path: string, options: RequestInit = {}) {
  const token = typeof window !== 'undefined' ? localStorage.getItem('sawrni_admin_token') : '';

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };

  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`/api/backend/${path.replace(/^\//, '')}`, {
    ...options,
    headers,
    cache: 'no-store',
  });

  const text = await res.text();
  let data: any = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }

  if (!res.ok) {
    const message = data?.message_ar || data?.message_en || data?.message || `API error ${res.status}`;
    throw new Error(message);
  }

  return data;
}
