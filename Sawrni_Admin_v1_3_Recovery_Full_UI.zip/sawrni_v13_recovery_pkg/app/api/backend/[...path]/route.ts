import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

const BACKEND = process.env.SAWRNI_BACKEND_BASE || 'http://127.0.0.1:8000/api/v1';
const TIMEOUT_MS = 15000;

async function proxy(req: NextRequest, ctx: { params: { path: string[] } }) {
  const path = ctx.params.path.join('/');
  const url = `${BACKEND.replace(/\/$/, '')}/${path}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const body = req.method === 'GET' || req.method === 'HEAD' ? undefined : await req.text();
    const authorization = req.headers.get('authorization');

    const headers: Record<string, string> = {
      'Content-Type': req.headers.get('content-type') || 'application/json',
      Accept: 'application/json',
    };

    if (authorization) headers.Authorization = authorization;

    const res = await fetch(url, {
      method: req.method,
      headers,
      body,
      cache: 'no-store',
      signal: controller.signal,
    });

    const text = await res.text();

    return new NextResponse(text, {
      status: res.status,
      headers: {
        'Content-Type': res.headers.get('content-type') || 'application/json',
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Backend proxy failed';
    return NextResponse.json(
      {
        status: 'error',
        message_en: 'Backend proxy failed',
        message_ar: 'تعذر الاتصال بالباكند',
        detail: message,
        backend: BACKEND,
      },
      { status: 502 }
    );
  } finally {
    clearTimeout(timer);
  }
}

export async function GET(req: NextRequest, ctx: { params: { path: string[] } }) {
  return proxy(req, ctx);
}

export async function POST(req: NextRequest, ctx: { params: { path: string[] } }) {
  return proxy(req, ctx);
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204 });
}
