'use client';

import { useEffect, useMemo, useState } from 'react';
import { sawrniApi } from '../lib/sawrniApi';

type Lang = 'ar' | 'en';
type ModuleKey = 'bookings' | 'providers' | 'payments' | 'wallets' | 'reviews' | 'delivery';

type Stat = { value: string; label_ar?: string; label_en?: string };
type Row = {
  id: number;
  module?: string;
  item_id?: number;
  title_ar?: string;
  title_en?: string;
  title?: string;
  party?: string;
  phone?: string;
  amount?: string;
  status?: string;
  notes?: string;
  created_at?: string;
};
type LogItem = {
  id?: number;
  module?: string;
  item_id?: number;
  action?: string;
  reason?: string;
  message_ar?: string;
  message_en?: string;
  created_at?: string;
};

type Toast = { type: 'ok' | 'error'; text: string } | null;

const modules: { key: ModuleKey; ar: string; en: string }[] = [
  { key: 'bookings', ar: 'الحجوزات', en: 'Bookings' },
  { key: 'providers', ar: 'مزودو الخدمة', en: 'Providers' },
  { key: 'payments', ar: 'المدفوعات', en: 'Payments' },
  { key: 'wallets', ar: 'المحافظ', en: 'Wallets' },
  { key: 'reviews', ar: 'التقييمات', en: 'Reviews' },
  { key: 'delivery', ar: 'ملفات التسليم', en: 'Delivery Files' },
];

const labels = {
  ar: {
    title: 'مركز تحكم إدارة صورني',
    subtitle: 'لوحة v1.3 Recovery متصلة بواجهة اختبار قابلة لاحقاً للربط مع Laravel الحقيقي.',
    connected: 'الـ API متصل',
    loaded: 'تم تحميل البيانات من باكند الاختبار.',
    refresh: 'تحديث',
    logout: 'تسجيل الخروج',
    switchLang: 'English',
    search: 'بحث',
    searchPlaceholder: 'بحث بالاسم، الهاتف، الحالة...',
    all: 'الكل',
    activeSection: 'القسم الحالي',
    approve: 'موافقة',
    reject: 'رفض',
    view: 'عرض',
    latestActions: 'آخر العمليات',
    confirmApprove: 'تأكيد الموافقة',
    confirmReject: 'تأكيد الرفض',
    confirmApproveText: 'هل تريد تأكيد الموافقة على هذا العنصر؟',
    confirmRejectText: 'هل تريد تأكيد رفض هذا العنصر؟',
    reason: 'اكتب سبب الرفض',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    close: 'إغلاق',
    apiError: 'تعذر الاتصال بالـ API',
    empty: 'لا توجد نتائج مطابقة حالياً.',
    details: 'تفاصيل العنصر',
    reasonRequired: 'سبب الرفض مطلوب.',
  },
  en: {
    title: 'Sawrni Admin Control Center',
    subtitle: 'v1.3 Recovery dashboard connected to the test backend and ready for later Laravel integration.',
    connected: 'API connected',
    loaded: 'Data loaded from test backend.',
    refresh: 'Refresh',
    logout: 'Logout',
    switchLang: 'العربية',
    search: 'Search',
    searchPlaceholder: 'Search name, phone, status...',
    all: 'All',
    activeSection: 'Active section',
    approve: 'Approve',
    reject: 'Reject',
    view: 'View',
    latestActions: 'Latest actions',
    confirmApprove: 'Confirm approval',
    confirmReject: 'Confirm rejection',
    confirmApproveText: 'Do you want to approve this item?',
    confirmRejectText: 'Do you want to reject this item?',
    reason: 'Write rejection reason',
    cancel: 'Cancel',
    confirm: 'Confirm',
    close: 'Close',
    apiError: 'API connection failed',
    empty: 'No matching results right now.',
    details: 'Item details',
    reasonRequired: 'Rejection reason is required.',
  },
};

function titleFor(row: Row, lang: Lang) {
  return lang === 'ar'
    ? row.title_ar || row.title || row.title_en || `SWR-${row.id}`
    : row.title_en || row.title || row.title_ar || `SWR-${row.id}`;
}

function logText(log: LogItem | string, lang: Lang) {
  if (typeof log === 'string') return log;
  return lang === 'ar'
    ? log.message_ar || log.message_en || `${log.action || 'action'} #${log.item_id || log.id || ''}`
    : log.message_en || log.message_ar || `${log.action || 'action'} #${log.item_id || log.id || ''}`;
}

export default function DashboardPage() {
  const [lang, setLang] = useState<Lang>('ar');
  const [active, setActive] = useState<ModuleKey>('bookings');
  const [stats, setStats] = useState<Stat[]>([]);
  const [rows, setRows] = useState<Row[]>([]);
  const [logs, setLogs] = useState<(LogItem | string)[]>([]);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [message, setMessage] = useState('');
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Row | null>(null);
  const [pendingAction, setPendingAction] = useState<'approve' | 'reject' | null>(null);
  const [reason, setReason] = useState('');
  const [toast, setToast] = useState<Toast>(null);

  const t = labels[lang];

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    const token = localStorage.getItem('sawrni_admin_token');
    if (!token) {
      window.location.href = '/login';
      return;
    }
    loadOverview();
    loadModule('bookings');
  }, []);

  function notify(type: 'ok' | 'error', text: string) {
    setToast({ type, text });
    setTimeout(() => setToast(null), 2800);
  }

  async function loadOverview() {
    try {
      setLoading(true);
      const data = await sawrniApi('admin-v10/overview');
      setStats(data.stats || []);
      setLogs(data.logs || data.latest_actions || []);
      setConnected(true);
      setMessage(t.loaded);
    } catch (error) {
      setConnected(false);
      const msg = error instanceof Error ? error.message : t.apiError;
      setMessage(msg);
      notify('error', msg);
    } finally {
      setLoading(false);
    }
  }

  async function loadModule(module: ModuleKey) {
    try {
      setLoading(true);
      setActive(module);
      const data = await sawrniApi(`admin-v10/${module}`);
      setRows(data.rows || []);
      setConnected(true);
      setMessage(t.loaded);
    } catch (error) {
      setConnected(false);
      setRows([]);
      const msg = error instanceof Error ? error.message : t.apiError;
      setMessage(msg);
      notify('error', msg);
    } finally {
      setLoading(false);
    }
  }

  async function refreshAll() {
    await loadOverview();
    await loadModule(active);
    notify('ok', t.loaded);
  }

  async function runAction() {
    if (!selected || !pendingAction) return;

    if (pendingAction === 'reject' && !reason.trim()) {
      notify('error', t.reasonRequired);
      return;
    }

    try {
      setLoading(true);
      const data = await sawrniApi(`admin-v10/${active}/${selected.id}/${pendingAction}`, {
        method: 'POST',
        body: JSON.stringify({ reason }),
      });

      const nextStatus = pendingAction === 'approve' ? 'approved' : 'rejected';
      setRows((old) => old.map((row) => (row.id === selected.id ? { ...row, status: nextStatus } : row)));

      const msg = lang === 'ar' ? data.message_ar || 'تم تنفيذ العملية.' : data.message_en || 'Action completed.';
      setMessage(msg);
      notify('ok', msg);
      setSelected(null);
      setPendingAction(null);
      setReason('');
      await loadOverview();
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Action failed';
      setMessage(msg);
      notify('error', msg);
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem('sawrni_admin_token');
    localStorage.removeItem('sawrni_admin_user');
    window.location.href = '/login';
  }

  const activeModule = modules.find((m) => m.key === active);
  const filteredRows = useMemo(() => {
    return rows.filter((row) => {
      const text = JSON.stringify(row).toLowerCase();
      const queryOk = !query || text.includes(query.toLowerCase());
      const statusOk = statusFilter === 'all' || row.status === statusFilter;
      return queryOk && statusOk;
    });
  }, [rows, query, statusFilter]);

  return (
    <main className="screen" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      {toast ? <div className={`toast ${toast.type}`}>{toast.text}</div> : null}

      <aside className="sidebar">
        <div className="brand">
          <div>
            <h2>Sawrni</h2>
            <p>Admin v1.3 Recovery</p>
          </div>
          <div className="logo">ص</div>
        </div>

        <nav>
          {modules.map((m) => (
            <button key={m.key} className={active === m.key ? 'nav active' : 'nav'} onClick={() => loadModule(m.key)} disabled={loading}>
              {lang === 'ar' ? m.ar : m.en}
            </button>
          ))}
        </nav>
      </aside>

      <section className="content">
        <header className="hero">
          <div className="heroText">
            <h1>{t.title}</h1>
            <p>{t.subtitle}</p>
          </div>
          <div className="topActions">
            <button className="white" onClick={logout}>{t.logout}</button>
            <button className="purple" disabled={loading} onClick={refreshAll}>{loading ? '...' : t.refresh}</button>
            <button className="gold" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{t.switchLang}</button>
          </div>
        </header>

        <div className={connected ? 'notice good' : 'notice bad'}>
          <strong>{connected ? t.connected : t.apiError}:</strong> {message}
        </div>

        <section className="stats">
          {stats.map((s, i) => (
            <article className="stat" key={i}>
              <strong>{s.value}</strong>
              <span>{lang === 'ar' ? s.label_ar || s.label_en : s.label_en || s.label_ar}</span>
            </article>
          ))}
        </section>

        <section className="panel">
          <div className="panelHead">
            <div>
              <span>{t.activeSection}</span>
              <h2>{lang === 'ar' ? activeModule?.ar : activeModule?.en}</h2>
            </div>
            <div className="filters">
              <button className="purple" disabled={loading} onClick={() => loadModule(active)}>{loading ? '...' : t.search}</button>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="all">{t.all}</option>
                <option value="pending">pending</option>
                <option value="approved">approved</option>
                <option value="rejected">rejected</option>
                <option value="confirmed">confirmed</option>
              </select>
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t.searchPlaceholder} />
            </div>
          </div>

          <div className="rows">
            {filteredRows.length === 0 ? <div className="empty">{t.empty}</div> : null}
            {filteredRows.map((row) => (
              <article className="row" key={row.id}>
                <div className="rowText">
                  <h3>{titleFor(row, lang)}</h3>
                  <p>
                    SWR-{row.id}
                    {row.party ? ` · ${row.party}` : ''}
                    {row.phone ? ` · ${row.phone}` : ''}
                    {row.amount ? ` · ${row.amount}` : ''}
                    {' '}
                    <span className={`badge ${row.status || 'pending'}`}>{row.status || 'pending'}</span>
                  </p>
                  {row.notes ? <p className="notes">{row.notes}</p> : null}
                </div>

                <div className="rowActions">
                  <button className="small" onClick={() => setSelected(row)}>{t.view}</button>
                  <button className="ok" onClick={() => { setSelected(row); setPendingAction('approve'); }}>{t.approve}</button>
                  <button className="danger" onClick={() => { setSelected(row); setPendingAction('reject'); }}>{t.reject}</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel latest">
          <h2>{t.latestActions}</h2>
          <div className="logList">
            {logs.slice(0, 10).map((log, i) => <p key={i}>{logText(log, lang)}</p>)}
          </div>
        </section>
      </section>

      {selected && !pendingAction ? (
        <div className="modalLayer">
          <div className="modal">
            <span className="modalKicker">{t.details}</span>
            <h2>{titleFor(selected, lang)}</h2>
            <div className="detailGrid">
              {Object.entries(selected).map(([key, value]) => (
                <div key={key}>
                  <small>{key}</small>
                  <strong>{String(value ?? '-')}</strong>
                </div>
              ))}
            </div>
            <button className="purple wide" onClick={() => setSelected(null)}>{t.close}</button>
          </div>
        </div>
      ) : null}

      {selected && pendingAction ? (
        <div className="modalLayer">
          <div className="modal">
            <span className="modalKicker">Sawrni Action</span>
            <h2>{pendingAction === 'approve' ? t.confirmApprove : t.confirmReject}</h2>
            <p>{pendingAction === 'approve' ? t.confirmApproveText : t.confirmRejectText}</p>
            <div className="targetBox">{titleFor(selected, lang)}</div>
            {pendingAction === 'reject' ? <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder={t.reason} /> : null}
            <div className="modalActions">
              <button className="white bordered" onClick={() => { setSelected(null); setPendingAction(null); setReason(''); }}>{t.cancel}</button>
              <button className={pendingAction === 'approve' ? 'ok' : 'danger'} disabled={loading} onClick={runAction}>{loading ? '...' : t.confirm}</button>
            </div>
          </div>
        </div>
      ) : null}

      <style jsx>{`
        .screen { min-height: 100vh; background: #f8fafc; color: #071326; }
        .toast { position: fixed; top: 18px; left: 50%; transform: translateX(-50%); z-index: 200; min-width: min(420px, 90vw); padding: 15px 18px; border-radius: 16px; box-shadow: 0 18px 50px rgba(2,6,23,.24); font-weight: 900; text-align: center; }
        .toast.ok { background: #ecfdf5; border: 1px solid #86efac; color: #166534; }
        .toast.error { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; }
        .sidebar { position: fixed; top: 0; bottom: 0; inset-inline-end: 0; width: 285px; background: #071326; padding: 28px 24px; box-sizing: border-box; color: white; z-index: 10; }
        .brand { display: flex; justify-content: space-between; align-items: center; margin-bottom: 34px; }
        .brand h2 { margin: 0; font-size: 28px; }
        .brand p { margin: 4px 0 0; color: #cbd5e1; font-size: 13px; }
        .logo { width: 58px; height: 58px; border-radius: 19px; background: linear-gradient(135deg, #522e91, #d9a441); display: grid; place-items: center; font-weight: 900; font-size: 20px; }
        nav { display: grid; gap: 12px; }
        .nav { min-height: 54px; border: 1px solid rgba(255,255,255,.08); background: rgba(255,255,255,.07); color: white; border-radius: 16px; padding: 15px 18px; font-weight: 900; text-align: inherit; cursor: pointer; }
        .nav.active { border-color: #d9a441; background: rgba(217,164,65,.14); }
        .content { margin-inline-end: 285px; padding: 30px; }
        .hero { background: #071326; color: white; border-radius: 28px; padding: 34px; display: flex; justify-content: space-between; align-items: center; gap: 24px; }
        .hero h1 { margin: 0; font-size: 38px; letter-spacing: -0.03em; }
        .hero p { margin: 12px 0 0; color: #cbd5e1; line-height: 1.8; }
        .topActions, .filters, .rowActions, .modalActions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        button { cursor: pointer; font-weight: 900; font-family: inherit; }
        button:disabled { opacity: .65; cursor: not-allowed; }
        .white, .gold, .purple, .ok, .danger, .small { border-radius: 14px; padding: 13px 18px; border: 0; }
        .white { background: white; color: #071326; }
        .bordered { border: 1px solid #cbd5e1; }
        .gold { background: #fff7e6; color: #7a5200; border: 1px solid #d9a441; }
        .purple { background: #522e91; color: white; }
        .ok { background: #16a34a; color: white; }
        .danger { background: #dc2626; color: white; }
        .small { background: white; color: #2563eb; border: 1px solid #cbd5e1; }
        .notice { margin-top: 20px; border-radius: 18px; padding: 17px 18px; font-size: 16px; }
        .good { background: #ecfdf5; border: 1px solid #86efac; color: #166534; }
        .bad { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; }
        .stats { margin-top: 24px; display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; }
        .stat { background: white; border-radius: 20px; padding: 22px; box-shadow: 0 12px 32px rgba(15,23,42,.08); }
        .stat strong { display: block; font-size: 36px; line-height: 1; }
        .stat span { display: block; margin-top: 12px; color: #64748b; }
        .panel { margin-top: 24px; background: white; border-radius: 24px; box-shadow: 0 12px 32px rgba(15,23,42,.08); overflow: hidden; }
        .panelHead { padding: 26px; display: flex; justify-content: space-between; align-items: center; gap: 20px; border-bottom: 1px solid #e2e8f0; }
        .panelHead span { color: #64748b; }
        .panelHead h2 { margin: 7px 0 0; font-size: 32px; }
        input, select, textarea { border: 1px solid #cbd5e1; border-radius: 14px; padding: 13px 16px; background: white; font: inherit; min-height: 46px; box-sizing: border-box; }
        textarea { width: 100%; min-height: 110px; margin-top: 16px; }
        .rows { padding: 24px; display: grid; gap: 14px; }
        .empty { border: 1px dashed #cbd5e1; border-radius: 18px; padding: 28px; color: #64748b; text-align: center; font-weight: 900; }
        .row { border: 1px solid #e2e8f0; border-radius: 18px; padding: 20px; display: flex; justify-content: space-between; gap: 20px; align-items: center; background: white; }
        .row h3 { margin: 0 0 10px; font-size: 21px; }
        .row p { margin: 0; color: #64748b; line-height: 1.8; }
        .notes { margin-top: 8px !important; }
        .badge { display: inline-block; padding: 5px 11px; border-radius: 999px; font-weight: 900; background: #e0f2fe; color: #075985; }
        .approved { background: #dcfce7; color: #166534; }
        .rejected { background: #fee2e2; color: #991b1b; }
        .pending { background: #e0f2fe; color: #075985; }
        .confirmed { background: #ede9fe; color: #5b21b6; }
        .latest { padding: 26px; }
        .latest h2 { margin-top: 0; }
        .logList { display: grid; gap: 8px; }
        .logList p { margin: 0; color: #64748b; line-height: 1.8; }
        .modalLayer { position: fixed; inset: 0; background: rgba(2,6,23,.62); display: grid; place-items: center; padding: 20px; z-index: 100; }
        .modal { width: min(680px, 95vw); background: white; border-radius: 26px; padding: 30px; box-shadow: 0 24px 90px rgba(2,6,23,.4); }
        .modalKicker { color: #522e91; font-weight: 900; letter-spacing: .08em; font-size: 12px; }
        .modal h2 { margin: 8px 0 12px; }
        .detailGrid { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 12px; margin: 18px 0; }
        .detailGrid div, .targetBox { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 16px; padding: 14px; }
        .detailGrid small { display: block; color: #64748b; margin-bottom: 7px; }
        .detailGrid strong { word-break: break-word; }
        .targetBox { margin: 16px 0; font-weight: 900; }
        .wide { width: 100%; }
        @media (max-width: 900px) { .sidebar { position: static; width: auto; } .content { margin-inline-end: 0; padding: 18px; } .hero, .panelHead, .row { flex-direction: column; align-items: stretch; } }
      `}</style>
    </main>
  );
}
