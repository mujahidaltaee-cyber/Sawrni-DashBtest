#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PKG_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "Applying Sawrni Admin v1.3 Recovery Full UI into: $ROOT"

mkdir -p "$ROOT/app"
rsync -a "$PKG_DIR/app/" "$ROOT/app/"
cp "$PKG_DIR/package.json" "$ROOT/package.json"
cp "$PKG_DIR/.env.local.example" "$ROOT/.env.local.example"

if [ ! -f "$ROOT/.env.local" ]; then
  cp "$PKG_DIR/.env.local.example" "$ROOT/.env.local"
fi

mkdir -p "$ROOT/_verified_builds"
cp "$PKG_DIR/scripts/smoke_test_v1_3.sh" "$ROOT/_verified_builds/smoke_test_v1_3.sh"
chmod +x "$ROOT/_verified_builds/smoke_test_v1_3.sh"

cat > "$ROOT/_verified_builds/SAWRNI_ADMIN_V1_3_RECOVERY_NOTES.md" <<'NOTES'
# Sawrni Admin v1.3 Recovery Full UI

This workspace had no app/ folder. The recovery package restored a full standalone Next.js admin UI.

Backend expected by default:
http://127.0.0.1:8000/api/v1

Next UI:
http://127.0.0.1:3000

Status label after successful test:
Sawrni Admin v1.3 Recovery Build — Integration Layer Verified
NOTES

echo "Done. Now run: npm install && npm run dev"
