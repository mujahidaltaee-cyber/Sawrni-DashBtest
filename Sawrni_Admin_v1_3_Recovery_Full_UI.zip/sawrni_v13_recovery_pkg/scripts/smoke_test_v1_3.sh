#!/usr/bin/env bash
set -euo pipefail

BACKEND="${SAWRNI_BACKEND_BASE:-http://127.0.0.1:8000/api/v1}"
NEXT="${SAWRNI_NEXT_BASE:-http://127.0.0.1:3000}"

echo "Testing backend: $BACKEND"
curl -fsS "$BACKEND/admin-auth/v10/config" >/dev/null
curl -fsS -X POST "$BACKEND/admin-auth/v10/beta-login" \
  -H "Content-Type: application/json" \
  -d '{"phone":"07000000000","password":"password"}' >/tmp/sawrni_login.json
TOKEN="$(python3 - <<'PY'
import json
print(json.load(open('/tmp/sawrni_login.json')).get('token',''))
PY
)"
if [ -z "$TOKEN" ]; then
  echo "No token returned"
  exit 1
fi
curl -fsS "$BACKEND/admin-v10/overview" >/dev/null
curl -fsS "$BACKEND/admin-v10/bookings" >/dev/null
curl -fsS -X POST "$BACKEND/admin-v10/bookings/1/approve" -H "Content-Type: application/json" -d '{}' >/dev/null

echo "Testing Next proxy: $NEXT"
curl -fsS "$NEXT/api/backend/admin-auth/v10/config" >/dev/null
curl -fsS "$NEXT/api/backend/admin-v10/overview" >/dev/null

echo "PASS: Sawrni Admin v1.3 backend + proxy smoke test passed."
