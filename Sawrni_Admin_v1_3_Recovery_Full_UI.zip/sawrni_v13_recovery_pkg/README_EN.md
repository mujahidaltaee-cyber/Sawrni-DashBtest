# Sawrni Admin v1.3 Recovery Full UI

Use this when the workspace lost the `app/` folder and v1.3 cannot apply.

This package restores a full standalone Next.js admin UI with:
- login
- OTP preview
- dashboard
- token guard
- backend proxy with SAWRNI_BACKEND_BASE
- authorization forwarding
- polished Sawrni-style dashboard
- approval/rejection modals
- toast messages
- smoke test script

It expects the no-composer backend to run on port 8000.
