# Sawrni Admin v1.3 Recovery Full UI

استخدم هذه الحزمة إذا اختفى مجلد app/ من Codespaces وفشل تطبيق v1.3.

هذه الحزمة تعيد واجهة Admin كاملة جاهزة للاختبار مع:
- تسجيل الدخول
- OTP Preview
- Dashboard
- حماية بالتوكن
- Proxy قابل للتبديل عن طريق SAWRNI_BACKEND_BASE
- إرسال Authorization للباكند
- واجهة Sawrni محسنة
- نوافذ موافقة/رفض محسنة
- Toast messages
- Smoke test

يجب تشغيل no-composer backend على port 8000.
