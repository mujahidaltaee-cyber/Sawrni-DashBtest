# Sawrni Phase 9.1 v3 — Backend Production API Rebuild

This is the corrected production-staging backend installer. It is not a fragment fix.

It forces PHP 8.3, uses a local Composer PHAR, avoids the Codespaces PHP 8.0 path, creates a clean Laravel backend, applies the Sawrni Phase 3 database/API blueprint, seeds staging users, and adds the API smoke test.

Use v3 only. Ignore old Phase 9.1 and Phase 9.1 v2 packages.
