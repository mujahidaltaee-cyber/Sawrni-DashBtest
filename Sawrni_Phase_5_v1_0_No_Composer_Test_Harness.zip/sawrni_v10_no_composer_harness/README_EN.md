# Sawrni v1.0 No-Composer Test Harness

This is a temporary Codespaces runtime for testing the Sawrni Admin v1.0 UI when Composer/Laravel cannot run because the Codespaces PHP version is too old.

It implements the same test endpoints expected by the admin UI:

- `/api/v1/admin-auth/v10/config`
- `/api/v1/admin-auth/v10/beta-login`
- `/api/v1/admin-auth/v10/request-otp`
- `/api/v1/admin-auth/v10/verify-otp`
- `/api/v1/admin-v10/overview`
- `/api/v1/admin-v10/{module}`
- `/api/v1/admin-v10/{module}/{id}/{action}`

Run:

```bash
cd /workspaces/Sawrni-beta1/_phase5_v10_no_composer
bash scripts/run-backend.sh
```

Then run the admin UI on port 3000 as usual.

Test login:

- Phone: `07000000000`
- Password: `password`
- OTP: `123456`

This is only for local UI/testing. It is not the final production Laravel backend.
