#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
php -S 0.0.0.0:8000 -t "$DIR/public" "$DIR/public/index.php"
