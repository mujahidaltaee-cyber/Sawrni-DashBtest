# Sawrni v1.0 No-Composer Test Harness

هذه نسخة اختبار مؤقتة لتشغيل Backend بسيط بدون Composer وبدون Laravel عندما يكون Codespaces يستخدم PHP قديم.

تشغّل نفس endpoints المطلوبة من واجهة الأدمن v1.0 حتى نختبر الواجهة والأزرار والدخول.

التشغيل:

```bash
cd /workspaces/Sawrni-beta1/_phase5_v10_no_composer
bash scripts/run-backend.sh
```

ثم شغّل واجهة الأدمن على port 3000 كالمعتاد.

بيانات الاختبار:

- Phone: `07000000000`
- Password: `password`
- OTP: `123456`

هذه نسخة اختبار فقط وليست Backend الإنتاج النهائي.
