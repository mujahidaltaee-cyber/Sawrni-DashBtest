<?php

declare(strict_types=1);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, Accept');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$storageDir = dirname(__DIR__) . '/storage';
$dbFile = $storageDir . '/sawrni_v10_store.json';
if (!is_dir($storageDir)) {
    mkdir($storageDir, 0775, true);
}

function now_iso(): string { return gmdate('c'); }
function respond(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function read_json_body(): array {
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
function default_store(): array {
    $now = now_iso();
    return [
        'otps' => [],
        'sessions' => [],
        'logs' => [],
        'items' => [
            ['id'=>1,'module'=>'bookings','title_ar'=>'حجز جلسة تخرج','title_en'=>'Graduation session booking','status'=>'pending','party'=>'Ali Kareem','phone'=>'07700000001','amount'=>'IQD 45,000','notes'=>'تم دفع العربون وبانتظار تأكيد مزود الخدمة.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>2,'module'=>'bookings','title_ar'=>'حجز مصور أعراس','title_en'=>'Wedding photographer booking','status'=>'approved','party'=>'Sara Ahmed','phone'=>'07700000002','amount'=>'IQD 150,000','notes'=>'حجز عالي القيمة، تحقق من تعارض المواعيد.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>3,'module'=>'bookings','title_ar'=>'حجز تصوير منتجات','title_en'=>'Product photoshoot booking','status'=>'approved','party'=>'Baghdad Cafe','phone'=>'07700000003','amount'=>'IQD 90,000','notes'=>'حجز مؤكد مع وصل إلكتروني.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>4,'module'=>'providers','title_ar'=>'ملف مزود خدمة جديد','title_en'=>'New provider profile','status'=>'pending','party'=>'Noor Model','phone'=>'07700000012','amount'=>null,'notes'=>'بانتظار مراجعة الهوية والأعمال.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>5,'module'=>'providers','title_ar'=>'ملف أندر بانتظار الموافقة','title_en'=>'Pending editing provider','status'=>'approved','party'=>'Edit House','phone'=>'07700000013','amount'=>null,'notes'=>'تمت الموافقة للاختبار التجريبي.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>6,'module'=>'payments','title_ar'=>'دفعة حجز أعراس','title_en'=>'Wedding booking payment','status'=>'confirmed','party'=>'Sara Ahmed','phone'=>'07700000002','amount'=>'IQD 150,000','notes'=>'تم تأكيد الدفعة.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>7,'module'=>'wallets','title_ar'=>'محفظة مزود خدمة','title_en'=>'Provider wallet','status'=>'warning','party'=>'Edit House','phone'=>'07700000013','amount'=>'IQD 75,000','notes'=>'تحذير حد الدين.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>8,'module'=>'reviews','title_ar'=>'تقييم جديد','title_en'=>'New review','status'=>'pending','party'=>'Customer A','phone'=>'07700000020','amount'=>null,'notes'=>'بانتظار المراجعة.','created_at'=>$now,'updated_at'=>$now],
            ['id'=>9,'module'=>'delivery','title_ar'=>'ملف تسليم صور','title_en'=>'Photo delivery file','status'=>'pending','party'=>'Baghdad Cafe','phone'=>'07700000003','amount'=>null,'notes'=>'بانتظار موافقة التسليم.','created_at'=>$now,'updated_at'=>$now],
        ],
    ];
}
function load_store(string $file): array {
    if (!file_exists($file)) {
        $store = default_store();
        file_put_contents($file, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        return $store;
    }
    $data = json_decode(file_get_contents($file) ?: '', true);
    return is_array($data) ? $data : default_store();
}
function save_store(string $file, array $store): void {
    file_put_contents($file, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}
function modules(): array {
    return [
        'bookings' => ['ar'=>'الحجوزات','en'=>'Bookings'],
        'providers' => ['ar'=>'مزودو الخدمة','en'=>'Providers'],
        'payments' => ['ar'=>'المدفوعات','en'=>'Payments'],
        'wallets' => ['ar'=>'المحافظ','en'=>'Wallets'],
        'reviews' => ['ar'=>'التقييمات','en'=>'Reviews'],
        'delivery' => ['ar'=>'ملفات التسليم','en'=>'Delivery Files'],
    ];
}

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'];
$store = load_store($dbFile);

if ($method === 'GET' && $path === '/api/v1/health') {
    respond(['status'=>'ok','app'=>'Sawrni','version'=>'v1.0-no-composer','database'=>'json-ok','timestamp'=>now_iso()]);
}

if ($method === 'GET' && $path === '/api/v1/admin-auth/v10/config') {
    respond(['status'=>'ok','version'=>'v1.0','auth_modes'=>['local_beta','otp_preview'],'otp_preview_code'=>'123456','production_auth_ready'=>true,'staging_ready'=>true,'runtime'=>'no-composer-test-harness']);
}

if ($method === 'POST' && $path === '/api/v1/admin-auth/v10/beta-login') {
    $body = read_json_body();
    $phone = trim((string)($body['phone'] ?? ''));
    $password = (string)($body['password'] ?? '');
    if ($phone !== '07000000000' || $password !== 'password') {
        respond(['message_ar'=>'رقم الهاتف أو كلمة المرور التجريبية غير صحيحة.','message_en'=>'Invalid beta phone or password.'], 401);
    }
    $token = 'local-beta-v10-' . bin2hex(random_bytes(24));
    $store['sessions'][] = ['user_id'=>1,'phone'=>$phone,'token'=>$token,'mode'=>'local_beta','expires_at'=>gmdate('c', time()+604800),'created_at'=>now_iso(),'updated_at'=>now_iso()];
    save_store($dbFile, $store);
    respond(['token'=>$token,'mode'=>'local_beta','user'=>['id'=>1,'name'=>'Super Admin','phone'=>$phone,'role'=>'super_admin']]);
}

if ($method === 'POST' && $path === '/api/v1/admin-auth/v10/request-otp') {
    $body = read_json_body();
    $phone = trim((string)($body['phone'] ?? ''));
    if ($phone === '') respond(['message_ar'=>'رقم الهاتف مطلوب.','message_en'=>'Phone is required.'], 422);
    foreach ($store['otps'] as &$otp) {
        if ($otp['phone'] === $phone && $otp['status'] === 'active') { $otp['status'] = 'replaced'; $otp['updated_at'] = now_iso(); }
    }
    unset($otp);
    $store['otps'][] = ['id'=>count($store['otps'])+1,'phone'=>$phone,'otp'=>'123456','otp_hash'=>password_hash('123456', PASSWORD_DEFAULT),'purpose'=>'admin_login','channel'=>'sms_preview','status'=>'active','attempts'=>0,'expires_at'=>gmdate('c', time()+600),'created_at'=>now_iso(),'updated_at'=>now_iso()];
    save_store($dbFile, $store);
    respond(['message_ar'=>'تم إنشاء رمز OTP التجريبي.','message_en'=>'OTP preview created.','otp_preview'=>'123456']);
}

if ($method === 'POST' && $path === '/api/v1/admin-auth/v10/verify-otp') {
    $body = read_json_body();
    $phone = trim((string)($body['phone'] ?? ''));
    $code = trim((string)($body['otp'] ?? ''));
    $foundIndex = null;
    for ($i = count($store['otps']) - 1; $i >= 0; $i--) {
        if ($store['otps'][$i]['phone'] === $phone && $store['otps'][$i]['status'] === 'active') { $foundIndex = $i; break; }
    }
    if ($foundIndex === null) respond(['message_ar'=>'لا يوجد طلب OTP فعال لهذا الرقم.','message_en'=>'No active OTP request for this phone.'], 401);
    $record = $store['otps'][$foundIndex];
    $valid = ($record['otp'] ?? null) === $code || password_verify($code, $record['otp_hash'] ?? '');
    if (!$valid) {
        $store['otps'][$foundIndex]['attempts'] = (int)($store['otps'][$foundIndex]['attempts'] ?? 0) + 1;
        $store['otps'][$foundIndex]['updated_at'] = now_iso();
        save_store($dbFile, $store);
        respond(['message_ar'=>'رمز OTP غير صحيح.','message_en'=>'Invalid OTP.'], 401);
    }
    $store['otps'][$foundIndex]['status'] = 'consumed';
    $store['otps'][$foundIndex]['consumed_at'] = now_iso();
    $store['otps'][$foundIndex]['updated_at'] = now_iso();
    $token = 'otp-preview-v10-' . bin2hex(random_bytes(24));
    $store['sessions'][] = ['user_id'=>1,'phone'=>$phone,'token'=>$token,'mode'=>'otp_preview','expires_at'=>gmdate('c', time()+604800),'created_at'=>now_iso(),'updated_at'=>now_iso()];
    save_store($dbFile, $store);
    respond(['token'=>$token,'mode'=>'otp_preview','user'=>['id'=>1,'name'=>'Super Admin','phone'=>$phone,'role'=>'super_admin']]);
}

if ($method === 'POST' && $path === '/api/v1/admin-auth/v10/logout') {
    respond(['message_ar'=>'تم تسجيل الخروج.','message_en'=>'Logged out.']);
}

if ($method === 'GET' && $path === '/api/v1/admin-v10/overview') {
    $items = $store['items'];
    $count = fn($filter) => count(array_filter($items, $filter));
    $stats = [
        ['value'=>(string)$count(fn($i)=>$i['module']==='bookings'),'label_ar'=>'سجلات الحجوزات','label_en'=>'Booking records'],
        ['value'=>(string)$count(fn($i)=>$i['module']==='providers' && $i['status']==='pending'),'label_ar'=>'مزودون بانتظار الموافقة','label_en'=>'Providers pending approval'],
        ['value'=>'15%','label_ar'=>'عمولة المنصة','label_en'=>'Platform commission'],
        ['value'=>'75K','label_ar'=>'حد الدين','label_en'=>'Debt limit'],
        ['value'=>(string)$count(fn($i)=>$i['module']==='wallets' && $i['status']==='warning'),'label_ar'=>'تنبيهات الدين','label_en'=>'Debt alerts'],
    ];
    respond(['status'=>'ok','version'=>'v1.0','stats'=>$stats,'logs'=>array_slice(array_reverse($store['logs']),0,8)]);
}

if ($method === 'GET' && preg_match('#^/api/v1/admin-v10/([a-zA-Z0-9_-]+)$#', $path, $m)) {
    $module = $m[1];
    if (!isset(modules()[$module])) respond(['message'=>'Unknown module.'], 404);
    $rows = array_values(array_filter($store['items'], fn($i) => $i['module'] === $module));
    respond(['status'=>'ok','module'=>$module,'rows'=>$rows]);
}

if ($method === 'GET' && preg_match('#^/api/v1/admin-v10/([a-zA-Z0-9_-]+)/(\d+)/view$#', $path, $m)) {
    $module = $m[1]; $id = (int)$m[2];
    foreach ($store['items'] as $item) {
        if ($item['module'] === $module && (int)$item['id'] === $id) respond(['status'=>'ok','item'=>$item]);
    }
    respond(['message'=>'Item not found.'], 404);
}

if ($method === 'POST' && preg_match('#^/api/v1/admin-v10/([a-zA-Z0-9_-]+)/(\d+)/(approve|reject|view)$#', $path, $m)) {
    $module = $m[1]; $id = (int)$m[2]; $action = $m[3];
    $body = read_json_body(); $reason = (string)($body['reason'] ?? '');
    $idx = null;
    foreach ($store['items'] as $i => $item) { if ($item['module'] === $module && (int)$item['id'] === $id) { $idx = $i; break; } }
    if ($idx === null) respond(['message'=>'Item not found.'], 404);
    if ($action === 'approve') $store['items'][$idx]['status'] = 'approved';
    if ($action === 'reject') { $store['items'][$idx]['status'] = 'rejected'; if ($reason !== '') $store['items'][$idx]['notes'] .= "\nReason: " . $reason; }
    $store['items'][$idx]['updated_at'] = now_iso();
    $moduleNames = modules();
    $moduleAr = $moduleNames[$module]['ar'] ?? $module; $moduleEn = $moduleNames[$module]['en'] ?? $module;
    $messageAr = $action === 'approve' ? "تمت الموافقة على عنصر رقم {$id} في قسم {$moduleAr}." : ($action === 'reject' ? "تم رفض عنصر رقم {$id} في قسم {$moduleAr}." : "تم عرض تفاصيل عنصر رقم {$id} في قسم {$moduleAr}.");
    $messageEn = $action === 'approve' ? "Approved item {$id} in {$moduleEn}." : ($action === 'reject' ? "Rejected item {$id} in {$moduleEn}." : "Viewed item {$id} in {$moduleEn}.");
    $store['logs'][] = ['id'=>count($store['logs'])+1,'module'=>$module,'item_id'=>$id,'action'=>$action,'reason'=>$reason,'message_ar'=>$messageAr,'message_en'=>$messageEn,'created_at'=>now_iso()];
    save_store($dbFile, $store);
    respond(['status'=>'ok','message_ar'=>$messageAr,'message_en'=>$messageEn,'item_status'=>$store['items'][$idx]['status']]);
}

respond(['message'=>'Not Found','path'=>$path], 404);
