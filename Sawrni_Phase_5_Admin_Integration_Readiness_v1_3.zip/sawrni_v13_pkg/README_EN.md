# Sawrni Phase 5 v1.3 — Admin Integration Readiness

This package does not change the no-composer backend. It keeps the verified v1.2 UI and adds the integration layer needed before moving to the real Laravel backend.

## Added

- Configurable Next.js proxy: `SAWRNI_BACKEND_BASE`
- Proxy timeout handling: `SAWRNI_PROXY_TIMEOUT_MS`
- Authorization bearer token forwarding
- Central API helper: `app/lib/sawrniApi.ts`
- Dashboard requests now include the saved admin token
- `.env.local.example` for later staging/production backend switching
- Smoke test script: `_verified_builds/smoke_test_v1_3.sh`

## Apply

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase5_v13
unzip -o Sawrni_Phase_5_Admin_Integration_Readiness_v1_3.zip -d _phase5_v13
bash _phase5_v13/sawrni_v13_pkg/scripts/apply_phase5_v1_3.sh
```

Restart UI:

```bash
pkill -f "next dev" 2>/dev/null || true
rm -rf .next
npm run dev
```

Keep the no-composer backend running on port 8000.

## Test

After port 3000 is open:

```bash
bash _verified_builds/smoke_test_v1_3.sh
```

Then test in browser:

- Login
- Dashboard load
- Change modules
- Approve item
- Reject item with reason
- Check latest actions

Expected label after passing:

**Sawrni Admin v1.3 Test Build — Integration Layer Verified**
