#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/workspaces/Sawrni-DashBtest"

if [ ! -d "$APP_ROOT/app" ]; then
  echo "ERROR: $APP_ROOT/app not found. Apply this inside the Sawrni-DashBtest workspace after v1.2."
  exit 1
fi

cd "$APP_ROOT"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "_verified_builds/backups/v1_3_$STAMP"
cp -R app "_verified_builds/backups/v1_3_$STAMP/app_backup" 2>/dev/null || true
cp package.json "_verified_builds/backups/v1_3_$STAMP/package.json.backup" 2>/dev/null || true

mkdir -p app/api/backend/[...path] app/lib _verified_builds

cat > app/api/backend/[...path]/route.ts <<'TS'
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const DEFAULT_BACKEND = 'http://127.0.0.1:8000/api/v1';
const BACKEND_BASE = (process.env.SAWRNI_BACKEND_BASE || DEFAULT_BACKEND).replace(/\/$/, '');
const TIMEOUT_MS = Number(process.env.SAWRNI_PROXY_TIMEOUT_MS || 15000);

type RouteContext = { params: { path: string[] } };

function buildTargetUrl(req: NextRequest, ctx: RouteContext) {
  const path = (ctx.params.path || []).join('/');
  const query = req.nextUrl.search || '';
  return `${BACKEND_BASE}/${path}${query}`;
}

function buildHeaders(req: NextRequest) {
  const headers = new Headers();
  headers.set('Accept', 'application/json');

  const contentType = req.headers.get('content-type');
  if (contentType) headers.set('Content-Type', contentType);
  else headers.set('Content-Type', 'application/json');

  const authorization = req.headers.get('authorization');
  if (authorization) headers.set('Authorization', authorization);

  const xRequestId = req.headers.get('x-request-id');
  if (xRequestId) headers.set('X-Request-ID', xRequestId);

  return headers;
}

async function proxy(req: NextRequest, ctx: RouteContext) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const method = req.method.toUpperCase();
    const body = method === 'GET' || method === 'HEAD' ? undefined : await req.text();
    const upstream = await fetch(buildTargetUrl(req, ctx), {
      method,
      headers: buildHeaders(req),
      body,
      cache: 'no-store',
      signal: controller.signal,
    });

    const text = await upstream.text();

    return new NextResponse(text, {
      status: upstream.status,
      headers: {
        'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
        'X-Sawrni-Backend-Base': BACKEND_BASE,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Proxy error';
    return NextResponse.json(
      {
        ok: false,
        source: 'sawrni-admin-next-proxy',
        backend_base: BACKEND_BASE,
        message_en: message.includes('abort') ? 'Backend request timed out.' : message,
        message_ar: message.includes('abort') ? 'انتهت مهلة الاتصال بالـ backend.' : 'تعذر الاتصال بالـ backend.',
      },
      { status: 502 }
    );
  } finally {
    clearTimeout(timeout);
  }
}

export async function GET(req: NextRequest, ctx: RouteContext) { return proxy(req, ctx); }
export async function POST(req: NextRequest, ctx: RouteContext) { return proxy(req, ctx); }
export async function PUT(req: NextRequest, ctx: RouteContext) { return proxy(req, ctx); }
export async function PATCH(req: NextRequest, ctx: RouteContext) { return proxy(req, ctx); }
export async function DELETE(req: NextRequest, ctx: RouteContext) { return proxy(req, ctx); }
TS

cat > app/lib/sawrniApi.ts <<'TS'
export type ApiResult<T = any> = T & {
  ok?: boolean;
  message?: string;
  message_ar?: string;
  message_en?: string;
};

const API_PROXY_BASE = '/api/backend';

function getStoredToken() {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem('sawrni_admin_token') || '';
}

export function sawrniAuthHeaders(extra?: Record<string, string>) {
  const token = getStoredToken();
  return {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(extra || {}),
  };
}

export async function sawrniApi<T = any>(path: string, init?: RequestInit): Promise<ApiResult<T>> {
  const normalized = path.startsWith('/') ? path : `/${path}`;
  const res = await fetch(`${API_PROXY_BASE}${normalized}`, {
    ...init,
    cache: 'no-store',
    headers: sawrniAuthHeaders(init?.headers as Record<string, string> | undefined),
  });

  const text = await res.text();
  let data: any = {};

  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!res.ok) {
    const error = new Error(data.message_ar || data.message_en || data.message || `Request failed: ${res.status}`);
    (error as any).status = res.status;
    (error as any).data = data;
    throw error;
  }

  return data as ApiResult<T>;
}

export const SawrniApi = {
  config: () => sawrniApi('/admin-auth/v10/config'),
  betaLogin: (phone: string, password: string) =>
    sawrniApi('/admin-auth/v10/beta-login', {
      method: 'POST',
      body: JSON.stringify({ phone, password }),
    }),
  requestOtp: (phone: string) =>
    sawrniApi('/admin-auth/v10/request-otp', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    }),
  verifyOtp: (phone: string, otp: string) =>
    sawrniApi('/admin-auth/v10/verify-otp', {
      method: 'POST',
      body: JSON.stringify({ phone, otp }),
    }),
  overview: () => sawrniApi('/admin-v10/overview'),
  moduleRows: (module: string) => sawrniApi(`/admin-v10/${module}`),
  adminAction: (module: string, id: number | string, action: 'approve' | 'reject' | string, payload?: Record<string, any>) =>
    sawrniApi(`/admin-v10/${module}/${id}/${action}`, {
      method: 'POST',
      body: JSON.stringify(payload || {}),
    }),
};
TS

cat > .env.local.example <<'ENV'
# Phase 5 v1.3
# Keep this default while using the no-composer test backend on port 8000.
SAWRNI_BACKEND_BASE=http://127.0.0.1:8000/api/v1
SAWRNI_PROXY_TIMEOUT_MS=15000

# Later, when real Laravel is deployed, change SAWRNI_BACKEND_BASE to the production/staging API base.
# Example:
# SAWRNI_BACKEND_BASE=https://api.sawrni.com/api/v1
ENV

python3 - <<'PY'
from pathlib import Path

p = Path('app/dashboard/page.tsx')
if p.exists():
    text = p.read_text()

    if 'function authHeaders()' not in text:
        marker = 'export default function DashboardPage() {'
        helper = """
function authHeaders(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('sawrni_admin_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

"""
        text = text.replace(marker, helper + marker)

    replacements = {
        "fetch('/api/backend/admin-v10/overview', { cache: 'no-store' });":
        "fetch('/api/backend/admin-v10/overview', { cache: 'no-store', headers: authHeaders() });",
        "fetch(`/api/backend/admin-v10/${module}`, { cache: 'no-store' });":
        "fetch(`/api/backend/admin-v10/${module}`, { cache: 'no-store', headers: authHeaders() });",
        "headers: { 'Content-Type': 'application/json' },\n        body: JSON.stringify({ reason }),":
        "headers: { 'Content-Type': 'application/json', ...authHeaders() },\n        body: JSON.stringify({ reason }),",
        "Admin Beta v1.2": "Admin Beta v1.3",
        "لوحة اختبار v1.2": "لوحة اختبار v1.3",
        "v1.2 test dashboard": "v1.3 test dashboard",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)

    p.write_text(text)

# Patch login so successful login stores user when available and version text is updated.
login = Path('app/login/page.tsx')
if login.exists():
    text = login.read_text()
    text = text.replace('اختبار v1.0 بدون Composer.', 'اختبار v1.3 مع Proxy جاهز للربط الحقيقي.')
    text = text.replace('Sawrni Admin Test', 'Sawrni Admin Test')
    # Add user storage after token storage if not present.
    if "sawrni_admin_user" not in text:
        text = text.replace(
            "localStorage.setItem('sawrni_admin_token', data.token);",
            "localStorage.setItem('sawrni_admin_token', data.token);\n    if (data.user) localStorage.setItem('sawrni_admin_user', JSON.stringify(data.user));"
        )
    login.write_text(text)

print('Dashboard/login patched for v1.3 integration readiness.')
PY

cat > _verified_builds/SAWRNI_ADMIN_V1_3_INTEGRATION_READINESS.md <<'EOF'
# Sawrni Admin v1.3 — Integration Readiness

Status: Applied

This phase keeps the verified v1.2 UI and adds the technical layer required before connecting to the real Laravel backend.

Added:
- Configurable Next.js backend proxy through SAWRNI_BACKEND_BASE.
- Proxy timeout handling.
- Forwarding of Authorization bearer token from the frontend to backend.
- Central API client at app/lib/sawrniApi.ts.
- Dashboard requests now include the stored admin token.
- Environment example file for switching from no-composer backend to real Laravel later.

Backend remains unchanged:
- No-composer backend should stay running on port 8000 for current testing.
- Real Laravel backend integration is reserved for the PHP 8.2+ environment.
EOF

cat > _verified_builds/smoke_test_v1_3.sh <<'SH2'
#!/usr/bin/env bash
set -euo pipefail

echo "Testing direct no-composer backend..."
curl -s http://127.0.0.1:8000/api/v1/admin-auth/v10/config | python3 -m json.tool >/dev/null
curl -s http://127.0.0.1:8000/api/v1/admin-v10/overview | python3 -m json.tool >/dev/null

echo "Testing Next proxy. Make sure npm run dev is running on port 3000..."
curl -s http://127.0.0.1:3000/api/backend/admin-auth/v10/config | python3 -m json.tool >/dev/null
curl -s http://127.0.0.1:3000/api/backend/admin-v10/overview | python3 -m json.tool >/dev/null

echo "v1.3 smoke test passed."
SH2
chmod +x _verified_builds/smoke_test_v1_3.sh

rm -rf .next

echo "Phase 5 v1.3 Integration Readiness applied."
echo "Restart UI: npm run dev"
echo "Optional smoke test after UI starts: bash _verified_builds/smoke_test_v1_3.sh"
