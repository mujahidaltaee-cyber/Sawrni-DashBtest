# صورني Phase 5 v1.3 — تجهيز الربط الحقيقي للإدارة

هذه الحزمة لا تغيّر الـ no-composer backend. تبقي واجهة v1.2 المجتازة للاختبار، وتضيف طبقة الربط المطلوبة قبل الانتقال إلى Laravel الحقيقي.

## الإضافات

- Proxy قابل للتغيير من خلال: `SAWRNI_BACKEND_BASE`
- مهلة اتصال للـ proxy: `SAWRNI_PROXY_TIMEOUT_MS`
- إرسال Authorization Bearer token إلى الـ backend
- ملف API مركزي: `app/lib/sawrniApi.ts`
- طلبات dashboard أصبحت ترسل token المحفوظ
- ملف `.env.local.example` لتسهيل التحويل لاحقاً إلى staging/production
- سكربت اختبار سريع: `_verified_builds/smoke_test_v1_3.sh`

## التطبيق

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase5_v13
unzip -o Sawrni_Phase_5_Admin_Integration_Readiness_v1_3.zip -d _phase5_v13
bash _phase5_v13/sawrni_v13_pkg/scripts/apply_phase5_v1_3.sh
```

إعادة تشغيل الواجهة:

```bash
pkill -f "next dev" 2>/dev/null || true
rm -rf .next
npm run dev
```

اترك no-composer backend شغال على port 8000.

## الاختبار

بعد فتح port 3000:

```bash
bash _verified_builds/smoke_test_v1_3.sh
```

ثم اختبر من المتصفح:

- تسجيل الدخول
- فتح dashboard
- التنقل بين الأقسام
- الموافقة على عنصر
- رفض عنصر مع كتابة سبب
- التأكد من تحديث آخر العمليات

بعد نجاح الاختبار تصبح النسخة:

**Sawrni Admin v1.3 Test Build — Integration Layer Verified**
