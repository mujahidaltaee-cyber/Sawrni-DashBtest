# صورني — Phase 9.0 Production Staging Foundation

هذه الحزمة لا تعتبر المنتج النهائي. هدفها تثبيت الأساس الإنتاجي الصحيح قبل بناء النسخة الحقيقية:

- ربط الهوية البصرية الحقيقية.
- إنشاء هيكل مستقر للـ staging.
- تثبيت ألوان صورني وشعارها وشعارها النصي.
- إضافة قائمة اختبار كاملة للتطبيق ولوحة التحكم والحجوزات والإشعارات.

## طريقة التطبيق

```bash
cd /workspaces/Sawrni-DashBtest
rm -rf _phase9_0
unzip -o Sawrni_Phase_9_0_Production_Staging_Foundation.zip -d _phase9_0
bash _phase9_0/sawrni_phase9_0_pkg/scripts/apply_phase9_0_production_staging_foundation.sh
```

بعدها نبدأ Phase 9.1 لبناء backend الحقيقي.
