#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Applying Sawrni Phase 9.0 Production Staging Foundation to: $ROOT"

mkdir -p assets/brand docs/source deployment tests/e2e shared-ui-spec

cp -R "$PKG_DIR/assets/brand/"* assets/brand/
cp -R "$PKG_DIR/shared-ui-spec/"* shared-ui-spec/
cp -R "$PKG_DIR/docs/"* docs/
cp -R "$PKG_DIR/deployment/"* deployment/
cp -R "$PKG_DIR/tests/e2e/"* tests/e2e/

# Copy brand into admin dashboard if it exists
if [ -d "admin-dashboard" ]; then
  mkdir -p admin-dashboard/public/brand
  cp assets/brand/logo_square.png admin-dashboard/public/brand/logo-square.png
  cp assets/brand/logo_horizontal.png admin-dashboard/public/brand/logo-horizontal.png
  cp assets/brand/app_icon.png admin-dashboard/public/brand/app-icon.png
  cp shared-ui-spec/brand_tokens.css admin-dashboard/public/brand/brand-tokens.css
  echo "Admin brand assets copied."
fi

# Copy brand into Flutter app if it exists
if [ -d "mobile-flutter" ]; then
  mkdir -p mobile-flutter/assets/brand
  cp assets/brand/logo_square.png mobile-flutter/assets/brand/logo_square.png
  cp assets/brand/logo_horizontal.png mobile-flutter/assets/brand/logo_horizontal.png
  cp assets/brand/app_icon.png mobile-flutter/assets/brand/app_icon.png
  mkdir -p mobile-flutter/lib/core/brand
  cp shared-ui-spec/sawrni_brand.dart mobile-flutter/lib/core/brand/sawrni_brand.dart
  echo "Mobile brand assets copied."
fi

cat > docs/PHASE_9_0_APPLIED.md <<'EOF'
# Phase 9.0 Applied

Sawrni Production Staging Foundation has been applied.

Next implementation phases:
1. Phase 9.1 Backend Production API rebuild
2. Phase 9.2 Admin Dashboard production UI + API connection
3. Phase 9.3 Flutter app production UI + API connection
4. Phase 9.4 Full E2E staging test
5. Phase 9.5 Store-ready Android/iOS builds
EOF

echo "PASS: Phase 9.0 Production Staging Foundation applied."
